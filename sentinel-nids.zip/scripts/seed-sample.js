'use strict';

/**
 * CLI: seed the clearly-labeled SAMPLE alert dataset into the local database.
 * Every record is stored with source='sample' and is_simulated=1, so it can
 * never be mistaken for a genuine detection in the dashboard.
 *
 * Usage: npm run seed-sample   (server does not need to be running)
 */

const path = require('path');
const { loadConfig } = require('../server/config');
const { Db } = require('../server/db');
const { loadRuleSet } = require('../server/ruleEngine');
const { Monitor } = require('../server/monitor');
const notify = require('../server/notify');
const { seedSample } = require('./seed-sample-lib');

function abs(config, p) {
  return path.isAbsolute(p) ? p : path.join(config.ROOT, p);
}

function main() {
  const config = loadConfig();
  config.dataDirAbs = abs(config, config.dataDir);
  config.watchDirAbs = abs(config, config.monitor.watchDir);

  const db = new Db(config.dataDirAbs);

  const ruleSetHolder = {
    dirs: [path.join(config.ROOT, 'config', 'rules')],
    _rs: null,
    get() { return this._rs; },
    set(rs) { this._rs = rs; },
  };
  ruleSetHolder._rs = loadRuleSet(config.vars, ruleSetHolder.dirs);

  const monitor = new Monitor({
    config,
    db,
    ruleSetHolder,
    notify: (alert) => notify.dispatch(db, config, alert),
    log: console,
  });

  const ids = seedSample(db, monitor);
  db.audit({
    id: `a-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    ts: Math.floor(Date.now() / 1000),
    actor: 'cli',
    action: 'sample-data',
    target: 'alerts',
    detail: { count: ids.length, via: 'npm run seed-sample' },
  });

  console.log(`[seed-sample] inserted ${ids.length} sample alerts into ${db.path}`);
  console.log('[seed-sample] all records are labeled source=sample, is_simulated=1 (NOT real detections)');

  db.close();
}

try {
  main();
} catch (err) {
  console.error('[seed-sample] failed:', err.message);
  process.exitCode = 1;
}
