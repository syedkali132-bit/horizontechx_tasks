'use strict';

/**
 * Sample dataset used to evaluate the dashboard when no real captures exist.
 * Every inserted alert is flagged source='sample' AND is_simulated=1 and its
 * signature starts with "SAMPLE", so it can never be mistaken for a genuine
 * detection. Nothing here is presented as real traffic.
 */

const SAMPLE_ALERTS = [
  { t: -22, severity: 'critical', srcIp: '45.155.40.12', dstIp: '192.168.1.20', dstPort: 22, proto: 'tcp', category: 'Attempted Administrator Privilege Gain', signature: 'SAMPLE SSH brute force burst (password guessing)' },
  { t: -21, severity: 'high', srcIp: '45.155.40.12', dstIp: '192.168.1.20', dstPort: 22, proto: 'tcp', category: 'Attempted Administrator Privilege Gain', signature: 'SAMPLE SSH invalid user enumeration' },
  { t: -19, severity: 'high', srcIp: '198.51.100.87', dstIp: '192.168.1.15', dstPort: 3389, proto: 'tcp', category: 'Attempted Reconnaissance', signature: 'SAMPLE RDP connection attempt from external network' },
  { t: -18, severity: 'medium', srcIp: '198.51.100.87', dstIp: '192.168.1.15', dstPort: 3389, proto: 'tcp', category: 'Attempted Reconnaissance', signature: 'SAMPLE RDP NLA negotiation failure burst' },
  { t: -16, severity: 'high', srcIp: '203.0.113.54', dstIp: '192.168.1.30', dstPort: 80, proto: 'tcp', category: 'Web Application Attack', signature: 'SAMPLE SQL injection attempt (union select)' },
  { t: -15, severity: 'medium', srcIp: '203.0.113.54', dstIp: '192.168.1.30', dstPort: 80, proto: 'tcp', category: 'Web Application Attack', signature: 'SAMPLE Directory traversal attempt (../)' },
  { t: -13, severity: 'critical', srcIp: '192.168.1.44', dstIp: '185.220.101.4', dstPort: 6667, proto: 'tcp', category: 'A Network Trojan was Detected', signature: 'SAMPLE IRC bot C2 beacon (5 min interval)' },
  { t: -11, severity: 'medium', srcIp: '192.168.1.44', dstIp: '185.220.101.4', dstPort: 443, proto: 'tcp', category: 'Potentially Bad Traffic', signature: 'SAMPLE Large outbound transfer (possible exfiltration)' },
  { t: -9, severity: 'low', srcIp: '192.168.1.62', dstIp: '8.8.8.8', dstPort: 53, proto: 'udp', category: 'Potentially Bad Traffic', signature: 'SAMPLE Oversized DNS query (possible tunneling)' },
  { t: -8, severity: 'high', srcIp: '91.240.118.172', dstIp: '192.168.1.10', proto: 'tcp', category: 'Attempted Reconnaissance', signature: 'SAMPLE Nmap XMAS scan signature match' },
  { t: -6, severity: 'medium', srcIp: '91.240.118.172', dstIp: '192.168.1.10', proto: 'tcp', category: 'Attempted Reconnaissance', signature: 'SAMPLE TCP port sweep: 34 distinct ports in 60s' },
  { t: -4, severity: 'low', srcIp: '192.168.1.70', dstIp: '192.168.1.1', dstPort: 53, proto: 'udp', category: 'Misc Activity', signature: 'SAMPLE DNS query rate above baseline' },
  { t: -2, severity: 'medium', srcIp: '103.99.0.25', dstIp: '192.168.1.25', dstPort: 21, proto: 'tcp', category: 'Protocol Command Decode', signature: 'SAMPLE FTP anonymous login attempt' },
  { t: -1, severity: 'high', srcIp: '103.99.0.25', dstIp: '192.168.1.25', dstPort: 21, proto: 'tcp', category: 'Attempted User Privilege Gain', signature: 'SAMPLE FTP credential stuffing pattern' },
  { t: -0.2, severity: 'low', srcIp: '192.168.1.80', dstIp: '203.0.113.99', dstPort: 8080, proto: 'tcp', category: 'Misc Activity', signature: 'SAMPLE HTTP request with unusual user agent' },
];

function seedSample(db, monitor) {
  const now = Math.floor(Date.now() / 1000);
  const ids = [];
  for (const s of SAMPLE_ALERTS) {
    const ts = now + Math.round(s.t * 3600); // t is hours ago
    const id = monitor.ingest(
      {
        ts,
        severity: s.severity,
        srcIp: s.srcIp,
        srcPort: null,
        dstIp: s.dstIp,
        dstPort: s.dstPort ?? null,
        proto: s.proto,
        category: s.category,
        signature: s.signature,
        signatureId: 9200000 + ids.length,
        description: 'Sample demonstration record — NOT a real detection',
      },
      'sample',
      { isSimulated: true, engine: 'sample-data' }
    );
    ids.push(id);
  }
  return ids;
}

module.exports = { seedSample, SAMPLE_ALERTS };
