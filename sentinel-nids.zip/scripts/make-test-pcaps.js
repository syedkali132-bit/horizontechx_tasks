'use strict';

/**
 * Generates synthetic, authorized test captures in examples/.
 * These PCAPs contain ONLY fabricated traffic between documentation
 * ranges (192.168.x.x, 203.0.113.x, 198.51.100.x) and exist solely to
 * exercise detection rules. They are not recordings of any real network.
 *
 * Usage: node scripts/make-test-pcaps.js
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const OUT = path.join(ROOT, 'examples');
const BASE_TS = 1700000000; // fixed epoch for reproducible captures

// ---------------- checksum helpers ----------------
function checksum(buf) {
  let sum = 0;
  for (let i = 0; i < buf.length; i += 2) {
    sum += (buf[i] << 8) + (i + 1 < buf.length ? buf[i + 1] : 0);
    sum = (sum & 0xffff) + (sum >> 16);
  }
  return (~sum) & 0xffff;
}

function ipToBuf(ip) {
  return Buffer.from(ip.split('.').map(Number));
}

// ---------------- packet builders ----------------
function mac(str) {
  return Buffer.from(str.split(':').map((h) => parseInt(h, 16)));
}

function ethernet(payload, { src = '02:00:00:00:00:01', dst = '02:00:00:00:00:02', type = 0x0800 } = {}) {
  const h = Buffer.alloc(14);
  mac(dst).copy(h, 0);
  mac(src).copy(h, 6);
  h.writeUInt16BE(type, 12);
  return Buffer.concat([h, payload]);
}

let ipId = 1;

function ipv4(srcIp, dstIp, proto, payload, { ttl = 64, dscp = 0 } = {}) {
  const totalLen = 20 + payload.length;
  const h = Buffer.alloc(20);
  h[0] = 0x45;
  h[1] = dscp;
  h.writeUInt16BE(totalLen, 2);
  h.writeUInt16BE((ipId++ % 65535) + 1, 4);
  h.writeUInt16BE(0x4000, 6); // DF
  h[8] = ttl;
  h[9] = proto;
  ipToBuf(srcIp).copy(h, 12);
  ipToBuf(dstIp).copy(h, 16);
  h.writeUInt16BE(checksum(h), 10);
  return Buffer.concat([h, payload]);
}

const TCP_FLAGS = { FIN: 0x01, SYN: 0x02, RST: 0x04, PSH: 0x08, ACK: 0x10, URG: 0x20 };

function tcp(srcIp, dstIp, srcPort, dstPort, { seq = 1, ack = 0, flags = ['SYN'], window = 64240, payload = Buffer.alloc(0), options = null } = {}) {
  let flagByte = 0;
  for (const f of flags) flagByte |= TCP_FLAGS[f] || 0;
  const opts = options || (flagByte & TCP_FLAGS.SYN ? Buffer.from('020405b4010303030101080a', 'hex') : Buffer.alloc(0));
  const dataOffset = 20 + opts.length;
  const h = Buffer.alloc(20);
  h.writeUInt16BE(srcPort, 0);
  h.writeUInt16BE(dstPort, 2);
  h.writeUInt32BE(seq >>> 0, 4);
  h.writeUInt32BE(ack >>> 0, 8);
  h[12] = (dataOffset / 4) << 4;
  h[13] = flagByte;
  h.writeUInt16BE(window, 14);
  const pseudo = Buffer.concat([ipToBuf(srcIp), ipToBuf(dstIp), Buffer.from([0, 6]), u16(dataOffset + payload.length)]);
  h.writeUInt16BE(checksum(Buffer.concat([pseudo, h, opts, payload])), 16);
  return Buffer.concat([h, opts, payload]);
}

function u16(n) {
  const b = Buffer.alloc(2);
  b.writeUInt16BE(n & 0xffff);
  return b;
}

function udp(srcIp, dstIp, srcPort, dstPort, payload) {
  const h = Buffer.alloc(8);
  h.writeUInt16BE(srcPort, 0);
  h.writeUInt16BE(dstPort, 2);
  h.writeUInt16BE(8 + payload.length, 4);
  const pseudo = Buffer.concat([ipToBuf(srcIp), ipToBuf(dstIp), Buffer.from([0, 17]), u16(8 + payload.length)]);
  h.writeUInt16BE(checksum(Buffer.concat([pseudo, h, payload])), 6);
  return Buffer.concat([h, payload]);
}

function icmpEcho(id, seqNo, payload, { type = 8, code = 0 } = {}) {
  const h = Buffer.alloc(8);
  h[0] = type;
  h[1] = code;
  h.writeUInt16BE(id, 4);
  h.writeUInt16BE(seqNo, 6);
  h.writeUInt16BE(checksum(Buffer.concat([h, payload])), 2);
  return Buffer.concat([h, payload]);
}

// ---------------- pcap writer ----------------
class PcapWriter {
  constructor() {
    this.records = [];
  }
  add(ts, frame) {
    const sec = Math.floor(ts);
    const usec = Math.round((ts - sec) * 1e6);
    this.records.push({ sec, usec, frame });
  }
  save(file) {
    const hdr = Buffer.alloc(24);
    hdr.writeUInt32LE(0xa1b2c3d4, 0); // magic (LE on disk = swapped read)
    hdr.writeUInt16LE(2, 4);
    hdr.writeUInt16LE(4, 6);
    hdr.writeInt32LE(0, 8);
    hdr.writeUInt32LE(0, 12);
    hdr.writeUInt32LE(65535, 16);
    hdr.writeUInt32LE(1, 20); // LINKTYPE_ETHERNET
    const parts = [hdr];
    for (const r of this.records) {
      const rec = Buffer.alloc(16);
      rec.writeUInt32LE(r.sec, 0);
      rec.writeUInt32LE(r.usec, 4);
      rec.writeUInt32LE(r.frame.length, 8);
      rec.writeUInt32LE(r.frame.length, 12);
      parts.push(rec, r.frame);
    }
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, Buffer.concat(parts));
    console.log(`  wrote ${path.relative(ROOT, file)} (${this.records.length} packets)`);
  }
}

// ---------------- scenario builders ----------------
const MACS = {
  a: '02:00:00:00:00:0a', b: '02:00:00:00:00:0b', gw: '02:00:00:00:00:01',
};

function frameIP(srcIp, dstIp, protoNum, l4, opts = {}) {
  return ethernet(ipv4(srcIp, dstIp, protoNum, l4, opts), {
    src: opts.srcMac || MACS.a,
    dst: opts.dstMac || MACS.gw,
  });
}

function buildPortScan() {
  const w = new PcapWriter();
  const attacker = '198.51.100.87';
  const target = '192.168.1.20';
  let t = BASE_TS;
  // 1) classic SYN sweep across 30 ports in ~12s (heuristic detector)
  const ports = [];
  for (let p = 20; p <= 140; p += 4) ports.push(p);
  for (let i = 0; i < 30; i++) {
    const syn = tcp(attacker, target, 40000 + i, ports[i], { seq: 1000 + i, flags: ['SYN'], window: 65535 });
    w.add(t + i * 0.4, frameIP(attacker, target, 6, syn));
    if (i % 3 === 0) {
      const rst = tcp(target, attacker, ports[i], 40000 + i, { seq: 1, ack: 1001 + i, flags: ['RST', 'ACK'] });
      w.add(t + i * 0.4 + 0.05, frameIP(target, attacker, 6, rst, { srcMac: MACS.b, dstMac: MACS.gw }));
    }
  }
  // 2) explicit NULL scan packet (all flags clear) -> sid 1000003
  const nullScan = tcp(attacker, target, 41000, 443, { seq: 5, flags: [], window: 1024, options: Buffer.alloc(0) });
  w.add(t + 13, frameIP(attacker, target, 6, nullScan));
  // 3) explicit XMAS scan packet (FIN+PSH+URG) -> sid 1000004
  const xmas = tcp(attacker, target, 41001, 443, { seq: 6, flags: ['FIN', 'PSH', 'URG'], window: 1024, options: Buffer.alloc(0) });
  w.add(t + 13.2, frameIP(attacker, target, 6, xmas));
  // 4) OS-fingerprint probe with telltale TCP options -> sid 1000005
  const osfp = tcp(attacker, target, 41002, 443, {
    seq: 7, flags: ['SYN'], window: 65535,
    options: Buffer.from('020405b4010303030101080affffffff00000000', 'hex'),
  });
  w.add(t + 13.4, frameIP(attacker, target, 6, osfp));
  return w;
}

function buildWebAttacks() {
  const w = new PcapWriter();
  const attacker = '203.0.113.54';
  const server = '192.168.1.30';
  let t = BASE_TS;
  const req = (path, ua) => Buffer.from(
    `GET ${path} HTTP/1.1\r\nHost: ${server}\r\nUser-Agent: ${ua}\r\nAccept: */*\r\nConnection: close\r\n\r\n`, 'latin1'
  );
  function httpExchange(i, path, ua) {
    const sp = 50000 + i;
    w.add(t, frameIP(attacker, server, 6, tcp(attacker, server, sp, 80, { seq: 100, flags: ['SYN'] })));
    w.add(t + 0.01, frameIP(server, attacker, 6, tcp(server, attacker, 80, sp, { seq: 200, ack: 101, flags: ['SYN', 'ACK'] }), { srcMac: MACS.b, dstMac: MACS.gw }));
    w.add(t + 0.02, frameIP(attacker, server, 6, tcp(attacker, server, sp, 80, { seq: 101, ack: 201, flags: ['ACK'] })));
    w.add(t + 0.03, frameIP(attacker, server, 6, tcp(attacker, server, sp, 80, { seq: 101, ack: 201, flags: ['PSH', 'ACK'], payload: req(path, ua) })));
    w.add(t + 0.05, frameIP(server, attacker, 6, tcp(server, attacker, 80, sp, { seq: 201, ack: 101 + req(path, ua).length, flags: ['RST', 'ACK'] }), { srcMac: MACS.b, dstMac: MACS.gw }));
    t += 2.5;
  }
  httpExchange(0, '/products?id=1 UNION SELECT username,password FROM users', 'Mozilla/5.0');
  httpExchange(1, '/download?file=../../../../etc/passwd', 'Mozilla/5.0');
  httpExchange(2, '/mirror/ubuntu.iso', 'Wget/1.21');
  httpExchange(4, '/admin/config', 'Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)');
  // benign request that should NOT alert
  httpExchange(3, '/index.html', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
  return w;
}

function buildBruteForce() {
  const w = new PcapWriter();
  const attacker = '45.155.40.12';
  const target = '192.168.1.20';
  let t = BASE_TS;
  for (let i = 0; i < 10; i++) {
    const sp = 43000 + i;
    // SYN
    w.add(t + i * 2, frameIP(attacker, target, 6, tcp(attacker, target, sp, 22, { seq: 500 + i, flags: ['SYN'] })));
    // RST|ACK refusal from server (failed connection)
    w.add(t + i * 2 + 0.02, frameIP(target, attacker, 6, tcp(target, attacker, 22, sp, { seq: 1, ack: 501 + i, flags: ['RST', 'ACK'] }), { srcMac: MACS.b, dstMac: MACS.gw }));
  }
  return w;
}

function buildMixed() {
  const w = new PcapWriter();
  const internal = '192.168.1.62';
  const dns = '192.168.1.1';
  const web = '203.0.113.80';
  let t = BASE_TS;

  // 1) normal DNS query/response
  const dnsQ = Buffer.concat([
    Buffer.from([0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]),
    Buffer.from('076578616d706c6503636f6d00', 'hex'),
    Buffer.from([0x00, 0x01, 0x00, 0x01]),
  ]);
  w.add(t, frameIP(internal, dns, 17, udp(internal, dns, 53000, 53, dnsQ)));
  const dnsA = Buffer.concat([dnsQ.subarray(0, 2), Buffer.from([0x81, 0x80, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00]), dnsQ.subarray(12), Buffer.from('c00c000100010000003c0004cb007102', 'hex')]);
  w.add(t + 0.01, frameIP(dns, internal, 17, udp(dns, internal, 53, 53000, dnsA), { srcMac: MACS.b, dstMac: MACS.gw }));
  t += 1;

  // 2) normal HTTP session with handshake + data + teardown
  const sp = 54000;
  const get = Buffer.from(`GET /index.html HTTP/1.1\r\nHost: ${web}\r\nUser-Agent: Mozilla/5.0\r\n\r\n`, 'latin1');
  const resp = Buffer.from('HTTP/1.1 200 OK\r\nContent-Length: 13\r\n\r\nHello, world!', 'latin1');
  w.add(t, frameIP(internal, web, 6, tcp(internal, web, sp, 80, { seq: 100, flags: ['SYN'] })));
  w.add(t + 0.01, frameIP(web, internal, 6, tcp(web, internal, 80, sp, { seq: 900, ack: 101, flags: ['SYN', 'ACK'] }), { srcMac: MACS.b, dstMac: MACS.gw }));
  w.add(t + 0.02, frameIP(internal, web, 6, tcp(internal, web, sp, 80, { seq: 101, ack: 901, flags: ['ACK'] })));
  w.add(t + 0.03, frameIP(internal, web, 6, tcp(internal, web, sp, 80, { seq: 101, ack: 901, flags: ['PSH', 'ACK'], payload: get })));
  w.add(t + 0.05, frameIP(web, internal, 6, tcp(web, internal, 80, sp, { seq: 901, ack: 101 + get.length, flags: ['PSH', 'ACK'], payload: resp }), { srcMac: MACS.b, dstMac: MACS.gw }));
  w.add(t + 0.07, frameIP(internal, web, 6, tcp(internal, web, sp, 80, { seq: 101 + get.length, ack: 901 + resp.length, flags: ['FIN', 'ACK'] })));
  t += 2;

  // 3) oversized ICMP echo from outside (payload 1000 bytes) -> sid 1000010
  const big = Buffer.alloc(1000, 0x61);
  w.add(t, frameIP('198.51.100.56', '192.168.1.70', 1, icmpEcho(1, 1, big)));
  w.add(t + 0.01, frameIP('192.168.1.70', '198.51.100.56', 1, icmpEcho(1, 1, big, { type: 0 }), { srcMac: MACS.b, dstMac: MACS.gw }));
  t += 1;

  // 4) oversized DNS query from outside (600 bytes) -> sid 1000011
  const bigDns = Buffer.concat([dnsQ, Buffer.alloc(600 - dnsQ.length, 0x41)]);
  w.add(t, frameIP('198.51.100.57', dns, 17, udp('198.51.100.57', dns, 53001, 53, bigDns)));
  t += 1;

  // 5) IRC C2 from internal host -> sid 1000012
  const irc = Buffer.from('PRIVMSG #c2 :beacon ok\r\n', 'latin1');
  const sp2 = 55000;
  w.add(t, frameIP('192.168.1.44', '185.220.101.4', 6, tcp('192.168.1.44', '185.220.101.4', sp2, 6667, { seq: 10, flags: ['PSH', 'ACK'], payload: irc })));
  t += 1;

  // 6) FTP anonymous attempt -> sid 1000009
  const ftpUser = Buffer.from('USER anonymous\r\n', 'latin1');
  w.add(t, frameIP('103.99.0.25', '192.168.1.25', 6, tcp('103.99.0.25', '192.168.1.25', 56000, 21, { seq: 20, flags: ['PSH', 'ACK'], payload: ftpUser })));
  t += 1;

  // 7) RDP SYN from outside -> sid 1000002
  w.add(t, frameIP('198.51.100.99', '192.168.1.15', 6, tcp('198.51.100.99', '192.168.1.15', 57000, 3389, { seq: 30, flags: ['SYN'] })));

  return w;
}

function main() {
  console.log('Generating synthetic test captures into examples/ ...');
  buildPortScan().save(path.join(OUT, 'portscan.pcap'));
  buildWebAttacks().save(path.join(OUT, 'web-attacks.pcap'));
  buildBruteForce().save(path.join(OUT, 'brute-force.pcap'));
  buildMixed().save(path.join(OUT, 'mixed-traffic.pcap'));
  console.log('Done.');
}

if (require.main === module) main();
module.exports = { buildPortScan, buildWebAttacks, buildBruteForce, buildMixed, PcapWriter, ethernet, ipv4, tcp, udp, icmpEcho, BASE_TS };
