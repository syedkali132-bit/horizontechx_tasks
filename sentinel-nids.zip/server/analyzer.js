'use strict';

/**
 * Offline PCAP analyzer.
 * Pass 1: signature matching (rule engine) + flow/conversation tracking.
 * Pass 2: behavioral heuristics computed from observed traffic statistics
 *         (port scans, failed connection bursts, connection-rate floods,
 *         large outbound transfers).
 * All output is derived exclusively from the supplied capture: nothing here
 * invents events.
 */

const FLAG_S = 0x02;
const FLAG_A = 0x10;
const FLAG_R = 0x04;
const FLAG_F = 0x01;

// canonical conversation key regardless of direction
function convKey(pkt) {
  const p1 = `${pkt.srcIp}:${pkt.srcPort ?? 0}`;
  const p2 = `${pkt.dstIp}:${pkt.dstPort ?? 0}`;
  return `${pkt.proto}|${[p1, p2].sort().join('|')}`;
}

function analyze(capture, ruleSet, opts = {}) {
  const h = opts.heuristics || {};
  const packets = capture.packets.filter((p) => p && p.srcIp && p.dstIp && !p.unsupportedLinkType && !p.unsupportedEtherType);
  const signatureAlerts = [];
  const flows = new Map();
  const malformed = capture.packets.length - packets.length;
  let minTs = null;
  let maxTs = null;

  for (const pkt of packets) {
    if (minTs === null || pkt.tsSec < minTs) minTs = pkt.tsSec;
    if (maxTs === null || pkt.tsSec > maxTs) maxTs = pkt.tsSec;
    // flow accounting
    const key = convKey(pkt);
    let f = flows.get(key);
    if (!f) {
      f = {
        proto: pkt.proto,
        a: `${pkt.srcIp}:${pkt.srcPort ?? 0}`,
        b: `${pkt.dstIp}:${pkt.dstPort ?? 0}`,
        srcIp: pkt.srcIp, dstIp: pkt.dstIp,
        srcPort: pkt.srcPort ?? null, dstPort: pkt.dstPort ?? null,
        packets: 0, bytes: 0, payloadBytes: 0,
        startTs: pkt.tsSec, endTs: pkt.tsSec,
        syn: 0, rst: 0, fin: 0, ack: 0, icmpTypes: {},
        payloadPreview: '',
      };
      flows.set(key, f);
    }
    f.packets++;
    f.bytes += pkt.origLen || 0;
    f.endTs = Math.max(f.endTs, pkt.tsSec);
    f.startTs = Math.min(f.startTs, pkt.tsSec);
    if (pkt.payload && pkt.payload.length) {
      f.payloadBytes += pkt.payload.length;
      if (!f.payloadPreview) {
        f.payloadPreview = printablePreview(pkt.payload);
      }
    }
    if (pkt.tcp) {
      if (pkt.tcp.flags & FLAG_S) f.syn++;
      if (pkt.tcp.flags & FLAG_R) f.rst++;
      if (pkt.tcp.flags & FLAG_F) f.fin++;
      if (pkt.tcp.flags & FLAG_A) f.ack++;
    }
    if (pkt.icmp) {
      const t = String(pkt.icmp.type);
      f.icmpTypes[t] = (f.icmpTypes[t] || 0) + 1;
    }

    // signature pass
    if (pkt.malformed) continue;
    for (const match of ruleSet.matchPacket(pkt)) {
      signatureAlerts.push({
        ts: pkt.tsSec,
        severity: match.rule.severity,
        srcIp: pkt.srcIp,
        srcPort: pkt.srcPort ?? null,
        dstIp: pkt.dstIp,
        dstPort: pkt.dstPort ?? null,
        proto: pkt.proto,
        category: match.rule.category,
        signature: match.rule.msg,
        signatureId: match.rule.sid,
        gid: match.rule.gid || 1,
        rev: match.rule.rev || 1,
        classtype: match.rule.classtype,
        ruleSource: `${match.rule.file}:${match.rule.line}`,
        payloadPreview: pkt.payload && pkt.payload.length ? printablePreview(pkt.payload) : '',
        thresholdCount: match.thresholdCount,
      });
    }
  }

  const heuristicAlerts = runHeuristics(packets, flows, h);

  return {
    summary: {
      totalPackets: capture.packets.length,
      decodedPackets: packets.length,
      malformedPackets: malformed,
      flows: flows.size,
      signatureAlerts: signatureAlerts.length,
      heuristicAlerts: heuristicAlerts.length,
      firstTs: minTs,
      lastTs: maxTs,
    },
    signatureAlerts,
    heuristicAlerts,
    flows: [...flows.values()].map((f) => ({
      ...f,
      duration: f.endTs - f.startTs,
    })),
  };
}

function runHeuristics(packets, flows, h) {
  const alerts = [];
  const {
    portScanDistinctPorts = 15,
    portScanWindowSec = 60,
    failedConnThreshold = 8,
    failedConnWindowSec = 120,
    connRateThreshold = 120,
    connRateWindowSec = 60,
    exfilBytes = 50000000,
  } = h;

  // ---- TCP/UDP port scan: many distinct destination ports, few completions ----
  const scannerMap = new Map(); // src -> { dst -> Map(port->firstTs) }
  for (const pkt of packets) {
    if (pkt.proto !== 'tcp' && pkt.proto !== 'udp') continue;
    if (pkt.proto === 'tcp' && !(pkt.tcp && (pkt.tcp.flags & FLAG_S) && !(pkt.tcp.flags & FLAG_A))) continue; // SYN only
    let byDst = scannerMap.get(pkt.srcIp);
    if (!byDst) scannerMap.set(pkt.srcIp, (byDst = new Map()));
    let ports = byDst.get(pkt.dstIp);
    if (!ports) byDst.set(pkt.dstIp, (ports = new Map()));
    if (!ports.has(pkt.dstPort)) ports.set(pkt.dstPort, pkt.tsSec);
  }
  for (const [srcIp, byDst] of scannerMap) {
    for (const [dstIp, ports] of byDst) {
      const entries = [...ports.entries()].sort((a, b) => a[1] - b[1]);
      let winStart = 0;
      for (let i = 0; i < entries.length; i++) {
        if (entries[i][1] - entries[winStart][1] > portScanWindowSec) winStart = i;
        const distinct = i - winStart + 1;
        if (distinct >= portScanDistinctPorts) {
          let completed = 0;
          for (const f of flows.values()) {
            if (f.srcIp === srcIp && f.dstIp === dstIp && f.ack > 0) completed++;
          }
          alerts.push({
            ts: entries[i][1],
            severity: 'high',
            srcIp,
            srcPort: null,
            dstIp,
            dstPort: null,
            proto: 'tcp',
            category: 'Attempted Reconnaissance',
            signature: `HEURISTIC TCP/UDP port sweep: ${distinct} distinct destination ports contacted within ${portScanWindowSec}s`,
            signatureId: 9000001,
            gid: 1,
            heuristic: 'port_scan',
            evidence: { distinctPorts: distinct, windowSec: entries[i][1] - entries[winStart][1], completedHandshakes: completed },
          });
          break; // one alert per (src,dst) pair is enough
        }
      }
    }
  }

  // ---- Repeated failed connection attempts: RST responses from one service ----
  const failures = new Map(); // key requester|responder|servicePort -> [ts...]
  for (const pkt of packets) {
    if (pkt.proto !== 'tcp' || !pkt.tcp) continue;
    if (!(pkt.tcp.flags & FLAG_R)) continue;
    const reqKey = `${pkt.dstIp}|${pkt.srcIp}|${pkt.tcp.srcPort}`;
    let arr = failures.get(reqKey);
    if (!arr) failures.set(reqKey, (arr = []));
    arr.push(pkt.tsSec);
  }
  for (const [key, times] of failures) {
    times.sort((a, b) => a - b);
    let winStart = 0;
    for (let i = 0; i < times.length; i++) {
      while (times[i] - times[winStart] > failedConnWindowSec) winStart++;
      const count = i - winStart + 1;
      if (count >= failedConnThreshold) {
        const [srcIp, dstIp, dstPort] = key.split('|');
        alerts.push({
          ts: times[i],
          severity: 'medium',
          srcIp,
          srcPort: null,
          dstIp,
          dstPort: Number(dstPort),
          proto: 'tcp',
          category: 'Potentially Bad Traffic',
          signature: `HEURISTIC repeated failed connection attempts: ${count} rejected connections within ${failedConnWindowSec}s`,
          signatureId: 9000002,
          gid: 1,
          heuristic: 'failed_connections',
          evidence: { attempts: count, windowSec: times[i] - times[winStart] },
        });
        break;
      }
    }
  }

  // ---- Connection-rate flood: new conversations per source in a window ----
  const firstSeen = new Map(); // src -> sorted unique flow-start timestamps
  for (const f of flows.values()) {
    let arr = firstSeen.get(f.srcIp);
    if (!arr) firstSeen.set(f.srcIp, (arr = []));
    arr.push(f.startTs);
  }
  for (const [srcIp, times] of firstSeen) {
    times.sort((a, b) => a - b);
    let winStart = 0;
    for (let i = 0; i < times.length; i++) {
      while (times[i] - times[winStart] > connRateWindowSec) winStart++;
      const count = i - winStart + 1;
      if (count >= connRateThreshold) {
        alerts.push({
          ts: times[i],
          severity: 'medium',
          srcIp,
          srcPort: null,
          dstIp: null,
          dstPort: null,
          proto: 'ip',
          category: 'Potentially Bad Traffic',
          signature: `HEURISTIC connection flood: ${count} new conversations initiated within ${connRateWindowSec}s`,
          signatureId: 9000003,
          gid: 1,
          heuristic: 'conn_flood',
          evidence: { newConversations: count, windowSec: times[i] - times[winStart] },
        });
        break;
      }
    }
  }

  // ---- Large outbound transfer (possible exfiltration) ----
  for (const f of flows.values()) {
    if (f.payloadBytes >= exfilBytes) {
      alerts.push({
        ts: f.endTs,
        severity: 'medium',
        srcIp: f.srcIp,
        srcPort: f.srcPort,
        dstIp: f.dstIp,
        dstPort: f.dstPort,
        proto: f.proto,
        category: 'Potentially Bad Traffic',
        signature: `HEURISTIC large data transfer: ${formatBytes(f.payloadBytes)} of payload in one conversation`,
        signatureId: 9000004,
        gid: 1,
        heuristic: 'exfil',
        evidence: { payloadBytes: f.payloadBytes, packets: f.packets },
      });
    }
  }

  return alerts;
}

function printablePreview(buf, max = 96) {
  const slice = buf.subarray(0, max);
  let out = '';
  for (const b of slice) {
    out += b >= 32 && b < 127 ? String.fromCharCode(b) : '.';
  }
  return out;
}

function formatBytes(n) {
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)} GB`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)} MB`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)} KB`;
  return `${n} B`;
}

module.exports = { analyze, convKey, formatBytes };
