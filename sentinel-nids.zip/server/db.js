'use strict';

const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS alerts (
  id TEXT PRIMARY KEY,
  ts INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  severity TEXT NOT NULL CHECK (severity IN ('low','medium','high','critical')),
  src_ip TEXT,
  src_port INTEGER,
  dst_ip TEXT,
  dst_port INTEGER,
  proto TEXT,
  category TEXT,
  signature TEXT NOT NULL,
  signature_id INTEGER,
  gid INTEGER,
  rev INTEGER,
  classtype TEXT,
  description TEXT,
  source TEXT NOT NULL CHECK (source IN ('live','pcap','simulated','sample')),
  is_simulated INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','acknowledged','resolved')),
  engine TEXT,
  pcap_file TEXT,
  rule_source TEXT,
  payload_preview TEXT,
  evidence TEXT,
  threshold_count INTEGER
);
CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(ts DESC);
CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_alerts_src ON alerts(src_ip);
CREATE INDEX IF NOT EXISTS idx_alerts_source ON alerts(source);

CREATE TABLE IF NOT EXISTS notes (
  id TEXT PRIMARY KEY,
  alert_id TEXT NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
  author TEXT NOT NULL DEFAULT 'analyst',
  note TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_notes_alert ON notes(alert_id);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  ts INTEGER NOT NULL,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  target TEXT,
  detail TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts DESC);

CREATE TABLE IF NOT EXISTS flows (
  id TEXT PRIMARY KEY,
  pcap_file TEXT NOT NULL,
  proto TEXT,
  src_ip TEXT, src_port INTEGER,
  dst_ip TEXT, dst_port INTEGER,
  packets INTEGER NOT NULL DEFAULT 0,
  bytes INTEGER NOT NULL DEFAULT 0,
  payload_bytes INTEGER NOT NULL DEFAULT 0,
  start_ts INTEGER, end_ts INTEGER, duration INTEGER,
  syn INTEGER DEFAULT 0, rst INTEGER DEFAULT 0, fin INTEGER DEFAULT 0, ack INTEGER DEFAULT 0,
  payload_preview TEXT
);
CREATE INDEX IF NOT EXISTS idx_flows_pcap ON flows(pcap_file);
CREATE INDEX IF NOT EXISTS idx_flows_src ON flows(src_ip);
CREATE INDEX IF NOT EXISTS idx_flows_bytes ON flows(bytes DESC);

CREATE TABLE IF NOT EXISTS pcap_files (
  name TEXT PRIMARY KEY,
  original_name TEXT,
  size_bytes INTEGER,
  analyzed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  analyzed_by TEXT,
  engine TEXT,
  packet_count INTEGER,
  decoded_packets INTEGER,
  flow_count INTEGER,
  alert_count INTEGER,
  first_ts INTEGER, last_ts INTEGER
);

CREATE TABLE IF NOT EXISTS notifications_log (
  id TEXT PRIMARY KEY,
  ts INTEGER NOT NULL,
  alert_id TEXT,
  channel TEXT NOT NULL,
  target TEXT,
  ok INTEGER NOT NULL,
  detail TEXT
);
`;

class Db {
  constructor(dataDir) {
    fs.mkdirSync(dataDir, { recursive: true });
    this.path = path.join(dataDir, 'nids.db');
    this.db = new DatabaseSync(this.path);
    this.db.exec('PRAGMA journal_mode = WAL;');
    this.db.exec('PRAGMA foreign_keys = ON;');
    this.db.exec(SCHEMA);
  }

  tx(fn) {
    this._txDepth = this._txDepth || 0;
    if (this._txDepth > 0) {
      // already inside a transaction: join it, let the outer frame commit/rollback
      this._txDepth++;
      try { return fn(); } finally { this._txDepth--; }
    }
    this._txDepth = 1;
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const r = fn();
      this.db.exec('COMMIT');
      return r;
    } catch (err) {
      try { this.db.exec('ROLLBACK'); } catch { /* already rolled back */ }
      throw err;
    } finally {
      this._txDepth = 0;
    }
  }

  insertAlert(a) {
    const id = a.id;
    this.db.prepare(
      `INSERT INTO alerts (id, ts, severity, src_ip, src_port, dst_ip, dst_port, proto, category, signature,
        signature_id, gid, rev, classtype, description, source, is_simulated, engine, pcap_file, rule_source,
        payload_preview, evidence, threshold_count)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(
      id, a.ts, a.severity, a.srcIp ?? null, a.srcPort ?? null, a.dstIp ?? null, a.dstPort ?? null,
      a.proto ?? null, a.category ?? null, a.signature, a.signatureId ?? null, a.gid ?? null,
      a.rev ?? null, a.classtype ?? null, a.description ?? null, a.source, a.isSimulated ? 1 : 0,
      a.engine ?? null, a.pcapFile ?? null, a.ruleSource ?? null, a.payloadPreview ?? null,
      a.evidence ? JSON.stringify(a.evidence) : null, a.thresholdCount ?? null
    );
    return id;
  }

  getAlert(id) {
    return this.db.prepare('SELECT * FROM alerts WHERE id = ?').get(id);
  }

  listAlerts(q) {
    const where = [];
    const params = [];
    if (q.severity) {
      const sevs = String(q.severity).split(',').filter((s) => ['low', 'medium', 'high', 'critical'].includes(s));
      if (sevs.length) {
        where.push(`severity IN (${sevs.map(() => '?').join(',')})`);
        params.push(...sevs);
      }
    }
    if (q.status && ['new', 'acknowledged', 'resolved'].includes(q.status)) {
      where.push('status = ?');
      params.push(q.status);
    }
    if (q.source && ['live', 'pcap', 'simulated', 'sample'].includes(q.source)) {
      where.push('source = ?');
      params.push(q.source);
    }
    if (q.from && Number.isInteger(Number(q.from))) {
      where.push('ts >= ?');
      params.push(Number(q.from));
    }
    if (q.to && Number.isInteger(Number(q.to))) {
      where.push('ts <= ?');
      params.push(Number(q.to));
    }
    if (q.q) {
      const like = `%${String(q.q).slice(0, 100)}%`;
      where.push('(signature LIKE ? OR src_ip LIKE ? OR dst_ip LIKE ? OR category LIKE ? OR CAST(signature_id AS TEXT) LIKE ?)');
      params.push(like, like, like, like, like);
    }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const sortable = {
      ts: 'ts',
      severity: `CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END`,
      src_ip: 'src_ip', dst_ip: 'dst_ip', proto: 'proto', status: 'status', source: 'source',
    };
    const sortCol = sortable[q.sort] || 'ts';
    const dir = q.dir === 'asc' ? 'ASC' : 'DESC';
    const page = Math.max(1, Number(q.page) || 1);
    const perPage = Math.min(200, Math.max(5, Number(q.perPage) || 25));
    const total = this.db.prepare(`SELECT COUNT(*) AS c FROM alerts ${whereSql}`).get(...params).c;
    const rows = this.db.prepare(
      `SELECT * FROM alerts ${whereSql} ORDER BY ${sortCol} ${dir}, ts DESC LIMIT ? OFFSET ?`
    ).all(...params, perPage, (page - 1) * perPage);
    return { rows, total, page, perPage };
  }

  setAlertStatus(id, status, actor, note) {
    this.tx(() => {
      this.db.prepare('UPDATE alerts SET status = ? WHERE id = ?').run(status, id);
      if (note) {
        this.db.prepare('INSERT INTO notes (id, alert_id, author, note) VALUES (?,?,?,?)')
          .run(`n-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`, id, actor, note);
      }
    });
  }

  addNote(id, alertId, author, note) {
    this.db.prepare('INSERT INTO notes (id, alert_id, author, note) VALUES (?,?,?,?)').run(id, alertId, author, note);
  }

  listNotes(alertId) {
    return this.db.prepare('SELECT * FROM notes WHERE alert_id = ? ORDER BY created_at ASC').all(alertId);
  }

  audit(entry) {
    this.db.prepare('INSERT INTO audit_log (id, ts, actor, action, target, detail) VALUES (?,?,?,?,?,?)')
      .run(entry.id, entry.ts, entry.actor, entry.action, entry.target ?? null, entry.detail ? JSON.stringify(entry.detail) : null);
  }

  listAudit(limit = 200) {
    return this.db.prepare('SELECT * FROM audit_log ORDER BY ts DESC LIMIT ?').all(limit);
  }

  replaceFlows(pcapFile, flows) {
    this.tx(() => {
      this.db.prepare('DELETE FROM flows WHERE pcap_file = ?').run(pcapFile);
      const stmt = this.db.prepare(
        `INSERT INTO flows (id, pcap_file, proto, src_ip, src_port, dst_ip, dst_port, packets, bytes, payload_bytes,
          start_ts, end_ts, duration, syn, rst, fin, ack, payload_preview)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
      );
      for (const f of flows) {
        stmt.run(
          `f-${Math.random().toString(16).slice(2, 10)}-${Date.now() % 100000}`, pcapFile, f.proto,
          f.srcIp ?? null, f.srcPort ?? null, f.dstIp ?? null, f.dstPort ?? null,
          f.packets, f.bytes, f.payloadBytes, f.startTs, f.endTs, f.duration ?? 0,
          f.syn, f.rst, f.fin, f.ack, f.payloadPreview ?? null
        );
      }
    });
  }

  upsertPcapFile(meta) {
    this.db.prepare(
      `INSERT INTO pcap_files (name, original_name, size_bytes, analyzed_by, engine, packet_count, decoded_packets, flow_count, alert_count, first_ts, last_ts)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)
       ON CONFLICT(name) DO UPDATE SET
         analyzed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'),
         size_bytes = excluded.size_bytes, analyzed_by = excluded.analyzed_by, engine = excluded.engine,
         packet_count = excluded.packet_count, decoded_packets = excluded.decoded_packets,
         flow_count = excluded.flow_count, alert_count = excluded.alert_count,
         first_ts = excluded.first_ts, last_ts = excluded.last_ts`
    ).run(meta.name, meta.originalName ?? meta.name, meta.sizeBytes ?? null, meta.analyzedBy ?? 'builtin',
      meta.engine ?? 'builtin', meta.packetCount ?? null, meta.decodedPackets ?? null,
      meta.flowCount ?? null, meta.alertCount ?? null, meta.firstTs ?? null, meta.lastTs ?? null);
  }

  listPcapFiles() {
    return this.db.prepare('SELECT * FROM pcap_files ORDER BY analyzed_at DESC').all();
  }

  listFlows(q) {
    const where = [];
    const params = [];
    if (q.pcap && /^[\w.\-]+$/.test(q.pcap)) {
      where.push('pcap_file = ?');
      params.push(q.pcap);
    }
    if (q.proto && ['tcp', 'udp', 'icmp', 'ip'].includes(q.proto)) {
      where.push('proto = ?');
      params.push(q.proto);
    }
    if (q.q) {
      const like = `%${String(q.q).slice(0, 80)}%`;
      where.push('(src_ip LIKE ? OR dst_ip LIKE ?)');
      params.push(like, like);
    }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const total = this.db.prepare(`SELECT COUNT(*) AS c FROM flows ${whereSql}`).get(...params).c;
    const rows = this.db.prepare(`SELECT * FROM flows ${whereSql} ORDER BY bytes DESC LIMIT 300`).all(...params);
    return { rows, total };
  }

  logNotification(entry) {
    this.db.prepare('INSERT INTO notifications_log (id, ts, alert_id, channel, target, ok, detail) VALUES (?,?,?,?,?,?,?)')
      .run(entry.id, entry.ts, entry.alertId ?? null, entry.channel, entry.target ?? null, entry.ok ? 1 : 0, entry.detail ?? null);
  }

  statsOverview() {
    const bySeverity = this.db.prepare('SELECT severity, COUNT(*) AS c FROM alerts GROUP BY severity').all();
    const byProto = this.db.prepare('SELECT proto, COUNT(*) AS c FROM alerts GROUP BY proto').all();
    const byStatus = this.db.prepare('SELECT status, COUNT(*) AS c FROM alerts GROUP BY status').all();
    const bySource = this.db.prepare('SELECT source, COUNT(*) AS c FROM alerts GROUP BY source').all();
    const total = this.db.prepare('SELECT COUNT(*) AS c FROM alerts').get().c;
    const newCount = this.db.prepare(`SELECT COUNT(*) AS c FROM alerts WHERE status = 'new'`).get().c;
    const trend = this.db.prepare(
      `SELECT (ts/3600)*3600 AS bucket, COUNT(*) AS c FROM alerts WHERE ts >= ? GROUP BY bucket ORDER BY bucket ASC`
    ).all(Math.floor(Date.now() / 1000) - 24 * 3600);
    const topSrc = this.db.prepare(
      `SELECT src_ip AS ip, COUNT(*) AS c FROM alerts WHERE src_ip IS NOT NULL GROUP BY src_ip ORDER BY c DESC LIMIT 10`
    ).all();
    const topDst = this.db.prepare(
      `SELECT dst_ip AS ip, COUNT(*) AS c FROM alerts WHERE dst_ip IS NOT NULL GROUP BY dst_ip ORDER BY c DESC LIMIT 10`
    ).all();
    const recent = this.db.prepare('SELECT * FROM alerts ORDER BY ts DESC LIMIT 8').all();
    const topTalkers = this.db.prepare(
      `SELECT src_ip AS ip, SUM(bytes) AS bytes, SUM(packets) AS packets FROM flows GROUP BY src_ip ORDER BY bytes DESC LIMIT 10`
    ).all();
    const flowTotals = this.db.prepare('SELECT COUNT(*) AS flows, COALESCE(SUM(bytes),0) AS bytes, COALESCE(SUM(packets),0) AS packets FROM flows').get();
    return { total, newCount, bySeverity, byProto, byStatus, bySource, trend, topSrc, topDst, recent, topTalkers, flowTotals };
  }

  purgeOldAlerts(days) {
    const cutoff = Math.floor(Date.now() / 1000) - days * 86400;
    const res = this.db.prepare('DELETE FROM alerts WHERE ts < ?').run(cutoff);
    return res.changes;
  }

  close() {
    this.db.close();
  }
}

module.exports = { Db };
