'use strict';

const path = require('path');
const fs = require('fs');
const express = require('express');
const { loadConfig } = require('./config');
const { Db } = require('./db');
const { loadRuleSet } = require('./ruleEngine');
const { Monitor } = require('./monitor');
const { loadOrCreateToken, requireAuth } = require('./auth');
const notify = require('./notify');
const { createApi } = require('./routes/api');

function abs(config, p) {
  return path.isAbsolute(p) ? p : path.join(config.ROOT, p);
}

async function main() {
  const config = loadConfig();
  config.dataDirAbs = abs(config, config.dataDir);
  config.watchDirAbs = abs(config, config.monitor.watchDir);
  config.uploadsDirAbs = path.join(config.dataDirAbs, 'uploads');
  fs.mkdirSync(config.uploadsDirAbs, { recursive: true });
  fs.mkdirSync(path.join(config.dataDirAbs, 'logs'), { recursive: true });

  const db = new Db(config.dataDirAbs);
  const tokenInfo = loadOrCreateToken(config.dataDirAbs);

  const rulesDirs = [
    path.join(config.ROOT, 'config', 'rules'),
  ];
  const ruleSetHolder = {
    dirs: rulesDirs,
    _rs: loadRuleSet(config.vars, rulesDirs),
    get() { return this._rs; },
    set(rs) { this._rs = rs; },
  };
  if (ruleSetHolder.get().errors.length) {
    console.warn('[nids] rule load errors:');
    for (const e of ruleSetHolder.get().errors) console.warn(`  ${e.file}:${e.line} ${e.error}`);
  }

  const monitor = new Monitor({
    config,
    db,
    ruleSetHolder,
    notify: (alert) => notify.dispatch(db, config, alert),
    log: console,
  });
  await monitor.refreshCapabilities();

  // retention sweep
  const purged = db.purgeOldAlerts(config.retention.alertsDays);

  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '1mb' }));
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    next();
  });

  const auth = requireAuth(() => tokenInfo.token);
  app.use('/api', createApi({ config, db, monitor, auth, ruleSetHolder, tokenInfo }));

  app.use(express.static(path.join(config.ROOT, 'public'), { index: 'index.html', maxAge: '5m' }));

  app.use('/api', (req, res) => res.status(404).json({ error: 'unknown API endpoint' }));
  app.use((err, req, res, next) => {
    if (err && err.type === 'entity.too.large') {
      return res.status(413).json({ error: 'payload too large' });
    }
    console.error('[nids] unhandled error:', err);
    res.status(500).json({ error: 'internal server error' });
  });

  const server = app.listen(config.port, config.host, () => {
    console.log('');
    console.log('  Sentinel NIDS');
    console.log('  ─────────────────────────────────────────────');
    console.log(`  Dashboard:      http://${config.host}:${config.port}`);
    console.log(`  Data directory: ${config.dataDirAbs}`);
    console.log(`  Rules loaded:   ${ruleSetHolder.get().size} (${ruleSetHolder.get().errors.length} errors)`);
    const caps = monitor.capabilities;
    if (caps) {
      console.log(`  Suricata:       ${caps.suricata.installed ? `found (${caps.suricata.version})` : 'not installed'}`);
      console.log(`  Snort:          ${caps.snort.installed ? `found (${caps.snort.version})` : 'not installed'}`);
    }
    if (purged > 0) console.log(`  Purged ${purged} alerts older than ${config.retention.alertsDays} days`);
    console.log('');
    if (tokenInfo.source === 'generated') {
      console.log(`  Admin token (saved to ${path.join(config.dataDirAbs, '.admin-token')}):`);
      console.log(`    ${tokenInfo.token}`);
      console.log('');
      console.log('  Set NIDS_ADMIN_TOKEN to provide your own token.');
    } else {
      console.log(`  Admin token source: ${tokenInfo.source}`);
    }
    console.log('');
  });

  const shutdown = () => {
    console.log('\n[nids] shutting down...');
    monitor.stop('shutdown');
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  return { app, server, config, db, monitor };
}

if (require.main === module) {
  main().catch((err) => {
    console.error('[nids] fatal startup error:', err.message);
    process.exit(1);
  });
}

module.exports = { main };
