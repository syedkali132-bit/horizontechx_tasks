'use strict';

const express = require('express');
const fs = require('fs');
const path = require('path');
const { loadRuleSet } = require('../ruleEngine');
const { recommendationsFor } = require('../recommendations');
const { PcapError } = require('../pcapParser');
const { safeId } = require('../util');

const MAX_UPLOAD_BYTES = 256 * 1024 * 1024; // 256 MB PCAP ceiling

function createApi(deps) {
  const { config, db, monitor, auth, ruleSetHolder, tokenInfo } = deps;
  const router = express.Router();

  const now = () => Math.floor(Date.now() / 1000);

  // ---------- read-only endpoints ----------
  router.get('/status', (req, res) => {
    res.json({
      ok: true,
      serverTime: new Date().toISOString(),
      monitor: monitor.status(),
      config: {
        host: config.host,
        port: config.port,
        homeNet: config.network.homeNet,
        watchDir: config.monitor.watchDir,
        retentionDays: config.retention.alertsDays,
        notifications: { minSeverity: config.notifications.minSeverity, webhookConfigured: Boolean(config.notifications.webhookUrl) },
      },
      auth: { requiredFor: 'mutations', tokenSource: tokenInfo.source },
    });
  });

  router.get('/stats/overview', (req, res) => {
    res.json(db.statsOverview());
  });

  router.get('/alerts', (req, res) => {
    res.json(db.listAlerts(req.query));
  });

  router.get('/alerts/:id', (req, res) => {
    const alert = db.getAlert(req.params.id);
    if (!alert) return res.status(404).json({ error: 'alert not found' });
    res.json({ alert, notes: db.listNotes(alert.id), recommendations: recommendationsFor(alert.category) });
  });

  router.get('/rules', (req, res) => {
    res.json(ruleSetHolder.get().listPublic());
  });

  router.get('/pcaps', (req, res) => {
    res.json({ files: db.listPcapFiles() });
  });

  router.get('/traffic/flows', (req, res) => {
    res.json(db.listFlows(req.query));
  });

  router.get('/recommendations/:category', (req, res) => {
    res.json({ category: req.params.category, actions: recommendationsFor(req.params.category) });
  });

  // ---------- authenticated endpoints ----------
  router.post('/alerts/:id/status', auth, (req, res) => {
    const { status, note } = req.body || {};
    if (!['new', 'acknowledged', 'resolved'].includes(status)) {
      return res.status(400).json({ error: 'status must be one of new, acknowledged, resolved' });
    }
    if (note !== undefined && typeof note !== 'string') {
      return res.status(400).json({ error: 'note must be a string' });
    }
    const alert = db.getAlert(req.params.id);
    if (!alert) return res.status(404).json({ error: 'alert not found' });
    db.setAlertStatus(alert.id, status, 'analyst', note && note.trim() ? note.trim() : null);
    db.audit({ id: `a-${now()}-${safeId().slice(0, 6)}`, ts: now(), actor: 'analyst', action: `alert-${status}`, target: alert.id, detail: { signature: alert.signature, note: note || null } });
    res.json({ ok: true, alert: db.getAlert(alert.id) });
  });

  router.post('/alerts/:id/notes', auth, (req, res) => {
    const { note } = req.body || {};
    if (typeof note !== 'string' || !note.trim() || note.length > 4000) {
      return res.status(400).json({ error: 'note must be a non-empty string (max 4000 chars)' });
    }
    const alert = db.getAlert(req.params.id);
    if (!alert) return res.status(404).json({ error: 'alert not found' });
    const id = `n-${now()}-${safeId().slice(0, 6)}`;
    db.addNote(id, alert.id, 'analyst', note.trim());
    db.audit({ id: `a-${now()}-${safeId().slice(0, 6)}`, ts: now(), actor: 'analyst', action: 'alert-note', target: alert.id, detail: { note: note.trim().slice(0, 200) } });
    res.json({ ok: true, notes: db.listNotes(alert.id) });
  });

  router.get('/audit', auth, (req, res) => {
    res.json({ entries: db.listAudit(Math.min(500, Number(req.query.limit) || 200)) });
  });

  router.post('/monitor/start', auth, async (req, res) => {
    const mode = (req.body && req.body.mode) || 'dropzone';
    try {
      const result = await monitor.start(mode, 'analyst');
      if (!result.ok) return res.status(400).json({ error: result.error });
      res.json({ ok: true, ...result, status: monitor.status() });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/monitor/stop', auth, (req, res) => {
    const result = monitor.stop('analyst');
    if (!result.ok) return res.status(400).json({ error: result.error });
    db.audit({ id: `a-${now()}-${safeId().slice(0, 6)}`, ts: now(), actor: 'analyst', action: 'monitor-stop', target: result.mode, detail: null });
    res.json({ ok: true, ...result, status: monitor.status() });
  });

  router.post('/rules/reload', auth, (req, res) => {
    const rs = loadRuleSet(config.vars, ruleSetHolder.dirs);
    ruleSetHolder.set(rs);
    db.audit({ id: `a-${now()}-${safeId().slice(0, 6)}`, ts: now(), actor: 'analyst', action: 'rules-reload', target: null, detail: { loaded: rs.size, errors: rs.errors.length } });
    res.json({ ok: true, loaded: rs.size, errors: rs.errors, status: monitor.status() });
  });

  // PCAP upload: raw body, query param ?name=foo.pcap
  router.post('/pcaps', auth, express.raw({ type: () => true, limit: MAX_UPLOAD_BYTES }), async (req, res) => {
    try {
      let name = String(req.query.name || 'upload.pcap');
      name = path.basename(name).replace(/[^\w.\-]/g, '_');
      if (!/\.(pcap|pcapng)$/i.test(name)) name += '.pcap';
      if (!Buffer.isBuffer(req.body) || req.body.length < 24) {
        return res.status(400).json({ error: 'empty or truncated upload — expected a libpcap/pcapng file' });
      }
      const dir = config.uploadsDirAbs;
      fs.mkdirSync(dir, { recursive: true });
      const stored = `${Date.now()}-${safeId().slice(0, 6)}-${name}`;
      const full = path.join(dir, stored);
      fs.writeFileSync(full, req.body);
      let result;
      try {
        result = await monitor.analyzePcapFile(full, { engine: 'builtin', actor: 'upload' });
        monitor.markAnalyzed(stored); // prevent drop-zone double-analysis
      } catch (err) {
        try { fs.unlinkSync(full); } catch { /* keep for debugging */ }
        throw err;
      }
      db.audit({ id: `a-${now()}-${safeId().slice(0, 6)}`, ts: now(), actor: 'analyst', action: 'pcap-upload', target: stored, detail: result });
      res.json({ ok: true, file: stored, ...result });
    } catch (err) {
      if (err instanceof PcapError) {
        return res.status(422).json({ error: err.message });
      }
      res.status(500).json({ error: err.message });
    }
  });

  // Import an external engine log (Suricata EVE or Snort fast format).
  router.post('/logs/import', auth, express.text({ type: () => true, limit: 32 * 1024 * 1024 }), (req, res) => {
    const kind = String(req.query.kind || 'eve');
    if (!Buffer.isBuffer(req.body) && typeof req.body !== 'string') {
      return res.status(400).json({ error: 'expected plain-text log body' });
    }
    const text = Buffer.isBuffer(req.body) ? req.body.toString('utf8') : req.body;
    const { parseEveLine, parseFastLine } = require('../engine');
    const parser = kind === 'fast' ? parseFastLine : parseEveLine;
    let count = 0;
    let skipped = 0;
    for (const line of text.split('\n')) {
      const a = parser(line);
      if (a) {
        monitor.ingest(a, 'live', { engine: kind === 'fast' ? 'snort-import' : 'suricata-import', actor: 'analyst' });
        count++;
      } else if (line.trim()) {
        skipped++;
      }
    }
    db.audit({ id: `a-${now()}-${safeId().slice(0, 6)}`, ts: now(), actor: 'analyst', action: 'log-import', target: kind, detail: { ingested: count, skipped } });
    res.json({ ok: true, ingested: count, skipped });
  });

  // Clearly-labeled SIMULATED events for UI demonstration when no traffic exists.
  router.post('/simulate', auth, (req, res) => {
    const scenario = (req.body && req.body.scenario) || 'portscan';
    const base = now() - 300;
    const templates = {
      portscan: [
        { ts: base, severity: 'high', srcIp: '198.51.100.23', dstIp: '192.168.1.10', proto: 'tcp', category: 'Attempted Reconnaissance', signature: 'SIMULATED Nmap SYN scan against workstation subnet', signatureId: 9100001 },
        { ts: base + 4, severity: 'medium', srcIp: '198.51.100.23', dstIp: '192.168.1.11', proto: 'tcp', category: 'Attempted Reconnaissance', signature: 'SIMULATED follow-up SYN probe on adjacent host', signatureId: 9100002 },
      ],
      bruteforce: [
        { ts: base, severity: 'critical', srcIp: '203.0.113.77', srcPort: 40001, dstIp: '192.168.1.20', dstPort: 22, proto: 'tcp', category: 'Attempted Administrator Privilege Gain', signature: 'SIMULATED SSH brute force burst (20 attempts / 60s)', signatureId: 9100003 },
      ],
      c2: [
        { ts: base, severity: 'critical', srcIp: '192.168.1.44', srcPort: 51500, dstIp: '203.0.113.200', dstPort: 6667, proto: 'tcp', category: 'A Network Trojan was Detected', signature: 'SIMULATED periodic beacon to IRC-like C2 channel', signatureId: 9100004 },
      ],
    };
    const picked = templates[scenario];
    if (!picked) {
      return res.status(400).json({ error: `unknown scenario "${scenario}" (available: ${Object.keys(templates).join(', ')})` });
    }
    const ids = [];
    for (const a of picked) {
      ids.push(monitor.ingest(
        { ...a, description: 'Simulated demonstration event — NOT a real detection' },
        'simulated',
        { isSimulated: true, actor: 'analyst' }
      ));
    }
    db.audit({ id: `a-${now()}-${safeId().slice(0, 6)}`, ts: now(), actor: 'analyst', action: 'simulate', target: scenario, detail: { ids } });
    res.json({ ok: true, ids, scenario, warning: 'These alerts are SIMULATED and labeled as such in the dashboard.' });
  });

  // Seed clearly-labeled SAMPLE dataset for dashboard evaluation.
  router.post('/sample-data', auth, (req, res) => {
    const { seedSample } = require('../../scripts/seed-sample-lib');
    const ids = seedSample(db, monitor);
    db.audit({ id: `a-${now()}-${safeId().slice(0, 6)}`, ts: now(), actor: 'analyst', action: 'sample-data', target: 'alerts', detail: { count: ids.length } });
    res.json({ ok: true, count: ids.length, warning: 'Sample alerts are labeled source=sample and is_simulated=1.' });
  });

  // Notifications configuration (stored as overrides, never in git/zip).
  router.post('/config/notifications', auth, (req, res) => {
    const { webhookUrl, minSeverity } = req.body || {};
    const sevOrder = ['low', 'medium', 'high', 'critical'];
    if (webhookUrl !== null && webhookUrl !== undefined && webhookUrl !== '') {
      try {
        const u = new URL(String(webhookUrl));
        if (!['http:', 'https:'].includes(u.protocol)) throw new Error('bad protocol');
      } catch {
        return res.status(400).json({ error: 'webhookUrl must be an http(s) URL or null' });
      }
    }
    if (minSeverity !== undefined && !sevOrder.includes(minSeverity)) {
      return res.status(400).json({ error: 'minSeverity must be low|medium|high|critical' });
    }
    const file = config._overridesFile;
    let ov = {};
    try { ov = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { /* new file */ }
    ov.notifications = {
      webhookUrl: webhookUrl === '' ? null : (webhookUrl === undefined ? config.notifications.webhookUrl : webhookUrl),
      minSeverity: minSeverity === undefined ? config.notifications.minSeverity : minSeverity,
    };
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(ov, null, 2));
    config.notifications.webhookUrl = ov.notifications.webhookUrl;
    config.notifications.minSeverity = ov.notifications.minSeverity;
    db.audit({ id: `a-${now()}-${safeId().slice(0, 6)}`, ts: now(), actor: 'analyst', action: 'config-notifications', target: null, detail: { webhookUrl: ov.notifications.webhookUrl ? '(set)' : null, minSeverity: ov.notifications.minSeverity } });
    res.json({ ok: true, notifications: { webhookConfigured: Boolean(ov.notifications.webhookUrl), minSeverity: ov.notifications.minSeverity } });
  });

  return router;
}

module.exports = { createApi };
