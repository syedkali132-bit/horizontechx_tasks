'use strict';

/**
 * Monitoring service.
 *
 * Two genuine operating modes:
 *  - "live":        engine child process capturing from a network interface
 *                   (requires Suricata/Snort installed; alert stream ingested
 *                   from EVE/fast logs). State reflects the real child process.
 *  - "dropzone":    watches the upload directory and automatically analyzes
 *                   every new PCAP with the built-in analyzer — continuous
 *                   monitoring of an offline feed.
 *
 * Status is always derived from the actual process/watcher state.
 */

const fs = require('fs');
const path = require('path');
const { analyze } = require('./analyzer');
const { readFile } = require('./pcapParser');
const { detectCapabilities, LiveCapture } = require('./engine');

class Monitor {
  constructor({ config, db, ruleSetHolder, notify, log = console }) {
    this.config = config;
    this.db = db;
    this.ruleSetHolder = ruleSetHolder;
    this.notify = notify;
    this.log = log;
    this.mode = null; // 'live' | 'dropzone'
    this.watcher = null;
    this.live = new LiveCapture(config, log);
    this.lastUpdate = null;
    this.lastError = null;
    this.analyzedCount = 0;
    this._analyzedFiles = new Set();
    this._caps = null;
    this._capsCheckedAt = 0;
    this.startedAt = null;
  }

  async refreshCapabilities() {
    this._caps = await detectCapabilities(this.config, this.log);
    this._capsCheckedAt = Date.now();
    return this._caps;
  }

  get capabilities() {
    if (!this._caps || Date.now() - this._capsCheckedAt > 5 * 60 * 1000) {
      this.refreshCapabilities().catch((err) => {
        this.lastError = `capability check failed: ${err.message}`;
      });
    }
    return this._caps;
  }

  get isActive() {
    if (this.mode === 'live') return this.live.isRunning;
    if (this.mode === 'dropzone') return this.watcher !== null;
    return false;
  }

  async start(mode, actor = 'system') {
    if (this.isActive) {
      return { ok: false, error: `monitoring already active in '${this.mode}' mode — stop it first` };
    }
    this.lastError = null;
    if (mode === 'live') {
      const result = await this.live.start(
        (alert) => this.ingest(alert, 'live', { engine: this.live.mode }),
        (code, err) => {
          if (err) this.lastError = err;
          this.db.audit({ id: `a-${Date.now()}`, ts: Math.floor(Date.now() / 1000), actor: 'engine', action: 'live-capture-exited', target: null, detail: { code, error: err } });
        }
      );
      if (!result.ok) {
        this.lastError = result.error;
        return result;
      }
      this.mode = 'live';
      this.startedAt = new Date();
      this.lastUpdate = new Date();
      this.db.audit({ id: `a-${Date.now()}`, ts: Math.floor(Date.now() / 1000), actor, action: 'monitor-start', target: 'live', detail: result });
      return { ok: true, mode: 'live', ...result };
    }
    if (mode === 'dropzone') {
      const dir = this.config.watchDirAbs;
      fs.mkdirSync(dir, { recursive: true });
      this.watcher = fs.watch(dir, { persistent: false }, () => this._scanDropzone());
      this._scanDropzone();
      this.mode = 'dropzone';
      this.startedAt = new Date();
      this.lastUpdate = new Date();
      this.db.audit({ id: `a-${Date.now()}`, ts: Math.floor(Date.now() / 1000), actor, action: 'monitor-start', target: 'dropzone', detail: { dir } });
      return { ok: true, mode: 'dropzone', dir };
    }
    return { ok: false, error: `unknown mode "${mode}" (supported: live, dropzone)` };
  }

  stop(actor = 'system') {
    if (!this.isActive) {
      return { ok: false, error: 'monitoring is not active' };
    }
    const mode = this.mode;
    if (mode === 'live') this.live.stop();
    if (mode === 'dropzone' && this.watcher) {
      this.watcher.close();
      this.watcher = null;
    }
    this.mode = null;
    this.startedAt = null;
    this.db.audit({ id: `a-${Date.now()}`, ts: Math.floor(Date.now() / 1000), actor, action: 'monitor-stop', target: mode, detail: null });
    return { ok: true, mode };
  }

  _scanDropzone() {
    const dir = this.config.watchDirAbs;
    let files;
    try {
      files = fs.readdirSync(dir);
    } catch (err) {
      this.lastError = `cannot read watch directory: ${err.message}`;
      return;
    }
    for (const f of files) {
      if (!f.toLowerCase().endsWith('.pcap') && !f.toLowerCase().endsWith('.pcapng')) continue;
      if (this._analyzedFiles.has(f)) continue;
      const full = path.join(dir, f);
      let size = 0;
      try {
        size = fs.statSync(full).size;
      } catch { continue; }
      // wait until file stops growing (writer finished)
      setTimeout(() => {
        try {
          if (fs.statSync(full).size !== size) return; // still growing; next scan catches it
          if (this._analyzedFiles.has(f)) return; // handled elsewhere (e.g. API upload)
          this._analyzedFiles.add(f);
          this.analyzePcapFile(full, { engine: 'builtin', actor: 'dropzone' })
            .then((r) => {
              this.lastUpdate = new Date();
              this.lastError = null;
              this.log.log(`[monitor] dropzone analyzed ${f}: ${r.alertCount} alerts, ${r.flowCount} flows`);
            })
            .catch((err) => {
              this.lastError = `analysis of ${f} failed: ${err.message}`;
              this.log.error(`[monitor] ${this.lastError}`);
            });
        } catch { /* file vanished */ }
      }, 1200);
    }
  }

  /**
   * Analyze a PCAP with the built-in analyzer and persist alerts + flows.
   * Returns {alertCount, flowCount, packetCount}.
   */
  async analyzePcapFile(filePath, { engine = 'builtin', actor = 'api' } = {}) {
    const name = path.basename(filePath);
    const capture = readFile(filePath);
    const ruleSet = this.ruleSetHolder.get();
    const result = analyze(capture, ruleSet, { heuristics: this.config.heuristics });
    const sizeBytes = fs.statSync(filePath).size;
    const alerts = [...result.signatureAlerts, ...result.heuristicAlerts];
    const now = Math.floor(Date.now() / 1000);

    this.db.tx(() => {
      for (const a of alerts) {
        const id = `al-${now}-${Math.random().toString(16).slice(2, 10)}`;
        this.db.insertAlert({
          id,
          ts: a.ts || now,
          severity: a.severity,
          srcIp: a.srcIp,
          srcPort: a.srcPort,
          dstIp: a.dstIp,
          dstPort: a.dstPort,
          proto: a.proto,
          category: a.category,
          signature: a.signature,
          signatureId: a.signatureId,
          gid: a.gid,
          rev: a.rev,
          classtype: a.classtype,
          description: a.heuristic ? `Behavioral detection (${a.heuristic})` : 'Signature rule match',
          source: 'pcap',
          isSimulated: false,
          engine,
          pcapFile: name,
          ruleSource: a.ruleSource ?? null,
          payloadPreview: a.payloadPreview ?? null,
          evidence: a.evidence ?? null,
          thresholdCount: a.thresholdCount ?? null,
        });
      }
      this.db.replaceFlows(name, result.flows);
      this.db.upsertPcapFile({
        name,
        originalName: name,
        sizeBytes,
        analyzedBy: actor,
        engine,
        packetCount: result.summary.totalPackets,
        decodedPackets: result.summary.decodedPackets,
        flowCount: result.flows.length,
        alertCount: alerts.length,
        firstTs: result.summary.firstTs,
        lastTs: result.summary.lastTs,
      });
    });

    for (const a of alerts) {
      this.notify({
        id: `al-${a.signatureId}-${a.ts}`,
        ts: a.ts,
        severity: a.severity,
        signature: a.signature,
        category: a.category,
        srcIp: a.srcIp,
        dstIp: a.dstIp,
        proto: a.proto,
        source: 'pcap',
      });
    }
    this.analyzedCount++;
    this.lastUpdate = new Date();
    return { alertCount: alerts.length, flowCount: result.flows.length, packetCount: result.summary.totalPackets };
  }

  /** Tell the drop-zone watcher to ignore a file (e.g. one just uploaded via the API). */
  markAnalyzed(fileName) {
    this._analyzedFiles.add(fileName);
  }

  /** Ingest a single alert (live engine path or simulated/sample ingestion). */
  ingest(a, source, { engine = null, pcapFile = null, isSimulated = false, actor = 'system' } = {}) {
    const now = Math.floor(Date.now() / 1000);
    const id = `al-${now}-${Math.random().toString(16).slice(2, 10)}`;
    this.db.insertAlert({
      id,
      ts: a.ts || now,
      severity: a.severity || 'medium',
      srcIp: a.srcIp,
      srcPort: a.srcPort,
      dstIp: a.dstIp,
      dstPort: a.dstPort,
      proto: a.proto,
      category: a.category,
      signature: a.signature,
      signatureId: a.signatureId,
      gid: a.gid,
      rev: a.rev,
      classtype: a.classtype,
      description: a.description ?? (engine ? `Detected by ${engine}` : 'Detected by Sentinel NIDS'),
      source,
      isSimulated,
      engine,
      pcapFile,
      ruleSource: a.ruleSource ?? null,
      payloadPreview: a.payloadPreview ?? null,
      evidence: a.evidence ?? null,
      thresholdCount: a.thresholdCount ?? null,
    });
    this.lastUpdate = new Date();
    this.notify({ id, ...a, source });
    return id;
  }

  status() {
    return {
      active: this.isActive,
      mode: this.mode,
      live: this.live.status(),
      startedAt: this.startedAt ? this.startedAt.toISOString() : null,
      lastUpdate: this.lastUpdate ? this.lastUpdate.toISOString() : null,
      lastError: this.lastError,
      analyzedCount: this.analyzedCount,
      capabilities: this._caps,
    };
  }
}

module.exports = { Monitor };
