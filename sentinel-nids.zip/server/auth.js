'use strict';

/**
 * Lightweight admin-token authentication.
 *
 * The token authorizes all mutating endpoints (status changes, notes,
 * monitoring control, rule reload, uploads, sample data). On first start a
 * random token is generated and stored in data/.admin-token (permissions
 * restricted to the owner). Set NIDS_ADMIN_TOKEN in the environment to
 * provide your own. Read-only endpoints stay open because the server binds
 * to localhost by default.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function loadOrCreateToken(dataDir) {
  if (process.env.NIDS_ADMIN_TOKEN && process.env.NIDS_ADMIN_TOKEN.length >= 8) {
    return { token: process.env.NIDS_ADMIN_TOKEN, source: 'environment' };
  }
  const file = path.join(dataDir, '.admin-token');
  try {
    const existing = fs.readFileSync(file, 'utf8').trim();
    if (existing.length >= 16) return { token: existing, source: 'file' };
  } catch { /* first boot */ }
  const token = crypto.randomBytes(24).toString('hex');
  fs.writeFileSync(file, token, { mode: 0o600 });
  return { token, source: 'generated' };
}

function requireAuth(getToken) {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : (req.headers['x-admin-token'] || '');
    if (!token) {
      return res.status(401).json({ error: 'Admin token required. Provide Authorization: Bearer <token>.' });
    }
    if (token.length < 8) {
      return res.status(403).json({ error: 'Invalid admin token.' });
    }
    const expected = getToken();
    const a = Buffer.from(String(token));
    const b = Buffer.from(String(expected));
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return res.status(403).json({ error: 'Invalid admin token.' });
    }
    req.admin = true;
    next();
  };
}

module.exports = { loadOrCreateToken, requireAuth };
