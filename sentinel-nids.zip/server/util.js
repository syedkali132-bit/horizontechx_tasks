'use strict';

const crypto = require('crypto');

const SEVERITY_ORDER = ['low', 'medium', 'high', 'critical'];

function severityRank(sev) {
  const i = SEVERITY_ORDER.indexOf(sev);
  return i === -1 ? 0 : i;
}

function isValidIpv4(ip) {
  if (typeof ip !== 'string') return false;
  const parts = ip.split('.');
  return parts.length === 4 && parts.every((p) => /^\d{1,3}$/.test(p) && Number(p) <= 255);
}

function ipv4ToInt(ip) {
  return ip.split('.').reduce((acc, o) => ((acc << 8) | Number(o)) >>> 0, 0);
}

function ipInCidr(ip, cidr) {
  const [net, bitsRaw] = cidr.split('/');
  if (!isValidIpv4(net)) return false;
  const bits = bitsRaw === undefined ? 32 : Number(bitsRaw);
  if (!Number.isInteger(bits) || bits < 0 || bits > 32) return false;
  const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
  return (ipv4ToInt(ip) & mask) === (ipv4ToInt(net) & mask);
}

/** Resolve an address spec item (ip, cidr, or variable like $HOME_NET) to CIDR list. */
function expandVar(item, vars, depth = 0) {
  if (depth > 4) return [];
  const out = [];
  const walk = (entry, negate) => {
    if (typeof entry !== 'string') return;
    if (entry.startsWith('$')) {
      const name = entry.slice(1);
      const values = vars[name];
      if (Array.isArray(values)) values.forEach((v) => walk(v, negate));
      else if (typeof values === 'string') walk(values, negate);
      return;
    }
    if (entry.startsWith('!')) {
      walk(entry.slice(1), !negate);
      return;
    }
    if (entry === 'any') {
      out.push({ any: true, negate });
      return;
    }
    out.push({ cidr: entry, negate });
  };
  walk(item, false);
  return out;
}

function parseIpSpec(spec, vars) {
  // spec: "any" | "ip" | item | "[item,item]" possibly negated as whole
  if (typeof spec !== 'string') return null;
  let s = spec.trim();
  let wholeNegate = false;
  if (s.startsWith('!')) {
    wholeNegate = true;
    s = s.slice(1).trim();
  }
  let items;
  if (s.startsWith('[') && s.endsWith(']')) {
    items = splitList(s.slice(1, -1));
  } else {
    items = [s];
  }
  const resolved = [];
  for (const it of items) {
    for (const r of expandVar(it, vars)) {
      resolved.push({ ...r, negate: wholeNegate ? !r.negate : r.negate });
    }
  }
  const any = resolved.length > 0 && resolved.every((r) => r.any || (r.cidr === '0.0.0.0/0' && !r.negate));
  return { items: resolved, any };
}

function splitList(inner) {
  const parts = [];
  let depth = 0;
  let cur = '';
  for (const ch of inner) {
    if (ch === '[') depth++;
    if (ch === ']') depth--;
    if (ch === ',' && depth === 0) {
      parts.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  if (cur.trim()) parts.push(cur.trim());
  return parts;
}

function ipMatches(ip, spec) {
  if (!spec) return false;
  if (spec.any) return true;
  let matched = false;
  let hasPositive = false;
  for (const item of spec.items) {
    if (item.any) {
      if (!item.negate) return true;
      continue;
    }
    if (!item.negate) hasPositive = true;
    const hit = isValidIpv4(ip) && ipInCidr(ip, item.cidr);
    if (hit) {
      if (item.negate) return false;
      matched = true;
    }
  }
  // A spec made only of negations (e.g. !$HOME_NET) matches everything the
  // negations do not cover.
  if (!hasPositive && !matched) return true;
  return matched;
}

function parsePortSpec(spec) {
  if (typeof spec !== 'string') return null;
  let s = spec.trim();
  let wholeNegate = false;
  if (s.startsWith('!')) {
    wholeNegate = true;
    s = s.slice(1).trim();
  }
  const items = s.startsWith('[') && s.endsWith(']') ? splitList(s.slice(1, -1)) : [s];
  const ranges = [];
  for (const it of items) {
    let negate = wholeNegate;
    let v = it;
    if (v.startsWith('!')) {
      negate = !negate;
      v = v.slice(1);
    }
    if (v === 'any') {
      ranges.push({ any: true, negate });
      continue;
    }
    let m = v.match(/^(\d+)(?::(\d*))?$/);
    if (m) {
      const lo = Number(m[1]);
      const hi = m[2] === undefined ? lo : m[2] === '' ? 65535 : Number(m[2]);
      if (lo < 0 || hi > 65535 || lo > hi) return null;
      ranges.push({ lo, hi, negate });
      continue;
    }
    m = v.match(/^:(\d+)$/);
    if (m) {
      ranges.push({ lo: 0, hi: Number(m[1]), negate });
      continue;
    }
    return null; // unsupported port token (e.g. $VAR ports not implemented)
  }
  return { ranges, any: ranges.some((r) => r.any && !r.negate) };
}

function portMatches(port, spec) {
  if (!spec) return false;
  if (spec.any) return true;
  let matched = false;
  let hasPositive = false;
  for (const r of spec.ranges) {
    if (r.any) {
      if (!r.negate) return true;
      continue;
    }
    if (!r.negate) hasPositive = true;
    const hit = port >= r.lo && port <= r.hi;
    if (hit) {
      if (r.negate) return false;
      matched = true;
    }
  }
  if (!hasPositive && !matched) return true;
  return matched;
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function safeId() {
  return crypto.randomBytes(12).toString('hex');
}

module.exports = {
  SEVERITY_ORDER,
  severityRank,
  isValidIpv4,
  ipInCidr,
  parseIpSpec,
  parsePortSpec,
  ipMatches,
  portMatches,
  escapeHtml,
  safeId,
  splitList,
};
