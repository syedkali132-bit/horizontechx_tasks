'use strict';

/**
 * Detection-engine integration layer.
 *
 * Detects whether Suricata or Snort is installed, can run engine-based PCAP
 * analysis (suricata -r / snort -r), and can start/stop live capture via a
 * child process. When no engine is installed every capability is reported
 * accurately as unavailable — the dashboard never claims live monitoring is
 * active unless a child process is genuinely running.
 */

const { spawn, execFile } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

function runVersion(cmd, args, timeoutMs = 8000) {
  return new Promise((resolve) => {
    let out = '';
    let err = '';
    let done = false;
    let child;
    try {
      child = execFile(cmd, args, { timeout: timeoutMs, windowsHide: true }, (error, stdout, stderr) => {
        done = true;
        out = stdout || '';
        err = stderr || '';
        const text = (out + '\n' + err).trim();
        resolve({ ok: !error && text.length > 0, text: text.split('\n')[0].slice(0, 300), raw: text });
      });
    } catch {
      resolve({ ok: false, text: '', raw: '' });
      return;
    }
    void child;
    setTimeout(() => {
      if (!done) resolve({ ok: false, text: '', raw: '' });
    }, timeoutMs + 500);
  });
}

async function detectCapabilities(config, log = console) {
  const [suricata, snort] = await Promise.all([
    runVersion(config.engine.suricataPath, ['-V']),
    runVersion(config.engine.snortPath, ['-V']),
  ]);
  const caps = {
    checkedAt: new Date().toISOString(),
    platform: process.platform,
    suricata: {
      installed: suricata.ok,
      version: suricata.ok ? versionFrom(suricata.raw, /(\d+\.\d+(?:\.\d+)?)/) : null,
      path: config.engine.suricataPath,
    },
    snort: {
      installed: snort.ok,
      version: snort.ok ? versionFrom(snort.raw, /(\d+\.\d+(?:\.\d+)?)/) : null,
      path: config.engine.snortPath,
    },
    liveCapture: { possible: false, notes: [] },
  };
  const notes = caps.liveCapture.notes;
  if (process.platform === 'win32') {
    if (suricata.ok || snort.ok) {
      notes.push('Windows engine found; live capture additionally requires Npcap (npcap.com) with the "Support raw 802.11 traffic" option OFF and admin/elevated rights.');
    } else {
      notes.push('No Suricata/Snort binary found on PATH. Install one of them to enable engine-backed detection (see README, "Installing a detection engine").');
    }
    notes.push('On Windows this console is typically unprivileged: even with an engine installed, starting live capture may fail without elevation — the monitoring page will show the exact engine error.');
  } else if (!suricata.ok && !snort.ok) {
    notes.push('No Suricata/Snort binary found on PATH. Install with e.g. "sudo apt install suricata" to enable engine-backed detection.');
  }
  if ((suricata.ok || snort.ok) && process.platform !== 'win32') {
    caps.liveCapture.possible = true;
  } else if ((suricata.ok || snort.ok) && process.platform === 'win32') {
    caps.liveCapture.possible = true; // possible if Npcap + elevation are in place
  }
  return caps;
}

function versionFrom(text, re) {
  const m = text.match(re);
  return m ? m[1] : null;
}

/** Parse one Suricata EVE JSON line into a normalized alert. */
function parseEveLine(line) {
  let obj;
  try {
    obj = JSON.parse(line);
  } catch {
    return null;
  }
  if (obj.event_type !== 'alert' || !obj.alert) return null;
  const sevMap = { 1: 'critical', 2: 'high', 3: 'medium', 4: 'low' };
  return {
    ts: typeof obj.timestamp === 'string' ? Math.floor(Date.parse(obj.timestamp) / 1000) : Math.floor(Date.now() / 1000),
    severity: sevMap[obj.alert.severity] || 'medium',
    srcIp: obj.src_ip || null,
    srcPort: obj.src_port ?? null,
    dstIp: obj.dest_ip || null,
    dstPort: obj.dest_port ?? null,
    proto: (obj.proto || 'ip').toLowerCase(),
    category: obj.alert.category || 'Uncategorized',
    signature: obj.alert.signature || 'Suricata alert',
    signatureId: obj.alert.signature_id ?? null,
    gid: obj.alert.gid ?? 1,
    classtype: null,
    payloadPreview: obj.payload ? Buffer.from(String(obj.payload), 'base64').toString('latin1').slice(0, 96) : '',
  };
}

/** Parse a Snort "fast" alert log line. */
function parseFastLine(line) {
  const m = line.match(/^(\d+\/\d+)-(\d+:\d+:\d+(?:\.\d+)?)\s+\[\*\*\]\s+\[(\d+):(\d+):(\d+)\]\s+(.+?)\s+\[\*\*\](?:\s+\[Classification:\s*(.+?)\])?(?:\s+\[Priority:\s*(\d+)\])?.*?\{(\w+)\}\s+(\S+)\s+->\s+(\S+)/);
  if (!m) return null;
  const [, datePart, timePart, gid, sid, , msg, classification, priority, proto, src, dst] = m;
  const [mo, da] = datePart.split('/').map(Number);
  const [h, mi, s] = timePart.split(':');
  const now = new Date();
  const ts = Math.floor(new Date(now.getFullYear(), mo - 1, da, Number(h), Number(mi), Number(s.split('.')[0])).getTime() / 1000);
  const srcM = src.match(/^(.+?):(\d+)$/);
  const dstM = dst.match(/^(.+?):(\d+)$/);
  const sevMap = { 1: 'critical', 2: 'high', 3: 'medium' };
  return {
    ts: Number.isFinite(ts) ? ts : Math.floor(Date.now() / 1000),
    severity: sevMap[Number(priority)] || 'medium',
    srcIp: srcM ? srcM[1] : src,
    srcPort: srcM ? Number(srcM[2]) : null,
    dstIp: dstM ? dstM[1] : dst,
    dstPort: dstM ? Number(dstM[2]) : null,
    proto: proto.toLowerCase(),
    category: classification || 'Uncategorized',
    signature: msg,
    signatureId: Number(sid),
    gid: Number(gid),
    classtype: null,
    payloadPreview: '',
  };
}

/**
 * Run the external engine against a PCAP file (offline).
 * Returns {engine, alerts[], diagnostics}.
 */
async function analyzeWithEngine(config, pcapPath, workDir, log = console) {
  fs.mkdirSync(workDir, { recursive: true });
  const caps = await detectCapabilities(config, log);
  const useSuricata = caps.suricata.installed && (config.engine.preferred !== 'snort' || !caps.snort.installed);
  if (useSuricata) {
    return runSuricataPcap(config, pcapPath, workDir);
  }
  if (caps.snort.installed) {
    return runSnortPcap(config, pcapPath, workDir);
  }
  const err = new Error('No detection engine (Suricata/Snort) installed — offline engine analysis unavailable. Use the built-in analyzer or install an engine.');
  err.code = 'NO_ENGINE';
  throw err;
}

function execCapture(cmd, args, opts = {}) {
  return new Promise((resolve) => {
    let stdout = '';
    let stderr = '';
    let child;
    try {
      child = spawn(cmd, args, { windowsHide: true, ...opts });
    } catch (err) {
      resolve({ code: -1, stdout, stderr: String(err.message), child: null });
      return;
    }
    child.stdout.on('data', (d) => { stdout += d; });
    child.stderr.on('data', (d) => { stderr += d; });
    child.on('error', (err) => {
      resolve({ code: -1, stdout, stderr: String(err.message), child });
    });
    child.on('close', (code) => {
      resolve({ code: code === null ? -1 : code, stdout, stderr, child });
    });
  });
}

async function runSuricataPcap(config, pcapPath, workDir) {
  const evePath = path.join(workDir, 'eve.json');
  const args = ['-r', pcapPath, '-l', workDir];
  if (config.engine.suricataConfig) args.push('-c', config.engine.suricataConfig);
  const res = await execCapture(config.engine.suricataPath, args);
  const diagnostics = {
    engine: 'suricata',
    command: `${config.engine.suricataPath} ${args.join(' ')}`,
    exitCode: res.code,
    stderrTail: res.stderr.slice(-2000),
  };
  const alerts = [];
  if (fs.existsSync(evePath)) {
    const lines = fs.readFileSync(evePath, 'utf8').split('\n');
    for (const line of lines) {
      const a = parseEveLine(line);
      if (a) alerts.push(a);
    }
  }
  return { engine: 'suricata', alerts, diagnostics };
}

async function runSnortPcap(config, pcapPath, workDir) {
  const logDir = path.join(workDir, 'snort-logs');
  fs.mkdirSync(logDir, { recursive: true });
  const args = ['-r', pcapPath, '-A', 'fast', '-l', logDir, '-q'];
  const res = await execCapture(config.engine.snortPath, args);
  const diagnostics = {
    engine: 'snort',
    command: `${config.engine.snortPath} ${args.join(' ')}`,
    exitCode: res.code,
    stderrTail: res.stderr.slice(-2000),
  };
  const alerts = [];
  try {
    const files = fs.readdirSync(logDir).filter((f) => f.startsWith('alert'));
    for (const f of files) {
      const lines = fs.readFileSync(path.join(logDir, f), 'utf8').split('\n');
      for (const line of lines) {
        const a = parseFastLine(line);
        if (a) alerts.push(a);
      }
    }
  } catch {
    // no alert files produced
  }
  return { engine: 'snort', alerts, diagnostics };
}

/**
 * Live capture controller. Owns the engine child process and streams alerts
 * from the EVE/fast log to the given onAlert callback.
 */
class LiveCapture {
  constructor(config, log = console) {
    this.config = config;
    this.log = log;
    this.child = null;
    this.startedAt = null;
    this.state = 'stopped';
    this.lastError = null;
    this.mode = null;
    this._stopTimers = [];
  }

  get isRunning() {
    return this.child !== null && this.child.exitCode === null && !this.child.killed;
  }

  async start(onAlert, onExit) {
    if (this.isRunning) return { ok: false, error: 'capture already running' };
    const caps = await detectCapabilities(this.config, this.log);
    const iface = this.config.engine.interface;
    if (!iface) {
      return { ok: false, error: 'No capture interface configured. Set engine.interface in config/nids.config.json.' };
    }
    const workDir = path.join(this.config.dataDirAbs, 'logs', `live-${Date.now()}`);
    fs.mkdirSync(workDir, { recursive: true });

    let cmd;
    let args;
    let logFile;
    if (caps.suricata.installed) {
      cmd = this.config.engine.suricataPath;
      logFile = path.join(workDir, 'eve.json');
      args = ['-i', iface, '-l', workDir];
      if (this.config.engine.suricataConfig) args.push('-c', this.config.engine.suricataConfig);
      this.mode = 'suricata';
    } else if (caps.snort.installed) {
      cmd = this.config.engine.snortPath;
      logFile = null;
      args = ['-i', iface, '-A', 'fast', '-l', workDir, '-q'];
      this.mode = 'snort';
    } else {
      return { ok: false, error: 'Neither Suricata nor Snort is installed; live capture cannot start. See README → Installing a detection engine.' };
    }

    try {
      this.child = spawn(cmd, args, { windowsHide: true });
    } catch (err) {
      this.child = null;
      this.state = 'stopped';
      return { ok: false, error: `failed to spawn engine: ${err.message}` };
    }
    this.state = 'starting';
    this.startedAt = new Date();
    this.lastError = null;

    this.child.on('error', (err) => {
      this.lastError = err.message;
      this.state = 'error';
    });
    this.child.on('exit', (code, signal) => {
      this.state = code === 0 ? 'stopped' : 'error';
      if (code !== 0 && code !== null) this.lastError = `engine exited with code ${code}${signal ? ` (signal ${signal})` : ''}`;
      this.child = null;
      for (const t of this._stopTimers) clearInterval(t);
      this._stopTimers = [];
      if (onExit) onExit(code, this.lastError);
    });

    // Wire alert streams once log files appear.
    if (this.mode === 'suricata') {
      this._watchForFile(logFile, (p) => this._tailLines(p, parseEveLine, onAlert));
    } else {
      this._watchForFile(path.join(workDir, 'alert'), (p) => this._tailLines(p, parseFastLine, onAlert), true);
      // snort rotates alert files; also scan directory
      const t = setInterval(() => {
        try {
          for (const f of fs.readdirSync(workDir)) {
            if (f.startsWith('alert') && !this._tailedFiles.has(path.join(workDir, f))) {
              this._watchForFile(path.join(workDir, f), (p) => this._tailLines(p, parseFastLine, onAlert));
            }
          }
        } catch { /* dir removed on stop */ }
      }, 3000);
      this._stopTimers.push(t);
    }

    // startup grace: mark running after brief delay if still alive
    const t2 = setTimeout(() => {
      if (this.isRunning) this.state = 'running';
    }, 1500);
    this._stopTimers.push(t2);

    return { ok: true, mode: this.mode, pid: this.child.pid, workDir };
  }

  _tailedFiles = new Set();

  _watchForFile(file, cb, isDirName = false) {
    const started = Date.now();
    const t = setInterval(() => {
      if (!this.isRunning && Date.now() - started > 10000) {
        clearInterval(t);
        return;
      }
      const target = isDirName ? file : file;
      if (fs.existsSync(target) && !this._tailedFiles.has(target)) {
        clearInterval(t);
        this._tailedFiles.add(target);
        cb(target);
      }
    }, 500);
    this._stopTimers.push(t);
  }

  _tailLines(file, parser, onAlert) {
    let offset = 0;
    const t = setInterval(() => {
      if (!this.isRunning && this.state !== 'starting') {
        clearInterval(t);
        return;
      }
      try {
        const stat = fs.statSync(file);
        if (stat.size > offset) {
          const fd = fs.openSync(file, 'r');
          const buf = Buffer.alloc(stat.size - offset);
          fs.readSync(fd, buf, 0, buf.length, offset);
          fs.closeSync(fd);
          offset = stat.size;
          for (const line of buf.toString('utf8').split('\n')) {
            const a = parser(line);
            if (a && onAlert) onAlert(a);
          }
        }
      } catch { /* file rotating */ }
    }, 700);
    this._stopTimers.push(t);
  }

  stop() {
    if (!this.child) {
      this.state = 'stopped';
      return { ok: true };
    }
    try {
      this.child.kill('SIGTERM');
      // Windows: SIGTERM may not exist; force after grace
      setTimeout(() => {
        if (this.child && !this.child.killed) {
          try { this.child.kill('SIGKILL'); } catch { /* already dead */ }
        }
      }, 2500);
    } catch (err) {
      return { ok: false, error: err.message };
    }
    this.state = 'stopped';
    return { ok: true };
  }

  status() {
    return {
      state: this.isRunning ? this.state : this.state === 'error' ? 'error' : 'stopped',
      mode: this.mode,
      running: this.isRunning,
      pid: this.child ? this.child.pid : null,
      startedAt: this.startedAt ? this.startedAt.toISOString() : null,
      lastError: this.lastError,
    };
  }
}

module.exports = { detectCapabilities, analyzeWithEngine, parseEveLine, parseFastLine, LiveCapture };
