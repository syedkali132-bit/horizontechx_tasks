'use strict';

/**
 * Notification dispatcher. Posts high-severity alerts to a configurable
 * webhook. Every attempt (success or failure) is written to the
 * notifications_log table so behavior is auditable even without a webhook.
 */

const { severityRank } = require('./util');

function dispatch(db, config, alert) {
  const minSev = config.notifications.minSeverity || 'high';
  if (severityRank(alert.severity) < severityRank(minSev)) return;
  const ts = Math.floor(Date.now() / 1000);
  const payload = {
    event: 'nids.alert',
    severity: alert.severity,
    signature: alert.signature,
    category: alert.category,
    srcIp: alert.srcIp,
    dstIp: alert.dstIp,
    proto: alert.proto,
    source: alert.source,
    at: new Date(alert.ts * 1000).toISOString(),
  };
  const url = config.notifications.webhookUrl;
  if (!url) {
    db.logNotification({
      id: `nl-${ts}-${Math.random().toString(16).slice(2, 8)}`,
      ts,
      alertId: alert.id,
      channel: 'webhook',
      target: null,
      ok: 0,
      detail: `severity threshold met (${alert.severity} >= ${minSev}) but no webhookUrl configured`,
    });
    return;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal: controller.signal,
  })
    .then((res) => {
      clearTimeout(timer);
      db.logNotification({
        id: `nl-${ts}-${Math.random().toString(16).slice(2, 8)}`,
        ts,
        alertId: alert.id,
        channel: 'webhook',
        target: url,
        ok: res.ok ? 1 : 0,
        detail: `HTTP ${res.status}`,
      });
    })
    .catch((err) => {
      clearTimeout(timer);
      db.logNotification({
        id: `nl-${ts}-${Math.random().toString(16).slice(2, 8)}`,
        ts,
        alertId: alert.id,
        channel: 'webhook',
        target: url,
        ok: 0,
        detail: String(err.message || err).slice(0, 300),
      });
    });
}

module.exports = { dispatch };
