'use strict';

/**
 * Snort/Suricata-style signature rule engine (offline matcher subset).
 * Parses rule files and evaluates decoded packets against them.
 * Supported subset is documented in docs/RULES.md.
 */

const fs = require('fs');
const path = require('path');
const { parseIpSpec, parsePortSpec, ipMatches, portMatches, splitList } = require('./util');

const CLASS_TYPES = {
  'attempted-admin': { priority: 1, category: 'Attempted Administrator Privilege Gain' },
  'attempted-user': { priority: 1, category: 'Attempted User Privilege Gain' },
  'attempted-recon': { priority: 2, category: 'Attempted Reconnaissance' },
  'attempted-dos': { priority: 2, category: 'Attempted Denial of Service' },
  'web-application-attack': { priority: 1, category: 'Web Application Attack' },
  'trojan-activity': { priority: 1, category: 'A Network Trojan was Detected' },
  'potentially-bad-traffic': { priority: 2, category: 'Potentially Bad Traffic' },
  'protocol-command-decode': { priority: 3, category: 'Protocol Command Decode' },
  'policy-violation': { priority: 2, category: 'Potential Corporate Privacy Violation' },
  'misc-attack': { priority: 2, category: 'Misc Attack' },
  'misc-activity': { priority: 3, category: 'Misc Activity' },
  'bad-unknown': { priority: 3, category: 'Potentially Bad Traffic' },
};

const PRIORITY_TO_SEVERITY = { 1: 'critical', 2: 'high', 3: 'medium' };

const KNOWN_OPTIONS = new Set([
  'msg', 'sid', 'gid', 'rev', 'classtype', 'priority', 'content', 'nocase', 'depth',
  'offset', 'pcre', 'flags', 'flow', 'threshold', 'itype', 'icode', 'icmp_id',
  'icmp_seq', 'dsize', 'ttl', 'tos', 'id', 'ipopts', 'fragbits', 'fragoffset',
  'reference', 'metadata', 'fast_pattern', 'tag', 'sameip', 'flowbits', 'byte_test',
  'byte_jump', 'isdataat', 'distance', 'within', 'rawbytes', 'replace', 'resp',
  'react', 'session', 'detection_filter', 'gid',
]);

const FLAG_LETTERS = { F: 0x01, S: 0x02, R: 0x04, P: 0x08, A: 0x10, U: 0x20, E: 0x40, C: 0x80 };

function parseContentValue(raw) {
  // content:"..." with |hex bytes| support, and ! negation
  let negated = false;
  let s = raw.trim();
  let rest = '';
  if (s.startsWith('!')) {
    negated = true;
    s = s.slice(1).trim();
  }
  if (s.length >= 2 && s.startsWith('"') && s.endsWith('"')) {
    rest = '';
    s = s.slice(1, -1);
  } else if (s.startsWith('"')) {
    // inline modifiers after the quoted string: content:"abc" depth:5 within:10;
    let j = 1;
    while (j < s.length) {
      if (s[j] === '\\') { j += 2; continue; }
      if (s[j] === '"') break;
      j++;
    }
    if (j >= s.length) throw new Error('unterminated quoted string in content');
    rest = s.slice(j + 1).trim();
    s = s.slice(1, j);
  }
  const bytes = [];
  let i = 0;
  let textBuf = [];
  const flushText = () => {
    for (const ch of Buffer.from(textBuf.join(''), 'utf8')) bytes.push(ch);
    textBuf = [];
  };
  while (i < s.length) {
    const ch = s[i];
    if (ch === '|') {
      flushText();
      const end = s.indexOf('|', i + 1);
      if (end === -1) throw new Error('unterminated |hex| block in content');
      const hexPart = s.slice(i + 1, end);
      for (const tok of hexPart.trim().split(/\s+/)) {
        if (!tok) continue;
        if (!/^[0-9a-fA-F]{2}$/.test(tok)) throw new Error(`invalid hex byte "${tok}" in content`);
        bytes.push(parseInt(tok, 16));
      }
      i = end + 1;
    } else if (ch === '\\' && i + 1 < s.length) {
      const next = s[i + 1];
      const map = { n: 0x0a, r: 0x0d, t: 0x09, '\\': 0x5c, '"': 0x22, ';': 0x3b, ':': 0x3a, '|': 0x7c };
      if (next in map) {
        textBuf.push(String.fromCharCode(map[next]));
        i += 2;
      } else {
        textBuf.push(next);
        i += 2;
      }
    } else {
      textBuf.push(ch);
      i++;
    }
  }
  flushText();
  return { bytes: Buffer.from(bytes), negated, rest };
}

function parseFlags(value) {
  const v = value.trim();
  let mask = 0;
  let val = 0;
  let negated = false;
  let s = v;
  if (s === '0') {
    // Snort: flags:0 means NO flags set — mask every flag bit, require value 0
    for (const l of 'FSRPAU') mask |= FLAG_LETTERS[l];
    return { mask, value: 0, negated: false };
  }
  if (s.startsWith('!')) {
    negated = true;
    s = s.slice(1);
  }
  if (s.startsWith('*')) {
    for (const l of 'FSRPAUEC') mask |= FLAG_LETTERS[l];
    s = s.slice(1);
  }
  for (const ch of s) {
    if (!(ch in FLAG_LETTERS)) throw new Error(`unknown TCP flag letter "${ch}"`);
    mask |= FLAG_LETTERS[ch];
    val |= FLAG_LETTERS[ch];
  }
  return { mask, value: val, negated };
}

function parseThreshold(value, location) {
  const parts = {};
  for (const kv of splitList(value)) {
    const idx = kv.indexOf(' ');
    if (idx === -1) throw new Error(`bad threshold token "${kv}" at ${location}`);
    parts[kv.slice(0, idx).trim()] = kv.slice(idx + 1).trim();
  }
  const type = parts.type || 'limit';
  if (!['limit', 'threshold', 'both'].includes(type)) {
    throw new Error(`unsupported threshold type "${type}" at ${location}`);
  }
  return {
    type,
    track: parts.track === 'by_dst' ? 'by_dst' : 'by_src',
    count: Math.max(1, parseInt(parts.count, 10) || 1),
    seconds: Math.max(1, parseInt(parts.seconds, 10) || 60),
  };
}

function parseDsize(value) {
  const m = String(value).trim().match(/^(<>|[<>=!]+)?\s*(\d+)(?:\s*<>\s*(\d+))?$/);
  if (!m) throw new Error(`unsupported dsize "${value}"`);
  const op = m[1] || '=';
  const a = Number(m[2]);
  const b = m[3] !== undefined ? Number(m[3]) : null;
  if (op === '<>' && b !== null) return { op: 'range', a, b };
  if (['<', '>', '<=', '>=', '=', '==', '!='].includes(op)) return { op, a };
  throw new Error(`unsupported dsize operator "${op}"`);
}

function parsePcre(raw) {
  let s = raw.trim();
  let negated = false;
  if (s.startsWith('!')) {
    negated = true;
    s = s.slice(1).trim();
  }
  const open = s.indexOf('/');
  if (open === -1) throw new Error('pcre must be /pattern/flags');
  let close = -1;
  for (let i = s.length - 1; i > open; i--) {
    if (s[i] === '/') {
      close = i;
      break;
    }
  }
  if (close === -1) throw new Error('pcre missing closing /');
  const pattern = s.slice(open + 1, close);
  const flags = s.slice(close + 1);
  const jsFlags = [...new Set(flags.replace(/[^imsu]/g, '').split(''))].join('');
  let re;
  try {
    re = new RegExp(pattern, jsFlags);
  } catch (err) {
    throw new Error(`invalid pcre pattern: ${err.message}`);
  }
  return { re, negated };
}

/** Parse one rule line. Returns {rule} or throws with line context. */
function parseRuleLine(line, fileName, lineNo, vars) {
  const location = `${fileName}:${lineNo}`;
  const m = line.match(/^\s*(alert|log|drop|reject|pass)\s+(\S+)\s+(\S+)\s+(\S+)\s+(->|<>|<-)\s+(\S+)\s+(\S+)\s+\((.*)\)\s*$/);
  if (!m) throw new Error(`syntax error at ${location}: cannot parse rule header`);
  const [, action, proto, srcIpRaw, srcPortRaw, dir, dstIpRaw, dstPortRaw, bodyRaw] = m;

  if (!['tcp', 'udp', 'icmp', 'ip'].includes(proto)) {
    throw new Error(`unsupported protocol "${proto}" at ${location} (supported: tcp, udp, icmp, ip)`);
  }

  // Split option body on unescaped semicolons, honouring quoted strings.
  const opts = [];
  {
    let cur = '';
    let inQ = false;
    for (let i = 0; i < bodyRaw.length; i++) {
      const ch = bodyRaw[i];
      if (ch === '\\' && inQ && i + 1 < bodyRaw.length) {
        cur += ch + bodyRaw[i + 1];
        i++;
        continue;
      }
      if (ch === '"') inQ = !inQ;
      if (ch === ';' && !inQ) {
        if (cur.trim()) opts.push(cur.trim());
        cur = '';
      } else {
        cur += ch;
      }
    }
    if (cur.trim()) opts.push(cur.trim());
  }

  const rule = {
    action, proto, direction: dir, file: fileName, line: lineNo,
    disabled: false, warnings: [],
    contents: [], pcre: null, threshold: null,
    sameip: false, flow: null, itype: null, icode: null,
    dsize: null, flags: null, references: [], metadata: [],
    vars,
  };
  const seenSid = new Set();
  for (const opt of opts) {
    const idx = opt.indexOf(':');
    const key = (idx === -1 ? opt : opt.slice(0, idx)).trim().toLowerCase();
    const val = idx === -1 ? '' : opt.slice(idx + 1).trim();
    switch (key) {
      case 'msg':
        rule.msg = val.replace(/^"|"$/g, '');
        break;
      case 'sid':
        rule.sid = parseInt(val, 10);
        if (!Number.isInteger(rule.sid) || rule.sid < 1) throw new Error(`invalid sid "${val}" at ${location}`);
        break;
      case 'gid':
        rule.gid = parseInt(val, 10) || 1;
        break;
      case 'rev':
        rule.rev = parseInt(val, 10) || 1;
        break;
      case 'classtype': {
        const ct = CLASS_TYPES[val];
        if (!ct) throw new Error(`unknown classtype "${val}" at ${location}`);
        rule.classtype = val;
        rule.category = ct.category;
        rule.priority = ct.priority;
        break;
      }
      case 'priority':
        rule.priority = parseInt(val, 10);
        if (!Number.isInteger(rule.priority) || rule.priority < 1 || rule.priority > 4) {
          throw new Error(`invalid priority "${val}" at ${location}`);
        }
        break;
      case 'content': {
        const c = parseContentValue(val);
        rule.contents.push(c);
        if (c.rest) {
          for (const modTok of c.rest.split(/\s+/).filter(Boolean)) {
            const mi = modTok.indexOf(':');
            const mKey = (mi === -1 ? modTok : modTok.slice(0, mi)).trim().toLowerCase();
            const mVal = mi === -1 ? '' : modTok.slice(mi + 1).trim();
            if (mKey === 'nocase') c.nocase = true;
            else if (mKey === 'fast_pattern') c.fastPattern = true;
            else if (['depth', 'offset', 'distance', 'within'].includes(mKey)) {
              const n = parseInt(mVal, 10);
              if (!Number.isInteger(n) || n < 0) throw new Error(`invalid ${mKey} "${mVal}" at ${location}`);
              c[mKey] = n;
            } else {
              throw new Error(`unknown content modifier "${mKey}" at ${location}`);
            }
          }
        }
        delete c.rest;
        break;
      }
      case 'nocase':
        if (rule.contents.length > 0) rule.contents[rule.contents.length - 1].nocase = true;
        break;
      case 'depth':
      case 'offset':
      case 'distance':
      case 'within': {
        const n = parseInt(val, 10);
        if (!Number.isInteger(n) || n < 0) throw new Error(`invalid ${key} "${val}" at ${location}`);
        if (rule.contents.length > 0) rule.contents[rule.contents.length - 1][key] = n;
        break;
      }
      case 'fast_pattern':
        if (rule.contents.length > 0) rule.contents[rule.contents.length - 1].fastPattern = true;
        break;
      case 'pcre':
        rule.pcre = parsePcre(val);
        break;
      case 'flags':
        rule.flags = parseFlags(val);
        break;
      case 'flow':
        rule.flow = val.split(',').map((s) => s.trim()).filter(Boolean);
        break;
      case 'threshold':
      case 'detection_filter':
        rule.threshold = parseThreshold(val, location);
        break;
      case 'itype':
        rule.itype = Number(val);
        break;
      case 'icode':
        rule.icode = Number(val);
        break;
      case 'dsize':
        rule.dsize = parseDsize(val);
        break;
      case 'sameip':
        rule.sameip = true;
        break;
      case 'reference': {
        const i2 = val.indexOf(',');
        rule.references.push(i2 === -1 ? { type: val, id: '' } : { type: val.slice(0, i2), id: val.slice(i2 + 1) });
        break;
      }
      case 'metadata':
        for (const tok of val.split(',')) {
          const i2 = tok.indexOf(' ');
          rule.metadata.push(i2 === -1 ? [tok.trim(), ''] : [tok.slice(0, i2).trim(), tok.slice(i2 + 1).trim()]);
        }
        break;
      default:
        if (!KNOWN_OPTIONS.has(key)) rule.warnings.push(`unknown option "${key}" ignored at ${location}`);
    }
  }

  if (!rule.sid) throw new Error(`rule missing required sid at ${location}`);
  if (seenSid.has(rule.sid)) throw new Error(`duplicate sid ${rule.sid} at ${location}`);
  seenSid.add(rule.sid);
  if (!rule.msg) rule.msg = `Signature ${rule.sid}`;
  if (!rule.classtype) {
    rule.classtype = 'bad-unknown';
    rule.category = CLASS_TYPES['bad-unknown'].category;
    if (rule.priority === undefined) rule.priority = 3;
  }
  if (rule.priority === undefined) rule.priority = CLASS_TYPES[rule.classtype].priority;
  rule.severity = PRIORITY_TO_SEVERITY[Math.min(4, Math.max(1, rule.priority))] || 'medium';

  const portVar = (raw) => {
    if (raw.startsWith('$')) {
      const v = vars[raw.slice(1)];
      if (Array.isArray(v) && v.every((p) => Number.isInteger(p))) {
        return '[' + v.join(',') + ']';
      }
      throw new Error(`unknown port variable ${raw} at ${location}`);
    }
    return raw;
  };

  rule.srcIpSpec = parseIpSpec(srcIpRaw, vars);
  rule.dstIpSpec = parseIpSpec(dstIpRaw, vars);
  rule.srcPortSpec = parsePortSpec(portVar(srcPortRaw));
  rule.dstPortSpec = parsePortSpec(portVar(dstPortRaw));
  if (!rule.srcIpSpec || !rule.dstIpSpec || !rule.srcPortSpec || !rule.dstPortSpec) {
    throw new Error(`invalid address/port spec at ${location}`);
  }
  if (rule.proto !== 'tcp' && rule.flags) {
    rule.warnings.push(`flags option ignored for non-TCP rule at ${location}`);
  }
  if (rule.proto === 'tcp' && rule.itype !== null) {
    rule.warnings.push(`itype option on TCP rule ignored at ${location}`);
  }
  if (['drop', 'reject'].includes(action)) {
    rule.warnings.push(`action "${action}" is passive in NIDS mode; treated as alert at ${location}`);
    rule.action = 'alert';
  }
  if (action === 'pass') rule.disabled = true; // pass rules are unsupported offline; disabled, never silently matched
  return rule;
}

class RuleSet {
  constructor(vars) {
    this.vars = vars;
    this.rules = [];
    this.errors = [];
    this._bySid = new Map();
    this._thresholdState = new Map();
  }

  loadFile(filePath) {
    const fileName = path.basename(filePath);
    let text;
    try {
      text = fs.readFileSync(filePath, 'utf8');
    } catch (err) {
      this.errors.push({ file: fileName, line: 0, error: `cannot read file: ${err.message}` });
      return;
    }
    const lines = text.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const raw = lines[i];
      const line = raw.replace(/#.*$/, '').trim();
      if (!line) continue;
      try {
        const rule = parseRuleLine(line, fileName, i + 1, this.vars);
        rule.raw = raw.trimEnd();
        if (this._bySid.has(rule.sid)) {
          this.errors.push({ file: fileName, line: i + 1, error: `duplicate sid ${rule.sid} (already defined in ${this._bySid.get(rule.sid).file}:${this._bySid.get(rule.sid).line})` });
          continue;
        }
        this._bySid.set(rule.sid, rule);
        if (!rule.disabled) this.rules.push(rule);
      } catch (err) {
        this.errors.push({ file: fileName, line: i + 1, error: err.message });
      }
    }
  }

  get size() {
    return this.rules.length;
  }

  /** Match a single decoded packet against all rules. Returns array of match descriptors. */
  matchPacket(pkt) {
    const out = [];
    for (const rule of this.rules) {
      if (this._ruleMatches(rule, pkt)) {
        const th = this._applyThreshold(rule, pkt);
        if (th.emit) {
          out.push({
            rule,
            throttled: th.throttled,
            thresholdCount: th.count,
          });
        }
      }
    }
    return out;
  }

  _ruleMatches(rule, pkt) {
    if (rule.proto !== 'ip' && rule.proto !== pkt.proto) return false;
    if (rule.direction === '<>') {
      // bidirectional: endpoints may match in either order
      const normal = this._endpointsMatch(rule, pkt.srcIp, pkt.srcPort, pkt.dstIp, pkt.dstPort);
      const swapped = this._endpointsMatch(rule, pkt.dstIp, pkt.dstPort, pkt.srcIp, pkt.srcPort);
      if (!normal && !swapped) return false;
      return this._payloadMatch(rule, pkt, pkt.payload);
    }
    if (!this._endpointsMatch(rule, pkt.srcIp, pkt.srcPort, pkt.dstIp, pkt.dstPort)) return false;
    return this._payloadMatch(rule, pkt, pkt.payload);
  }

  _endpointsMatch(rule, srcIp, srcPort, dstIp, dstPort) {
    if (!ipMatches(srcIp, rule.srcIpSpec)) return false;
    if (!portMatches(srcPort, rule.srcPortSpec)) return false;
    if (!ipMatches(dstIp, rule.dstIpSpec)) return false;
    if (!portMatches(dstPort, rule.dstPortSpec)) return false;
    if (rule.sameip && srcIp === dstIp) return true;
    return true;
  }

  _payloadMatch(rule, pkt, payload) {
    if (rule.itype !== null && !(pkt.icmp && pkt.icmp.type === rule.itype)) return false;
    if (rule.icode !== null && !(pkt.icmp && pkt.icmp.code === rule.icode)) return false;
    if (rule.dsize) {
      const len = payload ? payload.length : 0;
      const d = rule.dsize;
      let ok = false;
      switch (d.op) {
        case '>': ok = len > d.a; break;
        case '<': ok = len < d.a; break;
        case '>=': ok = len >= d.a; break;
        case '<=': ok = len <= d.a; break;
        case '!=': ok = len !== d.a; break;
        case 'range': ok = len > d.a && len < d.b; break;
        default: ok = len === d.a;
      }
      if (!ok) return false;
    }
    if (rule.flags && pkt.proto === 'tcp' && pkt.tcp) {
      const f = rule.flags;
      const all = pkt.tcp.flags;
      if (f.negated) {
        if ((all & f.mask) === f.value) return false;
      } else if ((all & f.mask) !== f.value) {
        return false;
      }
    }
    if (rule.flow && pkt.proto === 'tcp' && pkt.tcp) {
      for (const f of rule.flow) {
        if (f === 'established' && !(pkt.tcp.flags & FLAG_LETTERS.A) && !(pkt.tcp.flags & FLAG_LETTERS.R)) {
          // rough offline approximation: ACK/RST present, or data payload present
          if (!payload || payload.length === 0) return false;
        }
        if (f === 'no_stream' && payload && payload.length > 0) return false;
      }
    }
    if (rule.contents.length > 0) {
      if (!payload || payload.length === 0) return false;
      let searchFrom = 0;
      let prevEnd = 0;
      for (const c of rule.contents) {
        const needle = c.bytes;
        const start = c.offset !== undefined ? Math.min(c.offset, payload.length) : searchFrom;
        let end = c.depth !== undefined ? Math.min(start + c.depth, payload.length) : payload.length;
        if (c.within !== undefined) end = Math.min(end, prevEnd + c.within);
        const slice = payload.subarray(start, Math.max(start, end));
        let idx;
        if (c.nocase) {
          idx = slice.toString('latin1').toLowerCase().indexOf(needle.toString('latin1').toLowerCase());
        } else {
          idx = bufferIndexOf(slice, needle);
        }
        const found = idx !== -1;
        if (c.negated) {
          if (found) return false;
          continue;
        }
        if (!found) return false;
        prevEnd = start + idx + needle.length;
        searchFrom = prevEnd;
        if (c.distance !== undefined) searchFrom += c.distance;
      }
    }
    if (rule.pcre) {
      if (!payload || payload.length === 0) return false;
      const hit = rule.pcre.re.test(payload.toString('latin1'));
      rule.pcre.re.lastIndex = 0;
      if (rule.pcre.negated ? hit : !hit) return false;
    }
    return true;
  }

  _applyThreshold(rule, pkt) {
    if (!rule.threshold) return { emit: true, throttled: false, count: 1 };
    const t = rule.threshold;
    const keyIp = t.track === 'by_dst' ? pkt.dstIp : pkt.srcIp;
    const now = pkt.tsSec;
    const key = `${rule.sid}:${t.track}:${keyIp}`;
    let st = this._thresholdState.get(key);
    if (!st || now - st.windowStart >= t.seconds) {
      st = { windowStart: now, count: 0, emitted: 0 };
      this._thresholdState.set(key, st);
    }
    st.count++;
    if (t.type === 'limit' || t.type === 'both') {
      if (st.emitted >= t.count) return { emit: false, throttled: true, count: st.count };
      st.emitted++;
      return { emit: true, throttled: false, count: st.count };
    }
    // type 'threshold': emit only when count reached, once per window
    if (st.count >= t.count && !st.emitted) {
      st.emitted = 1;
      return { emit: true, throttled: false, count: st.count };
    }
    return { emit: false, throttled: true, count: st.count };
  }

  listPublic() {
    return {
      count: this.rules.length,
      errors: this.errors,
      rules: this.rules.map((r) => ({
        sid: r.sid, gid: r.gid || 1, rev: r.rev || 1, msg: r.msg, action: r.action,
        proto: r.proto, classtype: r.classtype, category: r.category,
        severity: r.severity, priority: r.priority,
        source: `${r.file}:${r.line}`,
        references: r.references, metadata: r.metadata, warnings: r.warnings,
        raw: r.raw,
      })),
    };
  }
}

function bufferIndexOf(haystack, needle) {
  if (needle.length === 0) return 0;
  if (needle.length > haystack.length) return -1;
  outer: for (let i = 0; i <= haystack.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) {
      if (haystack[i + j] !== needle[j]) continue outer;
    }
    return i;
  }
  return -1;
}

function loadRuleSet(vars, dirs) {
  const rs = new RuleSet(vars);
  for (const d of dirs) {
    let files;
    try {
      files = fs.readdirSync(d).filter((f) => f.endsWith('.rules')).sort();
    } catch (err) {
      rs.errors.push({ file: d, line: 0, error: `cannot list rules directory: ${err.message}` });
      continue;
    }
    for (const f of files) rs.loadFile(path.join(d, f));
  }
  return rs;
}

module.exports = { RuleSet, loadRuleSet, parseRuleLine, CLASS_TYPES };
