'use strict';

/**
 * Recommended defensive actions per alert category. These are advisory
 * analyst guidance only — Sentinel NIDS never blocks hosts or changes
 * firewall rules automatically.
 */

const ACTIONS = {
  'Attempted Reconnaissance': [
    'Verify whether the source IP belongs to an authorized vulnerability scanner or penetration test.',
    'Review firewall/IDS logs for the source IP across the rest of the network.',
    'If unauthorized, consider blocking the source at the perimeter firewall after analyst confirmation.',
    'Check whether any scanned ports answered (completed handshakes) and investigate those hosts.',
  ],
  'Attempted Administrator Privilege Gain': [
    'Treat as high priority: check authentication logs on the targeted service for successful logins after the attempts.',
    'Verify the targeted account is not locked out and no unauthorized session exists.',
    'Enforce MFA on the affected service and rate-limit or fail2ban-style throttle the source.',
    'Reset credentials for any account that shows a successful login from the source IP.',
  ],
  'Attempted User Privilege Gain': [
    'Check the targeted service logs for successful authentications following the attempts.',
    'Temporarily throttle or challenge authentication attempts from the source IP.',
    'Educate/verify the account owner; reset the password if any doubt remains.',
  ],
  'Attempted Denial of Service': [
    'Confirm service availability and baseline latency for the targeted host.',
    'Apply rate limiting or upstream scrubbing if the pattern persists.',
    'Capture traffic to characterize the flood (volume, protocol, amplification).',
  ],
  'Web Application Attack': [
    'Inspect the targeted application logs for the request and confirm whether it was rejected.',
    'Verify input validation / WAF rules cover the observed payload class.',
    'If the attack succeeded, invoke the application incident-response runbook (patch, review data access).',
  ],
  'A Network Trojan was Detected': [
    'Isolate the suspected host from the network for triage.',
    'Collect memory/disk artifacts before reimaging.',
    'Block the C2 indicator (IP/domain) at the proxy/DNS after analyst approval.',
    'Hunt for the same indicator across other hosts.',
  ],
  'Potentially Bad Traffic': [
    'Validate the behavior against the host owner and expected application traffic.',
    'Check for policy violations (unexpected protocols, oversized transfers, tunneling).',
    'Escalate if the traffic involves sensitive destinations or persists after verification.',
  ],
  'Protocol Command Decode': [
    'Review the protocol transaction in the flow data; anomalous commands may indicate probing.',
    'Confirm the service version is patched for known protocol abuses.',
  ],
  'Potential Corporate Privacy Violation': [
    'Verify the connection is sanctioned by policy (approved service, approved route).',
    'If unsanctioned, restrict access and review data transferred.',
  ],
  'Misc Attack': [
    'Correlate with surrounding alerts from the same source IP.',
    'Review the matched signature and payload preview to confirm relevance.',
  ],
  'Misc Activity': [
    'Low priority: review in the context of the host role and baseline behavior.',
    'Tune or suppress the rule if it is noisy and irrelevant in your environment.',
  ],
  'Uncategorized': [
    'Review the alert details, payload preview, and related flows.',
    'Classify and document findings in the investigation notes.',
  ],
};

function recommendationsFor(category) {
  return ACTIONS[category] || ACTIONS.Uncategorized;
}

module.exports = { recommendationsFor, ACTIONS };
