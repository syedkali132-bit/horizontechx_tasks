'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DEFAULT_VARS = {
  HOME_NET: ['192.168.0.0/16', '10.0.0.0/8', '172.16.0.0/12'],
  EXTERNAL_NET: ['!$HOME_NET'],
  HTTP_PORTS: [80, 8080],
  IRC_PORTS: [6667, 6697],
  SSH_PORTS: [22],
};

function fail(msg) {
  throw new Error(`Configuration error: ${msg}`);
}

function isValidIp(ip) {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(ip) && ip.split('.').every((o) => Number(o) <= 255);
}

function validate(raw) {
  if (!raw || typeof raw !== 'object') fail('config root must be a JSON object');
  const c = { ...raw };

  c.host = typeof c.host === 'string' && c.host.length > 0 ? c.host : '127.0.0.1';
  c.port = Number.isInteger(c.port) && c.port > 0 && c.port < 65536 ? c.port : 8080;

  if (!c.network || !Array.isArray(c.network.homeNet) || c.network.homeNet.length === 0) {
    fail('network.homeNet must be a non-empty array of CIDR ranges');
  }
  for (const cidr of c.network.homeNet) {
    const ip = String(cidr).split('/')[0];
    if (!isValidIp(ip)) fail(`network.homeNet entry "${cidr}" is not a valid IPv4 network`);
  }

  c.engine = c.engine || {};
  c.engine.preferred = c.engine.preferred === 'snort' ? 'snort' : 'suricata';
  c.engine.suricataPath = c.engine.suricataPath || 'suricata';
  c.engine.snortPath = c.engine.snortPath || 'snort';
  c.engine.interface = c.engine.interface || null;

  c.heuristics = {
    portScanDistinctPorts: positiveInt(c.heuristics?.portScanDistinctPorts, 15),
    portScanWindowSec: positiveInt(c.heuristics?.portScanWindowSec, 60),
    failedConnThreshold: positiveInt(c.heuristics?.failedConnThreshold, 8),
    failedConnWindowSec: positiveInt(c.heuristics?.failedConnWindowSec, 120),
    connRateThreshold: positiveInt(c.heuristics?.connRateThreshold, 120),
    connRateWindowSec: positiveInt(c.heuristics?.connRateWindowSec, 60),
    exfilBytes: positiveInt(c.heuristics?.exfilBytes, 50000000),
  };

  c.monitor = c.monitor || {};
  c.monitor.watchDir = c.monitor.watchDir || 'data/uploads';
  c.monitor.pollIntervalMs = positiveInt(c.monitor.pollIntervalMs, 2000);

  const sevOrder = ['low', 'medium', 'high', 'critical'];
  c.notifications = c.notifications || {};
  c.notifications.webhookUrl = c.notifications.webhookUrl || null;
  c.notifications.minSeverity = sevOrder.includes(c.notifications?.minSeverity)
    ? c.notifications.minSeverity
    : 'high';

  c.retention = {
    alertsDays: positiveInt(c.retention?.alertsDays, 30),
    pcapKeepHours: positiveInt(c.retention?.pcapKeepHours, 24),
  };

  if (process.env.NIDS_HOST) c.host = process.env.NIDS_HOST;
  if (process.env.NIDS_PORT) {
    const p = Number(process.env.NIDS_PORT);
    if (!Number.isInteger(p) || p < 0 || p > 65535) fail('NIDS_PORT must be an integer 0-65535 (0 = ephemeral, tests only)');
    c.port = p;
  }
  if (process.env.NIDS_DATA_DIR) c.dataDir = process.env.NIDS_DATA_DIR;
  return c;
}

function positiveInt(v, dflt) {
  const n = Number(v);
  return Number.isInteger(n) && n > 0 ? n : dflt;
}

function loadConfig() {
  const file = path.join(ROOT, 'config', 'nids.config.json');
  let raw;
  try {
    raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (err) {
    fail(`cannot read ${file}: ${err.message}`);
  }
  const config = validate(raw);

  config.vars = { ...DEFAULT_VARS };
  config.vars.HOME_NET = config.network.homeNet;
  config.vars.EXTERNAL_NET = ['!$HOME_NET'];
  config.vars.HTTP_PORTS = config.network.httpPorts || DEFAULT_VARS.HTTP_PORTS;

  const overridesFile = path.join(config.dataDir.startsWith(path.sep) || /^[A-Za-z]:/.test(config.dataDir)
    ? config.dataDir
    : path.join(ROOT, config.dataDir), 'config.overrides.json');
  if (fs.existsSync(overridesFile)) {
    try {
      const ov = JSON.parse(fs.readFileSync(overridesFile, 'utf8'));
      if (ov.notifications) {
        config.notifications = { ...config.notifications, ...ov.notifications };
      }
    } catch {
      // Overrides are best-effort; the base config stays authoritative.
    }
  }
  config._overridesFile = overridesFile;
  config.ROOT = ROOT;
  return config;
}

module.exports = { loadConfig, DEFAULT_VARS };
