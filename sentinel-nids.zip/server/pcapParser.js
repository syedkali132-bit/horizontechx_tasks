'use strict';

/**
 * Minimal, dependency-free PCAP / PCAPNG reader with protocol decoding.
 * Supports link types: Ethernet (1), Raw IPv4/IPv6 (12, 101, 228), Linux SLL (113).
 * Decodes Ethernet (incl. 802.1Q VLAN), IPv4, IPv6 (no extension chain beyond
 * hop-by-hop routing headers best-effort), TCP, UDP, ICMPv4, ICMPv6.
 */

const fs = require('fs');

const LINKTYPE_ETHERNET = 1;
const LINKTYPE_RAW = 12;
const LINKTYPE_LINUX_SLL = 113;
const LINKTYPE_RAW_ALT = 101;
const LINKTYPE_IPV6 = 229;

class PcapError extends Error {}

function readFile(path) {
  let buf;
  try {
    buf = fs.readFileSync(path);
  } catch (err) {
    throw new PcapError(`cannot read PCAP file: ${err.message}`);
  }
  return parseBuffer(buf);
}

function parseBuffer(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 4) throw new PcapError('file too small to be a PCAP');
  const magic = buf.readUInt32LE(0);
  if (magic === 0xa1b2c3d4 || magic === 0xd4c3b2a1 || magic === 0xa1b23c4d || magic === 0x4d3cb2a1) {
    return parseClassic(buf, magic);
  }
  // PCAPNG: byte-order magic inside Section Header Block
  if (buf.length >= 12) {
    const bom = buf.readUInt32LE(8);
    if (bom === 0x1a2b3c4d) return parsePcapng(buf, false);
    if (bom === 0xd4c3b2a1) return parsePcapng(buf, true);
  }
  throw new PcapError('unrecognized capture format (not libpcap or pcapng)');
}

function parseClassic(buf, magic) {
  const nano = magic === 0xa1b23c4d || magic === 0x4d3cb2a1;
  const swapped = magic === 0xd4c3b2a1 || magic === 0x4d3cb2a1;
  const u16 = swapped ? 'readUInt16BE' : 'readUInt16LE';
  const u32 = swapped ? 'readUInt32BE' : 'readUInt32LE';
  if (buf.length < 24) throw new PcapError('truncated global header');
  const linkType = buf[u16](20) & 0xffff;
  const packets = [];
  let off = 24;
  while (off + 16 <= buf.length) {
    const tsSec = buf[u32](off);
    let tsUsec = buf[u32](off + 4);
    if (nano) tsUsec = Math.floor(tsUsec / 1000);
    const inclLen = buf[u32](off + 8);
    const origLen = buf[u32](off + 12);
    off += 16;
    if (inclLen > buf.length - off) break; // truncated record: stop cleanly
    const data = buf.subarray(off, off + inclLen);
    packets.push(decodeLink(data, linkType, tsSec, tsUsec, origLen));
    off += inclLen;
  }
  return { format: 'pcap', linkType, packets, warnings: [] };
}

function parsePcapng(buf, swapped) {
  const u16 = swapped ? 'readUInt16BE' : 'readUInt16LE';
  const u32 = swapped ? 'readUInt32BE' : 'readUInt32LE';
  const packets = [];
  const interfaces = [];
  const warnings = [];
  let off = 0;
  let seenShb = false;
  while (off + 12 <= buf.length) {
    const blockType = buf[u32](off);
    const blockLen = buf[u32](off + 4);
    if (blockLen < 12 || off + blockLen > buf.length) {
      warnings.push(`truncated pcapng block at offset ${off}; stopping`);
      break;
    }
    const body = buf.subarray(off + 8, off + blockLen - 4);
    if (blockType === 0x0a0d0d0a) {
      seenShb = true;
    } else if (blockType === 0x00000001) {
      // Interface Description Block
      if (body.length < 8) throw new PcapError('malformed pcapng interface block');
      interfaces.push({ linkType: body[u16](0) & 0xffff, tsresol: 6 });
    } else if (blockType === 0x00000006) {
      // Enhanced Packet Block
      if (body.length < 20) throw new PcapError('malformed pcapng enhanced packet block');
      const ifIndex = body[u32](0);
      const tsHigh = body[u32](4);
      const tsLow = body[u32](8);
      const capLen = body[u32](12);
      const iface = interfaces[ifIndex] || { linkType: LINKTYPE_ETHERNET, tsresol: 6 };
      const resol = iface.tsresol || 6;
      let tsUsec;
      if (resol > 0) {
        tsUsec = Math.floor(((tsHigh * 0x100000000 + tsLow) * Math.pow(10, 6 - Math.min(resol, 6))) % 1000000);
      } else {
        tsUsec = 0;
      }
      const tsSec = Math.floor((tsHigh * 0x100000000 + tsLow) / Math.pow(10, Math.min(resol, 6) || 6));
      if (capLen <= body.length - 20) {
        packets.push(decodeLink(body.subarray(20, 20 + capLen), iface.linkType, tsSec, tsUsec, body[u32](16)));
      }
    } else if (blockType === 0x00000003) {
      // Simple Packet Block
      if (body.length >= 4) {
        const pktLen = body[u32](0);
        const data = body.subarray(4, 4 + Math.min(pktLen, body.length - 4));
        const iface = interfaces[0] || { linkType: LINKTYPE_ETHERNET };
        packets.push(decodeLink(data, iface.linkType, packets.length, 0, pktLen));
      }
    }
    off += blockLen;
  }
  if (!seenShb) throw new PcapError('malformed pcapng: no section header block');
  const linkType = interfaces.length > 0 ? interfaces[0].linkType : LINKTYPE_ETHERNET;
  return { format: 'pcapng', linkType, packets, warnings };
}

function decodeLink(data, linkType, tsSec, tsUsec, origLen) {
  const pkt = {
    tsSec, tsUsec,
    origLen: origLen !== undefined ? origLen : data.length,
    linkType,
    malformed: false,
  };
  try {
    if (linkType === LINKTYPE_ETHERNET) decodeEthernet(data, pkt);
    else if (linkType === LINKTYPE_RAW || linkType === LINKTYPE_RAW_ALT || linkType === LINKTYPE_IPV6) decodeNetwork(data, pkt);
    else if (linkType === LINKTYPE_LINUX_SLL) decodeSll(data, pkt);
    else pkt.unsupportedLinkType = linkType;
  } catch {
    pkt.malformed = true;
  }
  return pkt;
}

function decodeEthernet(data, pkt) {
  if (data.length < 14) throw new Error('short ethernet');
  let etherType = data.readUInt16BE(12);
  let off = 14;
  while (etherType === 0x8100 || etherType === 0x88a8) {
    if (data.length < off + 4) throw new Error('short vlan');
    etherType = data.readUInt16BE(off + 2);
    off += 4;
  }
  pkt.srcMac = macToString(data.subarray(6, 12));
  pkt.dstMac = macToString(data.subarray(0, 6));
  decodeNetwork(data.subarray(off), pkt, etherType);
}

function decodeSll(data, pkt) {
  if (data.length < 16) throw new Error('short sll');
  const proto = data.readUInt16BE(14);
  decodeNetwork(data.subarray(16), pkt, proto);
}

function decodeNetwork(data, pkt, etherType) {
  if (data.length < 1) throw new Error('empty network payload');
  const version = data[0] >> 4;
  if (etherType === undefined) {
    if (version === 4) etherType = 0x0800;
    else if (version === 6) etherType = 0x86dd;
    else throw new Error('unknown network layer version');
  }
  if (etherType === 0x0800) decodeIpv4(data, pkt);
  else if (etherType === 0x86dd) decodeIpv6(data, pkt);
  else pkt.unsupportedEtherType = etherType;
}

function decodeIpv4(data, pkt) {
  if (data.length < 20) throw new Error('short ipv4');
  const ihl = (data[0] & 0x0f) * 4;
  if (data.length < ihl || ihl < 20) throw new Error('bad ipv4 header length');
  pkt.proto = protoName(data[9]);
  pkt.ipProtoNum = data[9];
  pkt.srcIp = `${data[12]}.${data[13]}.${data[14]}.${data[15]}`;
  pkt.dstIp = `${data[16]}.${data[17]}.${data[18]}.${data[19]}`;
  pkt.ttl = data[8];
  pkt.ipLen = data.readUInt16BE(2);
  const frag = data.readUInt16BE(6);
  pkt.moreFragments = (frag & 0x2000) !== 0;
  pkt.fragmentOffset = frag & 0x1fff;
  const payload = data.subarray(ihl, Math.min(pkt.ipLen, data.length));
  decodeTransport(payload, pkt);
}

function decodeIpv6(data, pkt) {
  if (data.length < 40) throw new Error('short ipv6');
  const nextHeader = data[6];
  pkt.proto = protoName(nextHeader);
  pkt.ipProtoNum = nextHeader;
  pkt.srcIp = ipv6ToString(data.subarray(8, 24));
  pkt.dstIp = ipv6ToString(data.subarray(24, 40));
  pkt.ttl = data[7];
  const payloadLen = data.readUInt16BE(4);
  let payload = data.subarray(40, 40 + Math.min(payloadLen, data.length - 40));
  let nh = nextHeader;
  // walk a limited number of common extension headers
  let guard = 0;
  while ([0, 43, 60].includes(nh) && payload.length >= 8 && guard++ < 8) {
    nh = payload[0];
    const hdrLen = (payload[1] + 1) * 8;
    payload = payload.subarray(hdrLen);
  }
  if (nh === 44 && payload.length >= 8) {
    // fragment header
    nh = payload[0];
    payload = payload.subarray(8);
  }
  pkt.proto = protoName(nh);
  pkt.ipProtoNum = nh;
  decodeTransport(payload, pkt);
}

function decodeTransport(payload, pkt) {
  if (pkt.proto === 'tcp') {
    if (payload.length < 20) {
      pkt.malformed = true;
      return;
    }
    const dataOffset = (payload[12] >> 4) * 4;
    pkt.tcp = {
      srcPort: payload.readUInt16BE(0),
      dstPort: payload.readUInt16BE(2),
      seq: payload.readUInt32BE(4),
      ack: payload.readUInt32BE(8),
      flags: payload[13],
      window: payload.readUInt16BE(14),
    };
    pkt.srcPort = pkt.tcp.srcPort;
    pkt.dstPort = pkt.tcp.dstPort;
    const pl = dataOffset >= 20 && dataOffset <= payload.length ? payload.subarray(dataOffset) : Buffer.alloc(0);
    pkt.payload = pl;
    pkt.transportLen = payload.length;
  } else if (pkt.proto === 'udp') {
    if (payload.length < 8) {
      pkt.malformed = true;
      return;
    }
    pkt.udp = {
      srcPort: payload.readUInt16BE(0),
      dstPort: payload.readUInt16BE(2),
      length: payload.readUInt16BE(4),
    };
    pkt.srcPort = pkt.udp.srcPort;
    pkt.dstPort = pkt.udp.dstPort;
    pkt.payload = payload.subarray(8, Math.min(8 + pkt.udp.length - 8, payload.length));
    pkt.transportLen = payload.length;
  } else if (pkt.proto === 'icmp') {
    if (payload.length < 4) {
      pkt.malformed = true;
      return;
    }
    pkt.icmp = { type: payload[0], code: payload[1] };
    pkt.payload = payload.subarray(4);
  } else {
    pkt.payload = payload;
  }
}

function protoName(num) {
  switch (num) {
    case 1: return 'icmp';
    case 6: return 'tcp';
    case 17: return 'udp';
    case 58: return 'icmp';
    default: return 'ip';
  }
}

function macToString(b) {
  return [...b].map((x) => x.toString(16).padStart(2, '0')).join(':');
}

function ipv6ToString(b) {
  const parts = [];
  for (let i = 0; i < 16; i += 2) parts.push(b.readUInt16BE(i).toString(16));
  return parts.join(':');
}

module.exports = { readFile, parseBuffer, PcapError, LINKTYPE_ETHERNET };
