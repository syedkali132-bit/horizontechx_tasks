# Sentinel NIDS — Network Intrusion Detection System

Sentinel NIDS is a complete, self-contained network intrusion detection
platform: it monitors network traffic (live via Suricata/Snort when installed,
or continuously over a PCAP drop-zone), detects suspicious activity with
signature rules and behavioral heuristics, records structured alerts, supports
an analyst response workflow, and visualizes everything in a security
operations dashboard.

**Honesty guarantees**

- Every alert carries an explicit origin: `live` (detection engine),
  `pcap` (offline file analysis), `simulated` or `sample` (clearly-labeled
  demonstration records). Simulated/sample records are flagged in every table
  and can never be mistaken for genuine detections.
- The monitoring status shown in the UI always reflects the real process /
  watcher state. If no engine is installed, the dashboard says so and live
  capture is refused with a clear message — nothing is faked.
- Sentinel NIDS never blocks IP addresses or modifies firewall rules. Response
  actions are analyst-driven (acknowledge / resolve / notes) and every action
  is written to an audit log.

---

## Features

| Area | Details |
|---|---|
| Detection engines | Built-in offline analyzer (pure Node.js) + integration layer for Suricata and Snort (live capture, engine PCAP analysis, EVE/fast log ingestion) |
| Signature rules | Snort/Suricata-style rule language subset (documented in `docs/RULES.md`): `content` with `|hex|`, `nocase`, `depth`, `offset`, `distance`, `pcre`, `flags`, `flow`, `dsize`, `itype/icode`, `threshold`, IP/port lists, ranges and negation, `$HOME_NET`/`$EXTERNAL_NET` variables |
| Behavioral heuristics | TCP/UDP port-sweep detection, repeated failed-connection detection, connection-rate floods, large-transfer (exfiltration) detection — all computed from the actual capture |
| PCAP support | Classic libpcap (LE/BE, micro/nano) and pcapng; Ethernet + VLAN, Linux SLL, raw IP; IPv4/IPv6, TCP, UDP, ICMP decode |
| Continuous monitoring | Drop-zone mode (watch a directory, auto-analyze new captures) and live mode (engine child process with alert streaming) with honest start/stop/status |
| Alert management | Structured alerts (timestamp, severity, IPs, ports, protocol, category, signature ID, origin, evidence); filter/search/sort; severity-ranked sorting; pagination |
| Response workflow | Acknowledge/resolve alerts, investigation notes, per-category recommended defensive actions, full audit log, optional webhook notifications for high-severity alerts |
| Dashboard | Dark SOC theme, responsive (desktop/tablet/mobile): overview with real-data charts (severity, 24 h trend, protocols, top talkers), alerts, traffic/flow analysis, rules browser, monitoring control, investigation, settings/docs |
| Access control | Random admin token generated on first boot (`data/.admin-token`) or `NIDS_ADMIN_TOKEN`; required for every mutating endpoint; server binds to 127.0.0.1 by default |

## Technology stack

- **Backend:** Node.js (≥ 22.5 for the built-in `node:sqlite`), Express 4
- **Storage:** SQLite via `node:sqlite` (no native build step)
- **Frontend:** Vanilla JS SPA + Chart.js (vendored locally in `public/vendor/`, works offline)
- **Detection:** built-in analyzer + external Suricata ≥ 4 / Snort 2/3 when present
- **Tests:** dependency-free Node test runner (`tests/run-tests.js`)

## Prerequisites

- Node.js ≥ 22.5 (developed and tested on Node 24). Check with `node --version`.
- npm (ships with Node).
- **Optional:** Suricata or Snort for live capture / engine-backed analysis
  (see *Installing a detection engine*). Without an engine, all offline
  functionality — PCAP analysis, rules, heuristics, dashboard, response
  workflow — works out of the box.

## Installation

```bash
npm install          # installs express + chart.js
npm test             # optional: run the 45-test verification suite
npm start            # starts the dashboard on http://127.0.0.1:8080
npm run make-pcaps   # regenerate the 4 synthetic test captures in examples/
npm run seed-sample  # insert the clearly-labeled SAMPLE dataset into data/nids.db
```

On first start an admin token is generated and saved to `data/.admin-token`.
Paste it into **Settings → Admin access** in the dashboard (or send it as
`Authorization: Bearer <token>`). To provide your own token:

```bash
set NIDS_ADMIN_TOKEN=your-long-random-token   :: Windows
export NIDS_ADMIN_TOKEN=your-long-random-token # Linux/macOS
```

Environment overrides: `NIDS_HOST`, `NIDS_PORT`, `NIDS_DATA_DIR`.

## Configuration

All configuration lives in `config/nids.config.json` (validated at startup;
invalid values produce clear errors and safe defaults are applied where noted):

| Key | Meaning | Default |
|---|---|---|
| `host` / `port` | Dashboard bind address | `127.0.0.1` / `8080` |
| `network.homeNet` | CIDR list treated as internal (`$HOME_NET`) | RFC-1918 ranges |
| `engine.preferred` | `suricata` or `snort` | `suricata` |
| `engine.suricataPath` / `engine.snortPath` | engine binary names/paths | `suricata` / `snort` |
| `engine.interface` | capture interface for live mode (e.g. `eth0`, `\Device\NPF_{...}`) | `null` |
| `engine.suricataConfig` | optional custom `suricata.yaml` | `null` |
| `heuristics.*` | thresholds for port scans, failed connections, connection floods, exfil size | see file |
| `monitor.watchDir` | drop-zone directory | `data/uploads` |
| `notifications.webhookUrl` / `minSeverity` | high-severity webhook target | `null` / `high` |
| `retention.alertsDays` | alert retention | `30` |

Runtime notification overrides are stored in `data/config.overrides.json` via
the Settings page (kept out of the config directory so secrets never ship with
the project).

## Installing a detection engine (optional)

Sentinel NIDS works fully without an engine. To add engine-backed live
detection:

**Suricata (recommended)**

- Windows: install [Npcap](https://npcap.com/) (leave "WinPcap API-compatible
  mode" enabled), then download the official Suricata Windows build and add its
  `suricata.exe` to `PATH` (or set `engine.suricataPath`). Run the console
  **as administrator** for live capture.
- Linux: `sudo apt install suricata` (or your distro equivalent), then
  `sudo suricata-update` for the Emerging Threats ruleset if desired.

**Snort**

- Linux: `sudo apt install snort`. Windows builds are unmaintained; Suricata
  is the recommended engine on Windows.

Point `engine.interface` at the capture interface, e.g. `eth0`, `ens33`, or on
Windows `\Device\NPF_{GUID}` (list them with `suricata --list-interfaces` or
Npcap's `Get-NetAdapter`). The Monitoring page shows engine availability with
versions once it can run `suricata -V` / `snort -V`.

## How to start / stop monitoring

**Dashboard:** Monitoring page → choose the mode → Start / Stop (admin token
required; start/stop asks for confirmation).

- **Drop-zone PCAP monitoring** — watches `data/uploads` and automatically
  analyzes every `.pcap`/`.pcapng` dropped there. Works everywhere, no engine
  needed.
- **Live engine capture** — starts Suricata/Snort on `engine.interface` and
  streams alerts from the EVE/fast log into the dashboard in real time.
  Requires an installed engine and sufficient privileges (admin/root). If the
  engine is missing, the interface is unset, or the spawn fails, you get an
  explicit error and the state stays `inactive`.

**API:**

```bash
curl -X POST http://127.0.0.1:8080/api/monitor/start -H "Authorization: Bearer <token>" \
     -H "Content-Type: application/json" -d '{"mode":"dropzone"}'
curl -X POST http://127.0.0.1:8080/api/monitor/stop  -H "Authorization: Bearer <token>"
curl http://127.0.0.1:8080/api/status                # always shows the true state
```

## How to analyze a PCAP file

**Dashboard:** Monitoring page → drag a `.pcap`/`.pcapng` onto the upload box.

**CLI / API:**

```bash
curl -X POST "http://127.0.0.1:8080/api/pcaps?name=capture.pcap" \
     -H "Authorization: Bearer <token>" --data-binary @capture.pcap
```

The built-in analyzer decodes the capture, runs all loaded rules plus the
behavioral heuristics, stores alerts (origin `pcap`) and full conversation
records (Traffic Analysis page), and returns a summary:

```json
{"ok":true,"file":"...","alertCount":3,"flowCount":33,"packetCount":43}
```

You can also import an existing engine log (Suricata `eve.json` or Snort fast
format) on the Monitoring page or via
`POST /api/logs/import?kind=eve|fast` — alert lines are ingested as origin
`live` with the source engine recorded.

## How to test detection rules

1. Generate the synthetic test captures (fabricated traffic between
   documentation IP ranges — authorized and harmless):

   ```bash
   node scripts/make-test-pcaps.js
   ```

   This writes `examples/portscan.pcap`, `web-attacks.pcap`,
   `brute-force.pcap`, `mixed-traffic.pcap`.

2. Upload each file (Monitoring page). Expected detections:

   | File | Expected alerts |
   |---|---|
   | `portscan.pcap` | NULL-scan sig, XMAS-scan sig, port-sweep heuristic |
   | `web-attacks.pcap` | SQLi sig, directory-traversal sig, wget-UA sig, Nmap-NSE-UA sig |
   | `brute-force.pcap` | SSH brute-force sig (threshold: 1 alert), failed-connections heuristic |
   | `mixed-traffic.pcap` | RDP, FTP anonymous, oversized-ICMP, oversized-DNS, IRC-C2 signatures |

3. Verify the benign traffic in those files (normal DNS, a full HTTP session,
   a regular request) produces **no** alerts.
4. Run the automated suite: `npm test` (45 tests: rule parser, matcher,
   PCAP parser, analyzer end-to-end, full HTTP API workflow).

Custom rules go in `config/rules/local.rules` (sid range 1001000+ reserved);
syntax is documented in `docs/RULES.md`. After editing, use **Rules → Reload
rules** in the dashboard.

## Simulated & sample data

For demonstrations without real traffic, Settings offers:

- **Simulate scenarios** (port scan / brute force / C2) — inserts a few alerts
  with origin `simulated`, `is_simulated=1`, and a `SIMULATED` prefix.
- **Load sample dataset** — 15 alerts with origin `sample` spread over the last
  24 h so all dashboard charts render; every record is flagged
  `is_simulated=1` and prefixed `SAMPLE`.

The dashboard shows a provenance banner whenever such records exist, and the
alerts table tags them distinctly. **These records are never presented as real
detections.**

## Project layout

```
config/nids.config.json    main configuration
config/rules/*.rules       detection rules (community test set + local template)
server/                    Express backend
  ruleEngine.js            Snort/Suricata rule parser + matcher
  pcapParser.js            libpcap/pcapng reader + protocol decode
  analyzer.js              offline detection (signatures + heuristics + flows)
  engine.js                Suricata/Snort integration (capabilities, live, EVE/fast)
  monitor.js               monitoring lifecycle (drop-zone + live), ingestion
  db.js                    SQLite schema/queries (node:sqlite)
  routes/api.js            REST API
public/                    dashboard SPA (vanilla JS + vendored Chart.js)
scripts/make-test-pcaps.js synthetic capture generator
scripts/seed-sample-lib.js labeled sample dataset
scripts/seed-sample.js     CLI wrapper that seeds the sample dataset
tests/run-tests.js         test suite (45 tests)
docs/RULES.md              rule syntax reference
examples/                  generated test captures
data/                      runtime data (SQLite db, uploads, logs, admin token) — recreated at startup
```

## API summary (all under `/api`)

| Endpoint | Auth | Purpose |
|---|---|---|
| `GET /status` | – | server/monitoring state, engine capabilities, config summary |
| `GET /stats/overview` | – | dashboard aggregates (severity, trend, protocols, top IPs, flows) |
| `GET /alerts` | – | list/filter/search/sort/paginate alerts |
| `GET /alerts/:id` | – | alert detail + notes + recommendations |
| `POST /alerts/:id/status` | ✔ | acknowledge / resolve (+ optional note) |
| `POST /alerts/:id/notes` | ✔ | add investigation note |
| `GET /rules` | – | parsed rules + load errors |
| `POST /rules/reload` | ✔ | reload rule files |
| `GET /pcaps`, `GET /traffic/flows` | – | analyzed files, conversation records |
| `POST /pcaps?name=…` | ✔ | upload & analyze a PCAP (raw body) |
| `POST /logs/import?kind=eve\|fast` | ✔ | import engine alert logs |
| `POST /monitor/start|stop` | ✔ | control monitoring (`dropzone`/`live`) |
| `POST /simulate`, `POST /sample-data` | ✔ | clearly-labeled demo data |
| `POST /config/notifications` | ✔ | webhook URL + min severity |
| `GET /audit` | ✔ | response-action audit log |

Errors are JSON: `{"error":"…"}` with appropriate status codes (400/401/403/
404/413/422/500).

## Troubleshooting

- **"Admin token required" (401)** — set the token in Settings; it is printed
  on server startup and stored in `data/.admin-token`.
- **"No Suricata/Snort binary found on PATH"** — install an engine (see above)
  or use drop-zone/offline mode; this is **not** an error for offline work.
- **Live capture fails to spawn / exits immediately** — on Windows run the
  console as administrator and install Npcap; on Linux use `sudo` or grant
  `CAP_NET_RAW`. The exact engine stderr is shown on the Monitoring page and in
  `monitor.status.lastError`.
- **"No capture interface configured"** — set `engine.interface`.
- **Upload rejected (422 "unrecognized capture format")** — the file is not a
  libpcap/pcapng capture (e.g. it is a text TCPdump or a corrupt file).
- **Charts empty** — there are no ingested alerts yet; analyze a PCAP or load
  the sample dataset.
- **Rules not matching** — check Rules page for load errors; verify variables
  (`$HOME_NET`) and direction; note the supported subset in `docs/RULES.md`.
- **Port already in use** — set `NIDS_PORT` or change `port` in the config.

## Known limitations

- The built-in matcher implements a practical **subset** of the Snort/Suricata
  rule language (see `docs/RULES.md`): no `byte_test`/`byte_jump`,
  `flowbits`, `stream` reassembly, `replace`, or `tag`; `flow:established`
  is approximated without TCP state tracking. For full rule semantics run a
  real engine — Sentinel NIDS will ingest its alerts natively.
- Heuristics are threshold-based statistical detectors; they can miss
  slow/low-and-slow scans spread beyond the configured windows.
- The bundled rules are original, clearly-labeled **TEST** signatures for
  validating the pipeline; they are not a replacement for a maintained
  ruleset such as Emerging Threats (which a real Suricata/Snort install can
  provide via `suricata-update`).
- Live capture on Windows requires Npcap and elevated privileges; the
  unbundled-engine environment this project was developed in only allowed
  offline/drop-zone verification (44 automated tests + manual UI verification).
- IPv6 extension-header walking is best-effort; IP fragmentation reassembly
  is not performed (first fragments are decoded, non-initial fragments are
  skipped for content matching).
- The admin token protects mutating API endpoints; the read-only dashboard is
  open on the configured bind address — keep the default `127.0.0.1` binding
  or place Sentinel behind your own authentication if exposing it.

## License

MIT (see `LICENSE`).
