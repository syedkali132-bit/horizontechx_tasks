/* Shared UI components: toasts, modals, formatting helpers. */
(function () {
  'use strict';

  function esc(s) {
    if (s === null || s === undefined) return '';
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function toast(msg, kind = 'info', ms = 4200) {
    const root = document.getElementById('toast-root');
    const el = document.createElement('div');
    el.className = `toast ${kind}`;
    el.textContent = msg;
    root.appendChild(el);
    setTimeout(() => { el.remove(); }, ms);
  }

  function modal({ title, body, actions, wide }) {
    const root = document.getElementById('modal-root');
    root.innerHTML = '';
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    const box = document.createElement('div');
    box.className = 'modal';
    if (wide) box.style.maxWidth = '980px';
    box.innerHTML = `<h2>${esc(title)}</h2><div class="modal-body"></div><div class="modal-actions"></div>`;
    const bodyEl = box.querySelector('.modal-body');
    if (typeof body === 'string') bodyEl.innerHTML = body;
    else bodyEl.appendChild(body);
    const actionsEl = box.querySelector('.modal-actions');
    for (const a of actions || []) {
      const btn = document.createElement('button');
      btn.className = `btn ${a.kind || ''}`;
      btn.textContent = a.label;
      btn.onclick = async () => {
        if (a.onClick) {
          btn.disabled = true;
          try { const r = await a.onClick(); if (r !== false) close(); }
          catch (e) { toast(e.message, 'err'); }
          finally { btn.disabled = false; }
        } else close();
      };
      actionsEl.appendChild(btn);
    }
    overlay.appendChild(box);
    overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) close(); });
    root.appendChild(overlay);
    function close() { root.innerHTML = ''; }
    return { close, bodyEl };
  }

  function confirmDialog(title, message, confirmLabel = 'Confirm', danger = true) {
    return new Promise((resolve) => {
      const m = modal({
        title,
        body: `<p>${esc(message)}</p>`,
        actions: [
          { label: 'Cancel', kind: 'btn-ghost', onClick: () => { resolve(false); } },
          { label: confirmLabel, kind: danger ? 'btn-danger' : 'btn-primary', onClick: () => { resolve(true); } },
        ],
      });
      // resolve(false) when overlay dismissed via background click
      const overlay = m.bodyEl.closest('.modal-overlay');
      overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) resolve(false); });
    });
  }

  function sevBadge(sev) {
    return `<span class="sev sev-${esc(sev)}">${esc(sev)}</span>`;
  }

  function srcTag(source) {
    const labels = { live: 'LIVE', pcap: 'PCAP', simulated: 'SIMULATED', sample: 'SAMPLE' };
    return `<span class="tag tag-${esc(source)}">${labels[source] || esc(source)}</span>`;
  }

  function statusTag(status) {
    return `<span class="tag tag-status-${esc(status)}">${esc(status)}</span>`;
  }

  function fmtTime(ts) {
    if (!ts) return '—';
    const d = new Date(ts * 1000);
    return d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  function fmtNum(n) {
    if (n === null || n === undefined) return '—';
    return Number(n).toLocaleString();
  }

  function fmtBytes(n) {
    if (!n && n !== 0) return '—';
    if (n >= 1e9) return (n / 1e9).toFixed(2) + ' GB';
    if (n >= 1e6) return (n / 1e6).toFixed(2) + ' MB';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + ' KB';
    return n + ' B';
  }

  function emptyState(icon, title, subtitle) {
    return `<div class="empty-state"><div class="big">${icon}</div><h3>${esc(title)}</h3><p>${esc(subtitle || '')}</p></div>`;
  }

  function loading() {
    return '<div class="loading-block"><div class="spinner"></div><p>Loading…</p></div>';
  }

  function errorState(msg) {
    return `<div class="callout error"><strong>Error:</strong> ${esc(msg)}</div>`;
  }

  function pagination(total, page, perPage, onPage) {
    const pages = Math.max(1, Math.ceil(total / perPage));
    if (pages <= 1) return '';
    const wrap = document.createElement('div');
    wrap.style.cssText = 'display:flex;gap:8px;align-items:center;justify-content:flex-end;margin-top:12px;font-size:13px;color:var(--text-dim)';
    const btn = (label, p, disabled) => `<button class="btn btn-sm" data-page="${p}" ${disabled ? 'disabled' : ''}>${label}</button>`;
    wrap.innerHTML = `${btn('← Prev', page - 1, page <= 1)}<span>Page ${page} / ${pages} · ${total} alerts</span>${btn('Next →', page + 1, page >= pages)}`;
    wrap.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-page]');
      if (b && !b.disabled) onPage(Number(b.dataset.page));
    });
    return wrap;
  }

  window.ui = {
    esc, toast, modal, confirmDialog, sevBadge, srcTag, statusTag,
    fmtTime, fmtNum, fmtBytes, emptyState, loading, errorState, pagination,
  };
})();
