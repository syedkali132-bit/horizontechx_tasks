/* Page renderers for the Sentinel NIDS dashboard. */
(function () {
  'use strict';

  const { esc, toast, modal, confirmDialog, sevBadge, srcTag, statusTag, fmtTime, fmtNum, fmtBytes, emptyState, loading, errorState, pagination } = window.ui;

  let charts = [];
  function destroyCharts() {
    for (const c of charts) { try { c.destroy(); } catch { /* already gone */ } }
    charts = [];
  }

  const SEV_ORDER = ['critical', 'high', 'medium', 'low'];

  /* ============================ alert detail ============================ */
  async function alertDetailModal(id) {
    let data;
    try {
      data = await api.get(`/api/alerts/${encodeURIComponent(id)}`);
    } catch (e) {
      toast(e.message, 'err');
      return;
    }
    const a = data.alert;
    const body = document.createElement('div');
    const evidence = a.evidence ? safeJson(a.evidence) : null;
    body.innerHTML = `
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px">
        ${sevBadge(a.severity)} ${srcTag(a.source)} ${statusTag(a.status)}
        ${a.is_simulated ? '<span class="tag tag-simulated">not a real detection</span>' : ''}
      </div>
      <h3 style="font-size:15px;margin:6px 0 2px">${esc(a.signature)}</h3>
      <dl class="kv">
        <dt>Time</dt><dd>${esc(fmtTime(a.ts))}</dd>
        <dt>Source</dt><dd>${esc(a.src_ip || '—')}${a.src_port ? ':' + esc(a.src_port) : ''}</dd>
        <dt>Destination</dt><dd>${esc(a.dst_ip || '—')}${a.dst_port ? ':' + esc(a.dst_port) : ''}</dd>
        <dt>Protocol</dt><dd>${esc((a.proto || '').toUpperCase() || '—')}</dd>
        <dt>Category</dt><dd>${esc(a.category || '—')}</dd>
        <dt>Signature ID</dt><dd>${a.signature_id ? `${esc(a.gid || 1)}:${esc(a.signature_id)}${a.rev ? ':' + esc(a.rev) : ''}` : '—'}</dd>
        <dt>Detection engine</dt><dd>${esc(a.engine || 'builtin analyzer')}</dd>
        <dt>Origin</dt><dd>${esc(a.pcap_file ? 'pcap: ' + a.pcap_file : a.source)}</dd>
        ${a.rule_source ? `<dt>Rule</dt><dd>${esc(a.rule_source)}</dd>` : ''}
        ${a.threshold_count ? `<dt>Threshold count</dt><dd>${esc(a.threshold_count)}</dd>` : ''}
        ${evidence ? `<dt>Evidence</dt><dd>${esc(JSON.stringify(evidence))}</dd>` : ''}
      </dl>
      ${a.payload_preview ? `<h4 class="dim" style="margin:10px 0 4px;font-size:12px;text-transform:uppercase;letter-spacing:.06em">Payload preview</h4><div class="payload-preview">${esc(a.payload_preview)}</div>` : ''}
      <h4 class="dim" style="margin:14px 0 4px;font-size:12px;text-transform:uppercase;letter-spacing:.06em">Description</h4>
      <p>${esc(a.description || '—')}</p>
      <h4 class="dim" style="margin:14px 0 4px;font-size:12px;text-transform:uppercase;letter-spacing:.06em">Recommended defensive actions</h4>
      <ul class="rec-list">${(data.recommendations || []).map((r) => `<li>${esc(r)}</li>`).join('')}</ul>
      <h4 class="dim" style="margin:14px 0 4px;font-size:12px;text-transform:uppercase;letter-spacing:.06em">Investigation notes</h4>
      <div id="detail-notes"></div>
      <textarea id="detail-note-input" rows="2" placeholder="Add an analyst note…" style="width:100%;margin-top:6px"></textarea>
    `;
    const notesEl = body.querySelector('#detail-notes');
    function renderNotes() {
      notesEl.innerHTML = data.notes.length
        ? data.notes.map((n) => `<div class="note"><small>${esc(n.author)} · ${esc(n.created_at)}</small>${esc(n.note)}</div>`).join('')
        : '<p class="dim" style="font-size:13px">No notes yet.</p>';
    }
    renderNotes();

    const actions = [];
    if (a.status !== 'acknowledged') {
      actions.push({
        label: 'Acknowledge', kind: 'btn-primary',
        onClick: async () => {
          await changeStatus(a.id, 'acknowledged');
          return true;
        },
      });
    }
    if (a.status !== 'resolved') {
      actions.push({
        label: 'Mark resolved', kind: 'btn-primary',
        onClick: async () => {
          await changeStatus(a.id, 'resolved');
          return true;
        },
      });
    }
    actions.push({
      label: 'Add note', kind: '',
      onClick: async () => {
        const input = body.querySelector('#detail-note-input');
        const note = input.value.trim();
        if (!note) { toast('Note is empty', 'err'); return false; }
        await api.post(`/api/alerts/${encodeURIComponent(a.id)}/notes`, { note });
        data.notes = await api.get(`/api/alerts/${encodeURIComponent(a.id)}`).then((d) => d.notes);
        renderNotes();
        input.value = '';
        toast('Note added', 'ok');
        return false; // keep modal open
      },
    });
    actions.push({ label: 'Close', kind: 'btn-ghost' });
    modal({ title: 'Alert detail', body, actions, wide: true });

    async function changeStatus(id, status) {
      if (!api.getToken()) {
        toast('Set the admin token first (Settings page)', 'err');
        throw new Error('admin token required');
      }
      try {
        await api.post(`/api/alerts/${encodeURIComponent(id)}/status`, { status });
        toast(`Alert ${status}`, 'ok');
        if (window.refreshCurrentPage) window.refreshCurrentPage();
      } catch (e) {
        toast(e.message, 'err');
        throw e;
      }
    }
  }

  function safeJson(s) {
    try { return JSON.parse(s); } catch { return s; }
  }

  function alertsTable(rows, { onRowClick = true } = {}) {
    if (!rows.length) return emptyState('⚑', 'No alerts match', 'Try relaxing filters or ingest a PCAP / start monitoring.');
    const head = `
      <tr>
        <th>Time</th><th>Severity</th><th>Signature</th><th>Source → Destination</th>
        <th>Proto</th><th>Origin</th><th>Status</th>
      </tr>`;
    const body = rows.map((a) => `
      <tr data-id="${esc(a.id)}" class="${onRowClick ? 'clickable' : ''}">
        <td class="mono-cell" style="white-space:nowrap">${esc(fmtTime(a.ts))}</td>
        <td>${sevBadge(a.severity)}</td>
        <td>${esc(a.signature)}<br><small class="dim">${esc(a.category || '')}</small></td>
        <td class="mono-cell">${esc(a.src_ip || '—')}${a.src_port ? ':' + esc(a.src_port) : ''} → ${esc(a.dst_ip || '—')}${a.dst_port ? ':' + esc(a.dst_port) : ''}</td>
        <td class="mono-cell">${esc((a.proto || '').toUpperCase())}</td>
        <td>${srcTag(a.source)}</td>
        <td>${statusTag(a.status)}</td>
      </tr>`).join('');
    return `<table class="table"><thead>${head}</thead><tbody>${body}</tbody></table>`;
  }

  function bindAlertRows(container) {
    container.querySelectorAll('tr[data-id]').forEach((tr) => {
      tr.addEventListener('click', () => alertDetailModal(tr.dataset.id));
    });
  }

  /* ============================ dashboard ============================ */
  async function renderDashboard(page) {
    page.innerHTML = loading();
    let stats, status;
    try {
      [stats, status] = await Promise.all([api.get('/api/stats/overview'), api.get('/api/status')]);
    } catch (e) {
      page.innerHTML = errorState(e.message);
      return;
    }
    const sevCount = (s) => (stats.bySeverity.find((x) => x.severity === s) || {}).c || 0;
    const mon = status.monitor;
    const monDot = mon.active ? 'dot-green' : 'dot-gray';
    const monText = mon.active ? `Monitoring (${mon.mode})` : 'Monitoring off';

    page.innerHTML = `
      <div class="grid grid-6" style="margin-bottom:16px">
        <div class="card stat-card"><div class="stat-value">${fmtNum(stats.total)}</div><div class="stat-label">Total alerts</div></div>
        <div class="card stat-card stat-crit"><div class="stat-value" style="color:var(--crit)">${fmtNum(sevCount('critical'))}</div><div class="stat-label">Critical</div></div>
        <div class="card stat-card stat-high"><div class="stat-value" style="color:var(--high)">${fmtNum(sevCount('high'))}</div><div class="stat-label">High</div></div>
        <div class="card stat-card stat-med"><div class="stat-value" style="color:var(--med)">${fmtNum(sevCount('medium'))}</div><div class="stat-label">Medium</div></div>
        <div class="card stat-card stat-low"><div class="stat-value" style="color:var(--low)">${fmtNum(sevCount('low'))}</div><div class="stat-label">Low</div></div>
        <div class="card stat-card stat-ok"><div class="stat-value">${fmtNum(stats.newCount)}</div><div class="stat-label">New / unreviewed</div></div>
      </div>
      <div class="callout info" id="data-provenance"></div>
      <div class="grid grid-2" style="margin-bottom:16px">
        <div class="card"><h3>Alert severity distribution</h3><div class="chart-box sm"><canvas id="ch-sev"></canvas></div></div>
        <div class="card"><h3>Alert trend — last 24 hours</h3><div class="chart-box sm"><canvas id="ch-trend"></canvas></div></div>
      </div>
      <div class="grid grid-2" style="margin-bottom:16px">
        <div class="card"><h3>Protocol distribution</h3><div class="chart-box sm"><canvas id="ch-proto"></canvas></div></div>
        <div class="card"><h3>Top source IPs (by alert count)</h3><div class="chart-box sm"><canvas id="ch-topsrc"></canvas></div></div>
      </div>
      <div class="grid grid-2">
        <div class="card">
          <h3>Recent alerts</h3>
          <div id="dash-recent">${stats.recent.length ? alertsTable(stats.recent) : emptyState('⚑', 'No alerts yet', 'Ingest a PCAP on the Monitoring page to see detections.')}</div>
        </div>
        <div class="card">
          <h3>Monitoring status</h3>
          <dl class="kv">
            <dt>State</dt><dd><span class="dot ${monDot}"></span> ${esc(monText)}</dd>
            <dt>Engine</dt><dd>${mon.mode ? esc(mon.mode) : '—'} ${mon.live && mon.live.pid ? `(pid ${esc(mon.live.pid)})` : ''}</dd>
            <dt>Last update</dt><dd>${esc(mon.lastUpdate || 'never')}</dd>
            <dt>Files analyzed</dt><dd>${fmtNum(mon.analyzedCount)}</dd>
            <dt>Suricata</dt><dd>${capLine(status.monitor.capabilities && status.monitor.capabilities.suricata)}</dd>
            <dt>Snort</dt><dd>${capLine(status.monitor.capabilities && status.monitor.capabilities.snort)}</dd>
          </dl>
          ${mon.lastError ? `<div class="callout error"><strong>Last error:</strong> ${esc(mon.lastError)}</div>` : ''}
          <a class="btn btn-sm" href="#/monitoring">Open monitoring →</a>
        </div>
      </div>`;

    // data provenance notice
    const bySrc = stats.bySource || [];
    const parts = bySrc.map((s) => `${s.c} ${s.source}`).join(' · ');
    page.querySelector('#data-provenance').innerHTML = `
      <strong>Data provenance:</strong> statistics below are computed from <em>actual ingested records</em>
      (${fmtNum(stats.total)} alerts${parts ? ' — ' + esc(parts) : ''}).
      ${bySrc.some((s) => s.source === 'sample' || s.source === 'simulated')
        ? '<br><span class="warn-text">This deployment currently contains clearly-labeled SAMPLE/SIMULATED demonstration records. They are flagged in every table and are not real detections.</span>'
        : ''}`;
    bindAlertRows(page.querySelector('#dash-recent'));

    destroyCharts();
    charts.push(makeDoughnut('ch-sev',
      SEV_ORDER.map((s) => s[0].toUpperCase() + s.slice(1)),
      SEV_ORDER.map((s) => sevCount(s)),
      ['#f87171', '#fb923c', '#facc15', '#60a5fa']));
    charts.push(makeDoughnut('ch-proto',
      stats.byProto.map((p) => (p.proto || 'other').toUpperCase()),
      stats.byProto.map((p) => p.c),
      ['#38bdf8', '#818cf8', '#34d399', '#fbbf24', '#f472b6']));

    const tctx = document.getElementById('ch-trend');
    const labels = stats.trend.map((t) => fmtTime(t.bucket).split(', ')[1] || fmtTime(t.bucket));
    charts.push(new Chart(tctx, {
      type: 'line',
      data: { labels, datasets: [{ label: 'Alerts', data: stats.trend.map((t) => t.c), borderColor: '#38bdf8', backgroundColor: 'rgba(56,189,248,.14)', fill: true, tension: .3, pointRadius: 2 }] },
      options: { ...chartBase(), scales: { x: { ticks: { maxTicksLimit: 8 } }, y: { beginAtZero: true, ticks: { precision: 0 } } } },
    }));

    const sctx = document.getElementById('ch-topsrc');
    charts.push(new Chart(sctx, {
      type: 'bar',
      data: {
        labels: stats.topSrc.map((x) => x.ip),
        datasets: [{ data: stats.topSrc.map((x) => x.c), backgroundColor: '#818cf8' }],
      },
      options: { ...chartBase(), indexAxis: 'y', scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } },
    }));
  }

  function capLine(cap) {
    if (!cap) return 'not checked';
    return cap.installed ? `installed (${esc(cap.version || 'version unknown')})` : 'not installed';
  }

  function chartBase() {
    return {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { labels: { color: '#d7e1f0', boxWidth: 12 } } },
    };
  }

  function makeDoughnut(canvasId, labels, data, colors) {
    const el = document.getElementById(canvasId);
    if (!el) return null;
    return new Chart(el, {
      type: 'doughnut',
      data: { labels, datasets: [{ data, backgroundColor: colors, borderColor: '#0f1623', borderWidth: 2 }] },
      options: { ...chartBase(), cutout: '62%' },
    });
  }

  /* ============================ alerts ============================ */
  const alertState = { severity: '', status: '', source: '', q: '', sort: 'ts', dir: 'desc', page: 1, perPage: 25 };

  async function renderAlerts(page) {
    page.innerHTML = loading();
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(alertState)) {
      if (v !== '' && v !== null) params.set(k, v);
    }
    let data;
    try {
      data = await api.get(`/api/alerts?${params.toString()}`);
    } catch (e) {
      page.innerHTML = errorState(e.message);
      return;
    }
    page.innerHTML = `
      <div class="toolbar">
        <select id="f-sev">
          <option value="">All severities</option>
          ${SEV_ORDER.map((s) => `<option ${alertState.severity === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
        <select id="f-status">
          <option value="">All statuses</option>
          ${['new', 'acknowledged', 'resolved'].map((s) => `<option ${alertState.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
        <select id="f-source">
          <option value="">All origins</option>
          ${[['live', 'live (engine)'], ['pcap', 'pcap (offline)'], ['simulated', 'simulated (demo)'], ['sample', 'sample (demo)']].map(([v, l]) => `<option value="${v}" ${alertState.source === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
        <input type="text" id="f-q" class="search-box" placeholder="Search signature, IP, category, SID…" value="${esc(alertState.q)}">
        <button class="btn btn-sm" id="f-go">Search</button>
        <span class="spacer"></span>
        <span class="dim" style="font-size:12.5px">${fmtNum(data.total)} matching alerts</span>
      </div>
      <div class="card" id="alerts-table">${alertsTable(data.rows)}</div>
      <div id="alerts-pager"></div>`;
    bindAlertRows(page.querySelector('#alerts-table'));
    const pager = page.querySelector('#alerts-pager');
    const pg = ui.pagination(data.total, data.page, data.perPage, (p) => { alertState.page = p; renderAlerts(page); });
    if (pg) pager.appendChild(pg);

    page.querySelector('#f-sev').onchange = (e) => { alertState.severity = e.target.value; alertState.page = 1; renderAlerts(page); };
    page.querySelector('#f-status').onchange = (e) => { alertState.status = e.target.value; alertState.page = 1; renderAlerts(page); };
    page.querySelector('#f-source').onchange = (e) => { alertState.source = e.target.value; alertState.page = 1; renderAlerts(page); };
    const doSearch = () => { alertState.q = page.querySelector('#f-q').value; alertState.page = 1; renderAlerts(page); };
    page.querySelector('#f-go').onclick = doSearch;
    page.querySelector('#f-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); });
  }

  /* ============================ traffic ============================ */
  const trafficState = { pcap: '', proto: '', q: '' };

  async function renderTraffic(page) {
    page.innerHTML = loading();
    let pcaps, flowsData;
    try {
      pcaps = await api.get('/api/pcaps');
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(trafficState)) if (v) params.set(k, v);
      flowsData = await api.get(`/api/traffic/flows?${params.toString()}`);
    } catch (e) {
      page.innerHTML = errorState(e.message);
      return;
    }
    destroyCharts();
    const files = pcaps.files;
    const sel = `
      <select id="t-pcap">
        <option value="">All capture files</option>
        ${files.map((f) => `<option value="${esc(f.name)}" ${trafficState.pcap === f.name ? 'selected' : ''}>${esc(f.original_name || f.name)} (${fmtNum(f.packet_count)} pkts, ${fmtNum(f.alert_count)} alerts)</option>`).join('')}
      </select>`;
    page.innerHTML = `
      <div class="toolbar">
        ${files.length ? sel : '<span class="dim">No capture files analyzed yet — upload one on the Monitoring page.</span>'}
        <select id="t-proto">
          <option value="">All protocols</option>
          ${['tcp', 'udp', 'icmp'].map((p) => `<option ${trafficState.proto === p ? 'selected' : ''}>${p}</option>`).join('')}
        </select>
        <input type="text" id="t-q" class="search-box" placeholder="Filter by IP…" value="${esc(trafficState.q)}">
        <button class="btn btn-sm" id="t-go">Filter</button>
        <span class="spacer"></span>
        <span class="dim" style="font-size:12.5px">${fmtNum(flowsData.total)} conversations</span>
      </div>
      <div class="grid grid-3" style="margin-bottom:16px">
        <div class="card stat-card"><div class="stat-value">${fmtNum(flowsData.total)}</div><div class="stat-label">Conversations (top 300 by bytes)</div></div>
        <div class="card stat-card"><div class="stat-value">${fmtBytes((flowsData.rows || []).reduce((s, r) => s + r.bytes, 0))}</div><div class="stat-label">Total bytes shown</div></div>
        <div class="card stat-card"><div class="stat-value">${fmtBytes((flowsData.rows || []).reduce((s, r) => s + r.payload_bytes, 0))}</div><div class="stat-label">Payload bytes shown</div></div>
      </div>
      <div class="grid grid-3" style="margin-bottom:16px;grid-template-columns:2fr 1fr">
        <div class="card"><h3>Conversations</h3><div id="flows-table">${flowsTable(flowsData.rows)}</div></div>
        <div class="card"><h3>Payload preview</h3><div id="flow-preview" class="dim" style="font-size:13px">Select a conversation to inspect its first payload bytes.</div></div>
      </div>`;
    const pcapSel = page.querySelector('#t-pcap');
    if (pcapSel) pcapSel.onchange = (e) => { trafficState.pcap = e.target.value; renderTraffic(page); };
    page.querySelector('#t-proto').onchange = (e) => { trafficState.proto = e.target.value; renderTraffic(page); };
    const doFilter = () => { trafficState.q = page.querySelector('#t-q').value; renderTraffic(page); };
    page.querySelector('#t-go').onclick = doFilter;
    page.querySelector('#t-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') doFilter(); });
    page.querySelectorAll('#flows-table tr[data-preview]').forEach((tr) => {
      tr.addEventListener('click', () => {
        page.querySelectorAll('#flows-table tr').forEach((r) => r.style.background = '');
        tr.style.background = 'rgba(56,189,248,.08)';
        const el = page.querySelector('#flow-preview');
        el.className = 'payload-preview';
        el.textContent = tr.dataset.preview || '(no payload captured for this conversation)';
      });
    });
  }

  function flowsTable(rows) {
    if (!rows.length) return emptyState('⇄', 'No flows', 'Analyze a PCAP to populate conversation data.');
    const head = `<tr><th>Conversation</th><th>Proto</th><th>Packets</th><th>Bytes</th><th>Duration</th><th>Flags</th></tr>`;
    const body = rows.map((f) => `
      <tr data-preview="${esc(f.payload_preview || '')}" class="clickable">
        <td class="mono-cell">${esc(f.src_ip)}:${esc(f.src_port ?? '—')} → ${esc(f.dst_ip)}:${esc(f.dst_port ?? '—')}<br><small class="dim">${esc(f.pcap_file)}</small></td>
        <td class="mono-cell">${esc((f.proto || '').toUpperCase())}</td>
        <td class="mono-cell">${fmtNum(f.packets)}</td>
        <td class="mono-cell">${fmtBytes(f.bytes)}</td>
        <td class="mono-cell">${fmtNum(f.duration)}s</td>
        <td class="mono-cell" style="font-size:11px">${f.syn ? 'S' + f.syn + ' ' : ''}${f.ack ? 'A' + f.ack + ' ' : ''}${f.rst ? 'R' + f.rst + ' ' : ''}${f.fin ? 'F' + f.fin : ''}</td>
      </tr>`).join('');
    return `<div style="max-height:520px;overflow-y:auto"><table class="table"><thead>${head}</thead><tbody>${body}</tbody></table></div>`;
  }

  /* ============================ rules ============================ */
  async function renderRules(page) {
    page.innerHTML = loading();
    let data;
    try {
      data = await api.get('/api/rules');
    } catch (e) {
      page.innerHTML = errorState(e.message);
      return;
    }
    page.innerHTML = `
      <div class="toolbar">
        <span class="dim">${fmtNum(data.count)} active rules</span>
        <span class="spacer"></span>
        <button class="btn" id="rules-reload">Reload rules</button>
      </div>
      ${data.errors.length ? `<div class="callout error"><strong>Rule load errors (${data.errors.length}):</strong><ul>${data.errors.map((e) => `<li class="err-text">${esc(e.file)}:${e.line} — ${esc(e.error)}</li>`).join('')}</ul></div>` : ''}
      <div class="grid grid-2">
        ${data.rules.map((r) => `
          <div class="card">
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
              ${sevBadge(r.severity)}
              <span class="tag">${esc(r.proto)}</span>
              <span class="tag">${esc(r.classtype)}</span>
              <span class="mono-cell dim" style="margin-left:auto">${esc(r.source)}</span>
            </div>
            <h3 style="font-size:14.5px;margin:10px 0 4px;text-transform:none;letter-spacing:0;color:var(--text)">${esc(r.msg)}</h3>
            <div class="mono-cell dim" style="font-size:12px">sid ${esc(r.sid)} · rev ${esc(r.rev)} · gid ${esc(r.gid)} · ${esc(r.category)}</div>
            ${r.references.length ? `<div style="margin-top:6px">${r.references.map((x) => `<span class="tag">${esc(x.type)}:${esc(x.id)}</span>`).join(' ')}</div>` : ''}
            ${r.warnings.length ? `<div class="warn-text" style="margin-top:6px">⚠ ${r.warnings.map(esc).join(' · ')}</div>` : ''}
            <div class="rule-raw">${esc(r.raw)}</div>
          </div>`).join('')}
      </div>`;
    page.querySelector('#rules-reload').onclick = async () => {
      if (!api.getToken()) { toast('Set the admin token first (Settings page)', 'err'); return; }
      try {
        const r = await api.post('/api/rules/reload', {});
        toast(`Reloaded ${r.loaded} rules${r.errors.length ? ` with ${r.errors.length} errors` : ''}`, r.errors.length ? 'err' : 'ok');
        renderRules(page);
      } catch (e) { toast(e.message, 'err'); }
    };
  }

  /* ============================ monitoring ============================ */
  async function renderMonitoring(page) {
    page.innerHTML = loading();
    let st;
    try {
      st = await api.get('/api/status');
    } catch (e) {
      page.innerHTML = errorState(e.message);
      return;
    }
    const mon = st.monitor;
    const caps = mon.capabilities || {};
    const active = mon.active;
    const anyEngine = (caps.suricata && caps.suricata.installed) || (caps.snort && caps.snort.installed);

    page.innerHTML = `
      <div class="grid grid-2" style="margin-bottom:16px">
        <div class="card">
          <h3>Monitoring control</h3>
          <dl class="kv">
            <dt>State</dt><dd id="mon-state"><span class="dot ${active ? 'dot-green' : 'dot-gray'}"></span> ${active ? `active (${esc(mon.mode)} mode)` : 'inactive'}</dd>
            <dt>Started</dt><dd>${esc(mon.startedAt || '—')}</dd>
            <dt>Last update</dt><dd>${esc(mon.lastUpdate || 'never')}</dd>
            <dt>PCAPs analyzed</dt><dd>${fmtNum(mon.analyzedCount)}</dd>
          </dl>
          ${mon.lastError ? `<div class="callout error"><strong>Last error:</strong> ${esc(mon.lastError)}</div>` : ''}
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
            <select id="mon-mode">
              <option value="dropzone" ${mon.mode === 'dropzone' ? 'selected' : ''}>Drop-zone PCAP monitoring</option>
              <option value="live" ${mon.mode === 'live' ? 'selected' : ''} ${anyEngine ? '' : 'disabled'}>Live engine capture${anyEngine ? '' : ' (engine not installed)'}</option>
            </select>
            ${active
              ? '<button class="btn btn-danger" id="mon-stop">Stop monitoring</button>'
              : '<button class="btn btn-primary" id="mon-start">Start monitoring</button>'}
          </div>
          <p class="dim" style="font-size:12.5px;margin-top:10px">
            Drop-zone mode watches the upload directory and automatically analyzes every new PCAP.
            Live mode starts Suricata/Snort on the configured interface and ingests its alert stream in real time.
          </p>
        </div>
        <div class="card">
          <h3>Detection engine availability</h3>
          ${engineCard('Suricata', caps.suricata)}
          ${engineCard('Snort', caps.snort)}
          <p class="dim" style="font-size:12.5px;margin-top:10px">
            Checked at ${esc(caps.checkedAt || 'never')}.
            ${(caps.liveCapture && caps.liveCapture.notes || []).map((n) => `<br>• ${esc(n)}`).join('')}
          </p>
        </div>
      </div>
      <div class="grid grid-2">
        <div class="card">
          <h3>Analyze a PCAP file</h3>
          <div class="dropzone" id="dz" tabindex="0" role="button" aria-label="Upload PCAP">
            <div style="font-size:30px;margin-bottom:6px">⬆</div>
            <div><strong>Drop a .pcap / .pcapng here</strong> or click to browse</div>
            <div class="dim" style="font-size:12px;margin-top:4px">Analyzed locally by the built-in engine · max 256 MB</div>
            <input type="file" id="dz-file" accept=".pcap,.pcapng" hidden>
          </div>
          <div class="progress" id="dz-progress" hidden><div></div></div>
          <div id="dz-result" style="margin-top:10px"></div>
        </div>
        <div class="card">
          <h3>Import an engine alert log</h3>
          <p class="dim" style="font-size:12.5px">Paste a Suricata <code>eve.json</code> or Snort <code>alert</code> (fast) log to ingest its alerts as live-engine events.</p>
          <select id="imp-kind" style="margin-bottom:8px">
            <option value="eve">Suricata EVE (JSON lines)</option>
            <option value="fast">Snort fast alert log</option>
          </select>
          <textarea id="imp-text" rows="6" style="width:100%" placeholder='{"timestamp":"...","event_type":"alert","alert":{...}}'></textarea>
          <div style="margin-top:8px"><button class="btn" id="imp-go">Import log</button> <span id="imp-result" class="dim" style="font-size:12.5px"></span></div>
        </div>
      </div>`;

    const startBtn = page.querySelector('#mon-start');
    if (startBtn) startBtn.onclick = async () => {
      if (!api.getToken()) { toast('Set the admin token first (Settings page)', 'err'); return; }
      const mode = page.querySelector('#mon-mode').value;
      const ok = await confirmDialog('Start monitoring', `Start ${mode === 'live' ? 'LIVE engine capture' : 'drop-zone PCAP monitoring'}?`, 'Start', false);
      if (!ok) return;
      try {
        const r = await api.post('/api/monitor/start', { mode });
        toast(`Monitoring started (${r.mode})`, 'ok');
        renderMonitoring(page);
      } catch (e) { toast(e.message, 'err'); }
    };
    const stopBtn = page.querySelector('#mon-stop');
    if (stopBtn) stopBtn.onclick = async () => {
      if (!api.getToken()) { toast('Set the admin token first (Settings page)', 'err'); return; }
      const ok = await confirmDialog('Stop monitoring', `Stop the currently active '${mon.mode}' monitoring?`, 'Stop', true);
      if (!ok) return;
      try {
        await api.post('/api/monitor/stop', {});
        toast('Monitoring stopped', 'ok');
        renderMonitoring(page);
      } catch (e) { toast(e.message, 'err'); }
    };

    // dropzone
    const dz = page.querySelector('#dz');
    const fileInput = page.querySelector('#dz-file');
    dz.onclick = () => fileInput.click();
    dz.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') fileInput.click(); };
    ['dragenter', 'dragover'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('drag'); }));
    ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('drag'); }));
    dz.addEventListener('drop', (e) => {
      const f = e.dataTransfer.files && e.dataTransfer.files[0];
      if (f) uploadPcap(f, page);
    });
    fileInput.onchange = () => { if (fileInput.files[0]) uploadPcap(fileInput.files[0], page); };

    page.querySelector('#imp-go').onclick = async () => {
      if (!api.getToken()) { toast('Set the admin token first (Settings page)', 'err'); return; }
      const kind = page.querySelector('#imp-kind').value;
      const text = page.querySelector('#imp-text').value;
      if (!text.trim()) { toast('Paste a log first', 'err'); return; }
      try {
        const r = await api.upload(`/api/logs/import?kind=${kind}`, text);
        page.querySelector('#imp-result').textContent = `Ingested ${r.ingested} alerts (${r.skipped} non-alert lines skipped).`;
        toast(`Imported ${r.ingested} alerts`, 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
  }

  function engineCard(name, cap) {
    if (!cap) return `<p class="dim">${name}: not checked yet.</p>`;
    return `
      <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid rgba(36,52,79,.5)">
        <span class="dot ${cap.installed ? 'dot-green' : 'dot-gray'}"></span>
        <div>
          <strong>${esc(name)}</strong> ${cap.version ? `<span class="dim">v${esc(cap.version)}</span>` : ''}<br>
          <small class="dim">${cap.installed ? `found at “${esc(cap.path)}”` : `not found on PATH (“${esc(cap.path)}”)`}</small>
        </div>
      </div>`;
  }

  async function uploadPcap(file, page) {
    if (!api.getToken()) { toast('Set the admin token first (Settings page)', 'err'); return; }
    const prog = page.querySelector('#dz-progress');
    const bar = prog.querySelector('div');
    const result = page.querySelector('#dz-result');
    prog.hidden = false;
    bar.style.width = '20%';
    result.innerHTML = '';
    try {
      const buf = await file.arrayBuffer();
      bar.style.width = '60%';
      const name = encodeURIComponent(file.name);
      const r = await api.upload(`/api/pcaps?name=${name}`, buf);
      bar.style.width = '100%';
      result.innerHTML = `<div class="callout info" style="margin:0">
        <strong>${esc(file.name)}</strong> analyzed: ${fmtNum(r.packetCount)} packets →
        <strong>${fmtNum(r.alertCount)} alerts</strong>, ${fmtNum(r.flowCount)} conversations recorded.
        <a href="#/alerts?source=pcap">View alerts →</a></div>`;
      toast(`Analysis complete: ${r.alertCount} alerts`, 'ok');
    } catch (e) {
      prog.hidden = true;
      result.innerHTML = `<div class="callout error" style="margin:0">${esc(e.message)}</div>`;
      toast(e.message, 'err');
    }
  }

  /* ============================ incidents ============================ */
  const incidentState = { status: 'acknowledged', q: '' };

  async function renderIncidents(page) {
    page.innerHTML = loading();
    let data, auditData;
    const params = new URLSearchParams({ status: incidentState.status, perPage: 50 });
    if (incidentState.q) params.set('q', incidentState.q);
    try {
      data = await api.get(`/api/alerts?${params.toString()}`);
      if (api.getToken()) auditData = await api.get('/api/audit?limit=100').catch(() => null);
    } catch (e) {
      page.innerHTML = errorState(e.message);
      return;
    }
    page.innerHTML = `
      <div class="callout info">Investigation workflow: triage alerts from the Alerts page (acknowledge), then work them here.
      Every status change and note is recorded in the audit log below. Sentinel NIDS never blocks hosts or alters firewall rules automatically.</div>
      <div class="toolbar">
        <select id="i-status">
          ${[['acknowledged', 'Acknowledged (open incidents)'], ['new', 'New (untriaged)'], ['resolved', 'Resolved (closed)'], ['', 'All statuses']].map(([v, l]) =>
            `<option value="${v}" ${incidentState.status === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
        <input type="text" id="i-q" class="search-box" placeholder="Search incidents…" value="${esc(incidentState.q)}">
        <button class="btn btn-sm" id="i-go">Search</button>
      </div>
      <div class="card" id="inc-table">${alertsTable(data.rows)}</div>
      <div class="card" style="margin-top:16px">
        <h3>Audit log (response actions)</h3>
        ${auditData && auditData.entries.length ? `
          <div style="max-height:340px;overflow-y:auto"><table class="table">
            <thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Target</th></tr></thead>
            <tbody>${auditData.entries.map((e) => `
              <tr><td class="mono-cell" style="white-space:nowrap">${esc(e.created_at)}</td>
              <td>${esc(e.actor)}</td><td>${esc(e.action)}</td>
              <td class="mono-cell">${esc(e.target || '—')}</td></tr>`).join('')}</tbody>
          </table></div>`
        : `<p class="dim" style="font-size:13px">${api.getToken() ? 'No audit entries yet.' : 'Set the admin token to view the audit log.'}</p>`}
      </div>`;
    bindAlertRows(page.querySelector('#inc-table'));
    page.querySelector('#i-status').onchange = (e) => { incidentState.status = e.target.value; renderIncidents(page); };
    const doSearch = () => { incidentState.q = page.querySelector('#i-q').value; renderIncidents(page); };
    page.querySelector('#i-go').onclick = doSearch;
    page.querySelector('#i-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); });
  }

  /* ============================ settings ============================ */
  async function renderSettings(page) {
    page.innerHTML = loading();
    let st;
    try {
      st = await api.get('/api/status');
    } catch (e) {
      page.innerHTML = errorState(e.message);
      return;
    }
    page.innerHTML = `
      <div class="grid grid-2">
        <div class="card">
          <h3>Admin access</h3>
          <p class="dim" style="font-size:13px">Administrative actions (status changes, monitoring control, uploads, rule reload, simulation) require the admin token.
          It is printed on server startup and stored in <code>data/.admin-token</code>, or set via the <code>NIDS_ADMIN_TOKEN</code> environment variable.</p>
          <input type="password" id="set-token" placeholder="Paste admin token" style="width:100%" value="${esc(api.getToken())}">
          <div style="margin-top:8px;display:flex;gap:8px">
            <button class="btn btn-primary" id="set-token-save">Save token</button>
            <button class="btn btn-ghost" id="set-token-clear">Clear</button>
          </div>
        </div>
        <div class="card">
          <h3>Notifications (high-severity alerts)</h3>
          <p class="dim" style="font-size:13px">POST a JSON payload to a webhook whenever an alert at or above the minimum severity is ingested.</p>
          <label class="dim" style="font-size:12px">Webhook URL (blank = disabled)</label>
          <input type="text" id="set-webhook" placeholder="https://hooks.example.com/nids" style="width:100%" value="${esc(st.config.notifications.webhookConfigured ? '' : '')}">
          <label class="dim" style="font-size:12px;display:block;margin-top:8px">Minimum severity</label>
          <select id="set-minsev" style="width:100%">
            ${SEV_ORDER.map((s) => `<option ${st.config.notifications.minSeverity === s ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
          <div style="margin-top:8px"><button class="btn" id="set-notify-save">Save notification settings</button></div>
        </div>
      </div>
      <div class="card" style="margin-top:16px">
        <h3>Demonstration data (clearly labeled)</h3>
        <p class="dim" style="font-size:13px">When no real traffic is available you can generate <strong>simulated</strong> events or load a <strong>sample</strong> dataset.
        Both are permanently flagged <span class="tag tag-simulated">SIMULATED</span>/<span class="tag tag-sample">SAMPLE</span> and are never presented as genuine detections.</p>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn" data-scn="portscan">Simulate port scan</button>
          <button class="btn" data-scn="bruteforce">Simulate brute force</button>
          <button class="btn" data-scn="c2">Simulate C2 beacon</button>
          <button class="btn" id="sample-data">Load sample dataset (15 alerts)</button>
        </div>
      </div>
      <div class="card doc" style="margin-top:16px">
        <h3 style="margin:0 0 10px">Quick reference</h3>
        <ul>
          <li><strong>Start monitoring:</strong> Monitoring page → choose <em>Drop-zone PCAP monitoring</em> → Start, then drop capture files into <code>${esc(st.config.watchDir)}</code>.</li>
          <li><strong>Analyze a PCAP:</strong> Monitoring page → drag &amp; drop a <code>.pcap</code> onto the upload box (or <code>curl -X POST --data-binary @file.pcap "http://127.0.0.1:${esc(String(st.config.port))}/api/pcaps?name=file.pcap" -H "Authorization: Bearer &lt;token&gt;"</code>).</li>
          <li><strong>Test rules:</strong> <code>node scripts/make-test-pcaps.js</code> regenerates <code>examples/*.pcap</code>, then analyze them from the Monitoring page.</li>
          <li><strong>Add rules:</strong> edit <code>config/rules/local.rules</code>, then Rules page → Reload. See <code>docs/RULES.md</code> for the supported syntax.</li>
          <li><strong>Full setup &amp; troubleshooting:</strong> see <code>README.md</code>.</li>
        </ul>
      </div>`;
    page.querySelector('#set-token-save').onclick = () => {
      api.setToken(page.querySelector('#set-token').value);
      toast(api.getToken() ? 'Token saved for this session' : 'Token cleared', 'ok');
    };
    page.querySelector('#set-token-clear').onclick = () => {
      api.setToken('');
      page.querySelector('#set-token').value = '';
      toast('Token cleared', 'ok');
    };
    page.querySelector('#set-notify-save').onclick = async () => {
      if (!api.getToken()) { toast('Set the admin token first', 'err'); return; }
      try {
        const r = await api.post('/api/config/notifications', {
          webhookUrl: page.querySelector('#set-webhook').value.trim() || null,
          minSeverity: page.querySelector('#set-minsev').value,
        });
        toast(`Notifications saved (webhook ${r.notifications.webhookConfigured ? 'configured' : 'disabled'}, min ${r.notifications.minSeverity})`, 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
    page.querySelectorAll('button[data-scn]').forEach((b) => {
      b.onclick = async () => {
        if (!api.getToken()) { toast('Set the admin token first', 'err'); return; }
        const ok = await confirmDialog('Generate simulated events', 'These alerts are SIMULATED and will be clearly labeled as such. Continue?', 'Generate', false);
        if (!ok) return;
        try {
          const r = await api.post('/api/simulate', { scenario: b.dataset.scn });
          toast(`${r.ids.length} simulated alerts created`, 'ok');
        } catch (e) { toast(e.message, 'err'); }
      };
    });
    page.querySelector('#sample-data').onclick = async () => {
      if (!api.getToken()) { toast('Set the admin token first', 'err'); return; }
      const ok = await confirmDialog('Load sample dataset', 'Inserts 15 SAMPLE alerts (clearly labeled, not real detections) spread over the last 24h for dashboard evaluation. Continue?', 'Load', false);
      if (!ok) return;
      try {
        const r = await api.post('/api/sample-data', {});
        toast(`${r.count} sample alerts loaded`, 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
  }

  window.pages = {
    renderDashboard, renderAlerts, renderTraffic, renderRules, renderMonitoring, renderIncidents, renderSettings,
  };
})();
