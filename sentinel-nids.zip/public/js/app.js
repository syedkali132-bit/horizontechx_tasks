/* Router + global chrome behavior. */
(function () {
  'use strict';

  const routes = {
    dashboard: { title: 'Dashboard', render: 'renderDashboard' },
    alerts: { title: 'Live Alerts', render: 'renderAlerts' },
    traffic: { title: 'Traffic Analysis', render: 'renderTraffic' },
    rules: { title: 'Detection Rules', render: 'renderRules' },
    monitoring: { title: 'Monitoring', render: 'renderMonitoring' },
    incidents: { title: 'Incident Investigation', render: 'renderIncidents' },
    settings: { title: 'Settings & Documentation', render: 'renderSettings' },
  };

  const page = document.getElementById('page');
  let current = null;

  function currentRoute() {
    const h = location.hash.replace(/^#\//, '').split('?')[0];
    return routes[h] ? h : 'dashboard';
  }

  async function navigate() {
    const name = currentRoute();
    current = name;
    document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.route === name));
    document.getElementById('topbar-title').textContent = routes[name].title;
    document.getElementById('sidebar').classList.remove('open');
    try {
      await window.pages[routes[name].render](page);
    } catch (e) {
      page.innerHTML = `<div class="callout error"><strong>Page failed to render:</strong> ${ui.esc(e.message)}</div>`;
    }
  }

  window.refreshCurrentPage = () => { if (current) navigate(); };

  window.addEventListener('hashchange', navigate);
  document.getElementById('menu-btn').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
  });

  // clock
  setInterval(() => {
    const el = document.getElementById('clock');
    if (el) el.textContent = new Date().toLocaleTimeString();
  }, 1000);

  // sidebar status pill + new-alert badge
  async function pollStatus() {
    try {
      const st = await api.get('/api/status');
      const dot = document.querySelector('#sidebar-status .dot');
      const txt = document.getElementById('sidebar-status-text');
      if (st.monitor.active) {
        dot.className = 'dot dot-green';
        txt.textContent = `Live · ${st.monitor.mode}`;
      } else {
        dot.className = 'dot dot-gray';
        txt.textContent = 'Monitoring off';
      }
      const badge = document.getElementById('nav-new-count');
      const ov = await api.get('/api/stats/overview').catch(() => null);
      if (ov && ov.newCount > 0) {
        badge.hidden = false;
        badge.textContent = ov.newCount > 99 ? '99+' : ov.newCount;
      } else {
        badge.hidden = true;
      }
    } catch { /* server unreachable; leave last state */ }
  }

  api.updateAuthLabel();
  navigate();
  pollStatus();
  setInterval(pollStatus, 20000);
})();
