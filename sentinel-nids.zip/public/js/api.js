/* API client: thin fetch wrapper with admin-token support. */
(function () {
  'use strict';

  const TOKEN_KEY = 'nids.adminToken';

  function getToken() {
    return sessionStorage.getItem(TOKEN_KEY) || '';
  }
  function setToken(t) {
    if (t) sessionStorage.setItem(TOKEN_KEY, t.trim());
    else sessionStorage.removeItem(TOKEN_KEY);
    updateAuthLabel();
  }
  function updateAuthLabel() {
    const el = document.getElementById('auth-state');
    if (el) el.textContent = getToken() ? 'token set' : 'no token';
  }

  async function request(method, url, body, opts = {}) {
    const headers = {};
    if (body !== undefined && !(body instanceof Blob) && !(body instanceof ArrayBuffer) && !(body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
    }
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
    let res;
    try {
      res = await fetch(url, {
        method,
        headers,
        body: body === undefined ? undefined
          : (body instanceof Blob || body instanceof ArrayBuffer) ? body
          : (typeof body === 'string') ? body
          : JSON.stringify(body),
      });
    } catch (err) {
      const e = new Error('Cannot reach the Sentinel NIDS server. Is it running?');
      e.network = true;
      throw e;
    }
    let data = null;
    const text = await res.text();
    try { data = text ? JSON.parse(text) : null; } catch { data = { error: text.slice(0, 300) }; }
    if (!res.ok) {
      const e = new Error((data && data.error) || `Request failed (HTTP ${res.status})`);
      e.status = res.status;
      throw e;
    }
    return data;
  }

  window.api = {
    get: (url) => request('GET', url),
    post: (url, body, opts) => request('POST', url, body, opts),
    upload: (url, arrayBuffer) => request('POST', url, arrayBuffer),
    getToken, setToken, updateAuthLabel,
  };
})();
