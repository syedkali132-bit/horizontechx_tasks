# Sentinel NIDS rule syntax reference

Sentinel NIDS loads Snort/Suricata-style signature rules from every
`.rules` file in `config/rules/` (bundled `community.rules` + your
`local.rules`). This document describes exactly what the built-in offline
matcher supports, what it ignores, and where it differs from a real engine.

## Rule structure

```
action proto src_ip src_port direction dst_ip dst_port ( options... )
```

Example:

```
alert tcp $EXTERNAL_NET any -> $HOME_NET $HTTP_PORTS (msg:"TEST SQL injection attempt (union select)"; flow:to_server; content:"union select"; nocase; classtype:web-application-attack; priority:1; sid:1000007; rev:1;)
```

### Header fields

| Field | Supported values |
|---|---|
| `action` | `alert`, `log` (both raise alerts). `drop`/`reject` are **passive**: parsed, warned, treated as `alert` — this NIDS never enforces blocking. `pass` rules are disabled. |
| `proto` | `tcp`, `udp`, `icmp`, `ip` |
| IPs | `any`, single IPv4, CIDR (`192.168.0.0/24`), lists `[a,b,!c]`, negation `!`, variables (`$HOME_NET`, `$EXTERNAL_NET`, …) defined in config/network. Nested variables resolve to lists. |
| ports | `any`, number, range `80`, `1:1024`, `:1024`, `1024:`, lists, negation, port variables (`$HTTP_PORTS`, `$IRC_PORTS`) |
| direction | `->` (checked as written), `<>` (endpoints may match in either order) |

### Options

| Option | Semantics in the built-in matcher |
|---|---|
| `msg:"text"` | Human-readable alert message (required in practice; defaults to `Signature <sid>`) |
| `sid` / `gid` / `rev` | Numeric identifiers. `sid` is required and must be unique across all loaded files; duplicates are reported as load errors with file:line. |
| `classtype:name` | Sets category + default priority. Supported: `attempted-admin`, `attempted-user`, `attempted-recon`, `attempted-dos`, `web-application-attack`, `trojan-activity`, `potentially-bad-traffic`, `protocol-command-decode`, `policy-violation`, `misc-attack`, `misc-activity`, `bad-unknown` |
| `priority:1-4` | Overrides classtype priority: 1→critical, 2→high, 3→medium, 4→low |
| `content:"..."` | Substring match on the transport payload. `\;` `\:` `\\` `\|` `\"` escapes; `\n` `\r` `\t`; `\|hh hh\|` hex blocks anywhere in the string. Prefix `!` negates (match only if absent). |
| `nocase` | Applies to the **preceding** `content` |
| `depth:n` / `offset:n` | Search only within payload bytes `[offset, offset+depth)` |
| `distance:n` / `within:n` | Relative placement from the end of the previous content match (`within` is accepted and applied as max offset bound; see limitations) |
| `pcre:"/regex/flags"` | JavaScript RegExp against the payload (latin1). Flags: `i m s u` (PCRE-only flags are stripped). `!` prefix negates. |
| `flags:SPEC` | TCP flags. Letters `F S R P A U E C`, `0` = no flags at all, `*` = wildcard-anchored sets (`*F` etc.), `!` negation. |
| `flow:` | `to_server`, `established` (approximated: ACK/RST flag or payload presence — no full state tracking), `no_stream` (payload-bearing packets skipped) |
| `itype:n` / `icode:n` | ICMP type/code equality |
| `dsize:SPEC` | Payload length compare: `n`, `>n`, `<n`, `>=n`, `<=n`, `!=n`, `a<>b` (exclusive range) |
| `sameip` | Requires source IP ≠ destination IP |
| `threshold:type T, track TR, count N, seconds S` | `limit` (alert at most N times per window), `threshold` (alert once when N reached), `both`. `track by_src`/`by_dst`. Windows slide per source/destination key. |
| `reference:type,id` / `metadata:key value` | Recorded and shown in the dashboard |
| `fast_pattern` | Accepted (no-op offline; content order is deterministic) |

**Ignored with a warning** (rule still loads): unknown options,
`flowbits`, `byte_test`, `byte_jump`, `isdataat`, `rawbytes`, `replace`,
`resp`, `react`, `session`, `tag`, `ipopts`, `fragbits`, `fragoffset`,
`ttl`, `tos`, `id`, `icmp_id`, `icmp_seq`.

### Variables

- `$HOME_NET` ← `network.homeNet` in `config/nids.config.json`
- `$EXTERNAL_NET` = `!$HOME_NET`
- `$HTTP_PORTS`, `$IRC_PORTS`, `$SSH_PORTS` — configurable defaults `[80,8080]`, `[6667,6697]`, `[22]`

Negation-only lists (`!$HOME_NET`) match everything not covered by the
negated entries — the standard Snort semantics.

## Behavioral (non-signature) detections

Independent of rule files, the analyzer computes these from capture
statistics (thresholds in `heuristics.*`):

| sid | Detector | Fires when |
|---|---|---|
| 9000001 | Port sweep | ≥ N distinct destination ports from one source to one host inside the window with few completed handshakes |
| 9000002 | Failed connections | ≥ N RST-terminated connection attempts between the same endpoints/service in the window |
| 9000003 | Connection flood | ≥ N new conversations initiated by one source inside the window |
| 9000004 | Large transfer | One conversation's payload exceeds the configured byte threshold |

These are labeled `HEURISTIC …` and include machine-readable `evidence`
(distinct ports, window seconds, byte counts).

## Known matcher limitations

1. **No TCP stream reassembly** — contents are matched per packet. Rules that
   expect reassembled streams (common in HTTP rule sets) may not fire offline;
   a real engine handles those. `flow:established` is a heuristic.
2. **`within`** is honored as an upper bound measured from the previous match
   end (PCRE-style relative semantics); exotic combinations of
   offset/distance/within chains may differ from Suricata.
3. **No frag reassembly** — fragmented payloads are not reassembled for
   content matching.
4. **`flowbits`/state machines** are not implemented.
5. Threshold state is in-memory per rule load; reloading rules resets
   threshold windows.

## Tips for writing local rules

- Use the sid range **1001000+** for locals to avoid colliding with the
  bundled test rules (1000001–1000012) and heuristics (9000001–9000004).
- Keep `msg` specific: it becomes the alert signature shown to analysts.
- Prefer `classtype` + `priority` over manual severity guessing — the mapping
  is centralized and keeps severities consistent.
- Test with `node scripts/make-test-pcaps.js` captures and the Rules page
  reload; the page surfaces syntax errors with file and line numbers.
