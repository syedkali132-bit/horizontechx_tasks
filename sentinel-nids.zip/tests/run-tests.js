'use strict';

/**
 * Sentinel NIDS test suite — no external test framework required.
 * Run: node tests/run-tests.js
 * Exits non-zero on any failure.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const ROOT = path.join(__dirname, '..');

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    const r = fn();
    if (r && typeof r.then === 'function') {
      return r.then(() => { passed++; console.log(`  ✓ ${name}`); })
        .catch((err) => { failed++; failures.push([name, err]); console.log(`  ✗ ${name}\n      ${err.message}`); });
    }
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    failures.push([name, err]);
    console.log(`  ✗ ${name}\n      ${err.message}`);
  }
}

async function section(title, fn) {
  console.log(`\n${title}`);
  await fn();
}

/* ================= rule engine ================= */
const { RuleSet, parseRuleLine } = require(path.join(ROOT, 'server', 'ruleEngine'));
const util = require(path.join(ROOT, 'server', 'util'));
const { DEFAULT_VARS } = require(path.join(ROOT, 'server', 'config'));

const VARS = { ...DEFAULT_VARS, HOME_NET: ['192.168.0.0/16'], EXTERNAL_NET: ['!$HOME_NET'], HTTP_PORTS: [80, 8080], IRC_PORTS: [6667] };

function pkt(over = {}) {
  return {
    tsSec: 1000, tsUsec: 0,
    proto: 'tcp', srcIp: '203.0.113.9', srcPort: 40000,
    dstIp: '192.168.1.10', dstPort: 80,
    payload: Buffer.alloc(0), ...over,
  };
}

/* ================= pcap + analyzer ================= */
const pcapParser = require(path.join(ROOT, 'server', 'pcapParser'));
const { analyze } = require(path.join(ROOT, 'server', 'analyzer'));
const builders = require(path.join(ROOT, 'scripts', 'make-test-pcaps'));

function ruleset() {
  const rs = new RuleSet(VARS);
  rs.loadFile(path.join(ROOT, 'config', 'rules', 'community.rules'));
  rs.loadFile(path.join(ROOT, 'config', 'rules', 'local.rules'));
  return rs;
}

function pcapBuffer(writer) {
  const hdr = Buffer.alloc(24);
  hdr.writeUInt32LE(0xa1b2c3d4, 0);
  hdr.writeUInt16LE(2, 4); hdr.writeUInt16LE(4, 6);
  hdr.writeUInt32LE(65535, 16); hdr.writeUInt32LE(1, 20);
  const parts = [hdr];
  for (const r of writer.records) {
    const rec = Buffer.alloc(16);
    rec.writeUInt32LE(r.sec, 0); rec.writeUInt32LE(r.usec, 4);
    rec.writeUInt32LE(r.frame.length, 8); rec.writeUInt32LE(r.frame.length, 12);
    parts.push(rec, r.frame);
  }
  return Buffer.concat(parts);
}

async function main() {
  await section('Rule parser', async () => {
    await test('parses full rule with all common options', () => {
      const r = parseRuleLine(
        'alert tcp $EXTERNAL_NET any -> $HOME_NET 80 (msg:"X"; content:"abc"; nocase; depth:10; offset:2; pcre:"/def/i"; flags:SA; threshold:type limit, track by_src, count 3, seconds 60; classtype:web-application-attack; priority:1; sid:42; rev:2; reference:url,example.com;)',
        't.rules', 1, VARS
      );
      assert.strictEqual(r.sid, 42);
      assert.strictEqual(r.severity, 'critical');
      assert.strictEqual(r.contents.length, 1);
      assert.strictEqual(r.contents[0].nocase, true);
      assert.strictEqual(r.contents[0].depth, 10);
      assert.strictEqual(r.contents[0].offset, 2);
      assert.strictEqual(r.threshold.type, 'limit');
      assert.strictEqual(r.threshold.count, 3);
      assert.strictEqual(r.proto, 'tcp');
    });

    await test('rejects rule without sid and reports location', () => {
      assert.throws(
        () => parseRuleLine('alert tcp any any -> any any (msg:"x";)', 't.rules', 7, VARS),
        /missing required sid.*t\.rules:7/
      );
    });

    await test('rejects unknown classtype', () => {
      assert.throws(
        () => parseRuleLine('alert tcp any any -> any any (msg:"x"; classtype:nope; sid:5;)', 't', 1, VARS),
        /unknown classtype/
      );
    });

    await test('rejects bad content hex', () => {
      assert.throws(
        () => parseRuleLine('alert tcp any any -> any any (msg:"x"; content:"|zz|"; sid:6;)', 't', 1, VARS),
        /invalid hex byte/
      );
    });

    await test('IP negation spec: !$HOME_NET matches external, not internal', () => {
      const spec = util.parseIpSpec('!$HOME_NET', VARS);
      assert.strictEqual(util.ipMatches('8.8.8.8', spec), true);
      assert.strictEqual(util.ipMatches('192.168.5.5', spec), false);
    });

    await test('IP list spec matches any member', () => {
      const spec = util.parseIpSpec('[10.0.0.0/8, 192.168.1.0/24]', VARS);
      assert.strictEqual(util.ipMatches('10.4.4.4', spec), true);
      assert.strictEqual(util.ipMatches('192.168.1.9', spec), true);
      assert.strictEqual(util.ipMatches('172.16.0.1', spec), false);
    });

    await test('port ranges and lists', () => {
      assert.strictEqual(util.portMatches(8080, util.parsePortSpec('[80,8080]')), true);
      assert.strictEqual(util.portMatches(81, util.parsePortSpec('1:1024')), true);
      assert.strictEqual(util.portMatches(9000, util.parsePortSpec('!80')), true);
      assert.strictEqual(util.portMatches(80, util.parsePortSpec('!80')), false);
      assert.strictEqual(util.parsePortSpec('99999'), null);
    });
  });

  await section('Rule matcher', async () => {
    await test('flags:0 matches only zero-flag packets', () => {
      const rs = new RuleSet(VARS);
      rs.loadFile(path.join(ROOT, 'config', 'rules', 'community.rules'));
      const rule = rs.rules.find((r) => r.sid === 1000003);
      assert(rule, 'sid 1000003 loaded');
      assert.strictEqual(rs._ruleMatches(rule, pkt({ tcp: { flags: 0x00 } })), true);
      assert.strictEqual(rs._ruleMatches(rule, pkt({ tcp: { flags: 0x12 } })), false);
    });

    await test('content nocase + flow to_server', () => {
      const rs = new RuleSet(VARS);
      rs.loadFile(path.join(ROOT, 'config', 'rules', 'community.rules'));
      const rule = rs.rules.find((r) => r.sid === 1000007);
      const hit = pkt({ payload: Buffer.from("GET /?id=1 uNiOn SeLeCt 1-- HTTP/1.1\r\n\r\n") });
      assert.strictEqual(rs._ruleMatches(rule, hit), true);
      const miss = pkt({ payload: Buffer.from('GET /normal HTTP/1.1\r\n\r\n') });
      assert.strictEqual(rs._ruleMatches(rule, miss), false);
    });

    await test('content with |hex| bytes and depth', () => {
      const r = parseRuleLine('alert tcp any any -> any any (msg:"h"; content:"|02 04 05 b4|"; depth:8; sid:77;)', 't', 1, VARS);
      const rs = new RuleSet(VARS);
      rs.rules.push(r);
      assert.strictEqual(rs._ruleMatches(r, pkt({ payload: Buffer.concat([Buffer.from([1, 2]), Buffer.from('020405b4', 'hex'), Buffer.alloc(20)]) })), true);
      assert.strictEqual(rs._ruleMatches(r, pkt({ payload: Buffer.concat([Buffer.alloc(30), Buffer.from('020405b4', 'hex')]) })), false);
    });

    await test('content with within bounds distance from previous match end', () => {
      const r = parseRuleLine('alert tcp any any -> any any (msg:"w"; content:"abc"; content:"def" within:5; sid:78;)', 't', 1, VARS);
      assert.strictEqual(r.contents[1].within, 5);
      const rs = new RuleSet(VARS);
      rs.rules.push(r);
      // "def" ends exactly at prevEnd+5 -> matches
      assert.strictEqual(rs._ruleMatches(r, pkt({ payload: Buffer.from('xxabcyydefzz') })), true);
      // "def" ends at prevEnd+6 -> outside the window
      assert.strictEqual(rs._ruleMatches(r, pkt({ payload: Buffer.from('xxabcyyyyydef') })), false);
      // no second content at all
      assert.strictEqual(rs._ruleMatches(r, pkt({ payload: Buffer.from('xxabcyyyyyyy') })), false);
    });

    await test('dsize operators', () => {
      const r = parseRuleLine('alert icmp any any -> any any (msg:"d"; itype:8; dsize:>900; sid:88;)', 't', 1, VARS);
      assert.strictEqual(r.dsize.op, '>');
      const rs = new RuleSet(VARS);
      assert.strictEqual(rs._ruleMatches(r, { proto: 'icmp', srcIp: '1.1.1.1', dstIp: '2.2.2.2', icmp: { type: 8 }, payload: Buffer.alloc(1000) }), true);
      assert.strictEqual(rs._ruleMatches(r, { proto: 'icmp', srcIp: '1.1.1.1', dstIp: '2.2.2.2', icmp: { type: 8 }, payload: Buffer.alloc(100) }), false);
    });

    await test('threshold type threshold emits once per window after count', () => {
      const r = parseRuleLine('alert tcp any any -> any any (msg:"t"; flags:S; threshold:type threshold, track by_src, count 3, seconds 60; sid:99;)', 't', 1, VARS);
      const rs = new RuleSet(VARS);
      rs.rules.push(r);
      const p = pkt({ tcp: { flags: 0x02 } });
      assert.strictEqual(rs.matchPacket(p).length, 0);
      assert.strictEqual(rs.matchPacket(p).length, 0);
      const third = rs.matchPacket(p);
      assert.strictEqual(third.length, 1);
      assert.strictEqual(rs.matchPacket(p).length, 0); // suppressed in same window
      const later = pkt({ tsSec: 1000 + 61, tcp: { flags: 0x02 } });
      assert.strictEqual(rs.matchPacket(later).length, 0); // new window, counting again
      rs.matchPacket(later);                                // count 2
      assert.strictEqual(rs.matchPacket(later).length, 1);  // count 3 → emits once
    });

    await test('EXTERNAL_NET rule matches external source, blocks internal', () => {
      const r = parseRuleLine('alert tcp $EXTERNAL_NET any -> $HOME_NET 22 (msg:"s"; flags:S; sid:55;)', 't', 1, VARS);
      const rs = new RuleSet(VARS);
      assert.strictEqual(rs._ruleMatches(r, pkt({ dstPort: 22, tcp: { flags: 0x02 } })), true);
      assert.strictEqual(rs._ruleMatches(r, pkt({ srcIp: '192.168.3.3', dstPort: 22, tcp: { flags: 0x02 } })), false);
    });

    await test('pcre matching with flags', () => {
      const r = parseRuleLine('alert tcp any any -> any any (msg:"p"; pcre:"/union.+select/i"; sid:66;)', 't', 1, VARS);
      const rs = new RuleSet(VARS);
      assert.strictEqual(rs._ruleMatches(r, pkt({ payload: Buffer.from('xx UNION blah SELECT xx') })), true);
      assert.strictEqual(rs._ruleMatches(r, pkt({ payload: Buffer.from('xx union blah select xx') })), true);
      assert.strictEqual(rs._ruleMatches(r, pkt({ payload: Buffer.from('nothing here') })), false);
    });
  });

  await section('PCAP parser', async () => {
    await test('parses classic little-endian pcap', () => {
      const cap = pcapParser.parseBuffer(pcapBuffer(builders.buildMixed()));
      assert.strictEqual(cap.format, 'pcap');
      assert.strictEqual(cap.packets.length, 14);
      const tcp = cap.packets.find((p) => p.proto === 'tcp' && p.payload && p.payload.length);
      assert(tcp, 'tcp packet with payload found');
      assert.strictEqual(tcp.srcPort, 54000);
      assert.strictEqual(tcp.dstPort, 80);
    });

    await test('parses big-endian (swapped) pcap', () => {
      const buf = pcapBuffer(builders.buildBruteForce());
      const swapped = Buffer.alloc(buf.length);
      buf.copy(swapped);
      swapped.writeUInt32BE(0xa1b2c3d4, 0); // big-endian magic marker
      // rebuild header fields as BE
      swapped.writeUInt16BE(2, 4); swapped.writeUInt16BE(4, 6);
      swapped.writeUInt32BE(65535, 16); swapped.writeUInt16BE(1, 20);
      let off = 24;
      while (off + 16 <= swapped.length) {
        for (const [o, sz] of [[0, 4], [4, 4], [8, 4], [12, 4]]) {
          const v = buf.readUInt32LE(off + o);
          swapped.writeUInt32BE(v, off + o);
        }
        const inclLen = buf.readUInt32LE(off + 8);
        off += 16 + inclLen;
      }
      const cap = pcapParser.parseBuffer(swapped);
      assert.strictEqual(cap.packets.length, 20);
      assert.strictEqual(cap.packets[0].proto, 'tcp');
    });

    await test('rejects garbage with clear error', () => {
      assert.throws(() => pcapParser.parseBuffer(Buffer.from('this is definitely not a pcap file at all.....')), pcapParser.PcapError);
      assert.throws(() => pcapParser.parseBuffer(Buffer.alloc(10)), pcapParser.PcapError);
    });

    await test('truncated record stops cleanly without throwing', () => {
      const buf = pcapBuffer(builders.buildPortScan());
      const truncated = buf.subarray(0, buf.length - 30); // cut mid-record
      const cap = pcapParser.parseBuffer(truncated);
      assert(cap.packets.length > 0);
    });

    await test('decodes VLAN-tagged ethernet and ICMPv6', () => {
      const inner = builders.ipv4('192.168.1.2', '192.168.1.3', 1, builders.icmpEcho(5, 1, Buffer.from('abcd')));
      const eth = Buffer.alloc(18);
      Buffer.from('020000000002', 'hex').copy(eth, 0);
      Buffer.from('020000000001', 'hex').copy(eth, 6);
      eth.writeUInt16BE(0x8100, 12);
      eth.writeUInt16BE(100, 14);
      eth.writeUInt16BE(0x0800, 16);
      const w = new builders.PcapWriter();
      w.add(builders.BASE_TS, Buffer.concat([eth, inner]));
      const cap = pcapParser.parseBuffer(pcapBuffer(w));
      assert.strictEqual(cap.packets.length, 1);
      assert.strictEqual(cap.packets[0].proto, 'icmp');
      assert.strictEqual(cap.packets[0].icmp.type, 8);
    });
  });

  await section('Analyzer (end-to-end on generated captures)', async () => {
    const rs = ruleset();
    const cases = [
      ['portscan.pcap', builders.buildPortScan, 3, [1000003, 1000004, 9000001]],
      ['web-attacks.pcap', builders.buildWebAttacks, 4, [1000005, 1000006, 1000007, 1000008]],
      ['brute-force.pcap', builders.buildBruteForce, 2, [1000001, 9000002]],
      ['mixed-traffic.pcap', builders.buildMixed, 5, [1000002, 1000009, 1000010, 1000011, 1000012]],
    ];
    for (const [name, build, count, sids] of cases) {
      await test(`${name} produces ${count} expected detections`, () => {
        const cap = pcapParser.parseBuffer(pcapBuffer(build()));
        const r = analyze(cap, rs, { heuristics: {} });
        const all = [...r.signatureAlerts, ...r.heuristicAlerts];
        assert.strictEqual(all.length, count, `alert count ${all.length} != ${count}: ${all.map((a) => a.signatureId).join(',')}`);
        for (const sid of sids) {
          assert(all.some((a) => a.signatureId === sid), `sid ${sid} expected`);
        }
      });
    }

    await test('benign-only capture yields zero alerts', () => {
      const w = new builders.PcapWriter();
      const dnsQ = Buffer.concat([
        Buffer.from([0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]),
        Buffer.from('076578616d706c6503636f6d00', 'hex'), Buffer.from([0x00, 0x01, 0x00, 0x01]),
      ]);
      const frame = builders.ethernet(builders.ipv4('192.168.1.5', '192.168.1.1', 17, builders.udp('192.168.1.5', '192.168.1.1', 4000, 53, dnsQ)));
      w.add(builders.BASE_TS, frame);
      const cap = pcapParser.parseBuffer(pcapBuffer(w));
      const r = analyze(cap, rs, { heuristics: {} });
      assert.strictEqual(r.signatureAlerts.length, 0);
      assert.strictEqual(r.heuristicAlerts.length, 0);
      assert.strictEqual(r.summary.flows, 1);
    });
  });

  await section('HTTP API', async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nids-test-'));
    process.env.NIDS_DATA_DIR = tmp;
    process.env.NIDS_PORT = '0';
    process.env.NIDS_ADMIN_TOKEN = 'test-token-123456';
    const { main } = require(path.join(ROOT, 'server', 'index.js'));
    const ctx = await main();
    if (!ctx.server.listening) {
      await new Promise((resolve) => ctx.server.once('listening', resolve));
    }
    const port = ctx.server.address().port;
    const B = `http://127.0.0.1:${port}`;
    const H = { Authorization: 'Bearer test-token-123456', 'Content-Type': 'application/json' };

    const get = async (p, headers) => {
      const res = await fetch(B + p, { headers });
      return { status: res.status, body: await res.json().catch(() => null) };
    };
    const post = async (p, body, headers = H, raw) => {
      const res = await fetch(B + p, {
        method: 'POST',
        headers,
        body: raw !== undefined ? raw : body !== undefined ? JSON.stringify(body) : undefined,
      });
      return { status: res.status, body: await res.json().catch(() => null) };
    };

    await test('GET /api/status reports engines accurately', async () => {
      const r = await get('/api/status');
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.body.monitor.active, false);
      assert.strictEqual(typeof r.body.monitor.capabilities.suricata.installed, 'boolean');
    });

    await test('mutations require the admin token', async () => {
      const noTok = await post('/api/monitor/start', { mode: 'dropzone' }, { 'Content-Type': 'application/json' });
      assert.strictEqual(noTok.status, 401);
      const badTok = await post('/api/monitor/start', { mode: 'dropzone' }, { 'Content-Type': 'application/json', Authorization: 'Bearer wrongwrong' });
      assert.strictEqual(badTok.status, 403);
    });

    await test('upload + analyze PCAP, alerts appear', async () => {
      const buf = pcapBuffer(builders.buildPortScan());
      const r = await post('/api/pcaps?name=portscan.pcap', undefined, { Authorization: 'Bearer test-token-123456' }, buf);
      assert.strictEqual(r.status, 200, JSON.stringify(r.body));
      assert.strictEqual(r.body.alertCount, 3);
      const list = await get('/api/alerts?source=pcap');
      assert.strictEqual(list.body.total, 3);
    });

    await test('invalid upload rejected safely', async () => {
      const r = await post('/api/pcaps?name=x.pcap', undefined, { Authorization: 'Bearer test-token-123456' }, Buffer.alloc(200, 0x41));
      assert.strictEqual(r.status, 422);
      assert(r.body.error.length > 5);
    });

    await test('severity sort uses rank not alphabet', async () => {
      await post('/api/pcaps?name=mixed.pcap', undefined, { Authorization: 'Bearer test-token-123456' }, pcapBuffer(builders.buildMixed()));
      const asc = await get('/api/alerts?sort=severity&dir=asc&perPage=50');
      const ranks = asc.body.rows.map((x) => ['critical', 'high', 'medium', 'low'].indexOf(x.severity));
      for (let i = 1; i < ranks.length; i++) assert(ranks[i] >= ranks[i - 1], 'ascending severity order violated');
    });

    await test('filters: severity, search, status', async () => {
      const crit = await get('/api/alerts?severity=critical');
      assert(crit.body.rows.every((x) => x.severity === 'critical'));
      const q = await get('/api/alerts?q=Nmap');
      assert(q.body.total >= 2);
    });

    await test('status change + note + audit trail', async () => {
      const list = await get('/api/alerts?perPage=1');
      const id = list.body.rows[0].id;
      const r = await post(`/api/alerts/${id}/status`, { status: 'acknowledged', note: 'test note' });
      assert.strictEqual(r.status, 200);
      const detail = await get(`/api/alerts/${id}`);
      assert.strictEqual(detail.body.alert.status, 'acknowledged');
      assert(detail.body.notes.length >= 1);
      assert(detail.body.recommendations.length >= 3);
      const audit = await get('/api/audit', H);
      assert(audit.body.entries.some((e) => e.action === 'alert-acknowledged'));
    });

    await test('bad status value rejected', async () => {
      const list = await get('/api/alerts?perPage=1');
      const r = await post(`/api/alerts/${list.body.rows[0].id}/status`, { status: 'bogus' });
      assert.strictEqual(r.status, 400);
    });

    await test('simulate creates clearly-labeled simulated alerts', async () => {
      const r = await post('/api/simulate', { scenario: 'c2' });
      assert.strictEqual(r.status, 200);
      const list = await get('/api/alerts?source=simulated');
      assert.strictEqual(list.body.total, 1);
      assert.strictEqual(list.body.rows[0].is_simulated, 1);
    });

    await test('unknown simulate scenario rejected', async () => {
      const r = await post('/api/simulate', { scenario: 'nope' });
      assert.strictEqual(r.status, 400);
    });

    await test('sample data is labeled and spread over 24h', async () => {
      const r = await post('/api/sample-data', {});
      assert.strictEqual(r.status, 200);
      const list = await get('/api/alerts?source=sample&perPage=50');
      assert.strictEqual(list.body.total, 15);
      assert(list.body.rows.every((x) => x.is_simulated === 1));
    });

    await test('monitoring start/stop lifecycle with real state', async () => {
      const start = await post('/api/monitor/start', { mode: 'dropzone' });
      assert.strictEqual(start.status, 200);
      const st = await get('/api/status');
      assert.strictEqual(st.body.monitor.active, true);
      assert.strictEqual(st.body.monitor.mode, 'dropzone');
      const again = await post('/api/monitor/start', { mode: 'dropzone' });
      assert.strictEqual(again.status, 400);
      const stop = await post('/api/monitor/stop', {});
      assert.strictEqual(stop.status, 200);
      const st2 = await get('/api/status');
      assert.strictEqual(st2.body.monitor.active, false);
    });

    await test('live mode refused cleanly when no engine installed', async () => {
      const caps = (await get('/api/status')).body.monitor.capabilities;
      if (!caps.suricata.installed && !caps.snort.installed) {
        const r = await post('/api/monitor/start', { mode: 'live' });
        assert.strictEqual(r.status, 400);
        assert(/not installed|no capture interface|cannot start/i.test(r.body.error), r.body.error);
      }
    });

    await test('rules endpoint lists parsed rules without errors', async () => {
      const r = await get('/api/rules');
      assert.strictEqual(r.status, 200);
      assert(r.body.count >= 12);
      assert.deepStrictEqual(r.body.errors, []);
    });

    await test('EVE log import ingests only alert events', async () => {
      const line = JSON.stringify({
        timestamp: '2026-10-16T12:00:00Z', event_type: 'alert', src_ip: '192.0.2.5', dest_ip: '192.168.1.9',
        proto: 'TCP', alert: { severity: 2, signature: 'TEST imported sig', category: 'Misc Attack', signature_id: 31337, gid: 1 },
      });
      const r = await post('/api/logs/import?kind=eve', undefined, { Authorization: 'Bearer test-token-123456', 'Content-Type': 'text/plain' }, line + '\n{"event_type":"flow"}\n');
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.body.ingested, 1);
      assert.strictEqual(r.body.skipped, 1);
    });

    await test('traffic flows endpoint returns flow records', async () => {
      const r = await get('/api/traffic/flows');
      assert.strictEqual(r.status, 200);
      assert(r.body.total > 0);
      assert(r.body.rows[0].bytes > 0);
    });

    await test('stats overview aggregates real data', async () => {
      const r = await get('/api/stats/overview');
      assert(r.body.total > 20);
      assert.strictEqual(r.body.bySeverity.reduce((s, x) => s + x.c, 0), r.body.total);
      const sevMap = Object.fromEntries(r.body.bySeverity.map((x) => [x.severity, x.c]));
      const crit = await get('/api/alerts?severity=critical');
      assert.strictEqual(sevMap.critical, crit.body.total);
    });

    await test('notification config validation', async () => {
      const bad = await post('/api/config/notifications', { webhookUrl: 'gopher://x', minSeverity: 'high' });
      assert.strictEqual(bad.status, 400);
      const ok = await post('/api/config/notifications', { webhookUrl: 'https://example.com/hook', minSeverity: 'critical' });
      assert.strictEqual(ok.status, 200);
      assert.strictEqual(ok.body.notifications.webhookConfigured, true);
    });

    await test('unknown API route 404s with JSON', async () => {
      const r = await get('/api/definitely-not-here');
      assert.strictEqual(r.status, 404);
      assert(r.body.error);
    });

    await test('static dashboard served', async () => {
      const res = await fetch(B + '/');
      assert.strictEqual(res.status, 200);
      const html = await res.text();
      assert(html.includes('Sentinel NIDS'));
    });

    ctx.monitor.stop('test');
    ctx.server.close();
    try { ctx.db.close(); } catch { /* best effort */ }
    await new Promise((r) => setTimeout(r, 400));
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch { /* Windows file locks: best effort */ }
  });

  console.log(`\n${'='.repeat(50)}`);
  console.log(`Result: ${passed} passed, ${failed} failed`);
  if (failed > 0) {
    console.log('Failures:');
    for (const [name, err] of failures) console.log(`  - ${name}: ${err.message}`);
    process.exit(1);
  }
}

main().catch((err) => {
  console.error('Test suite crashed:', err);
  process.exit(1);
});
