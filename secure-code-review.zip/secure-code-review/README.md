# Secure Coding Review

A local secure-code-review workflow: a Python AST scanner, a deliberately **insecure** training app, a **secure** default app, automated tests and generated reports (Markdown + HTML).

```
src/               scanner, external-tool runner, exploit proofs, report generator, CLI
sample_app/insecure/  INSECURE TRAINING SAMPLE (labelled VULN-nn; never deploy)
sample_app/secure/    remediated default application
tests/             unittest suite (secure app, scanner, exploit proofs)
reports/           generated report (.md/.html) and findings.json
docs/              before_after.md (generated)
```

## Prerequisites
Python 3.10+ and Flask (`pip install -r requirements.txt`). Optional: `pip install -r requirements-dev.txt` for Bandit, Ruff and pip-audit (pip-audit needs network access).

## Run
```
python -m src.cli scan sample_app/insecure     # scan one local directory
python -m src.cli audit                        # full workflow + reports
python -m unittest discover -s tests -t .      # tests only
bandit -r sample_app -f txt ; ruff check sample_app ; pip-audit -r requirements.txt   # optional external tools
APP_SECRET_KEY=$(python -c "import secrets;print(secrets.token_hex(32))") python -m sample_app.secure.app   # run secure app on 127.0.0.1
```
`audit` runs Bandit/Ruff/pip-audit only if installed, and the report states what actually executed. Output: `reports/security_audit_report.md|html`, `reports/findings.json`, `docs/before_after.md`.

## Severity
Critical: unconditional remote code execution. High: direct compromise of auth, data or code integrity. Medium: information leak or weakened defense. Low/Informational: hardening. Status values: Confirmed (exploit demonstrated / direct evidence), Potential risk, False positive, Informational. No CVSS scoring.

## Safety of the scanner
Scans only an explicitly given local directory; rejects symlinked targets, does not follow symlinks, and only parses code with `ast` (never imports or runs it). The exploit proofs run only against the bundled insecure sample using Flask's in-process test client.

## Limitations
Heuristic single-function analysis; no CSRF tokens, rate limiting, TLS or audit logging in the demo app; passing tests do not prove the app is secure. No dashboard was built (CLI + report chosen for reliability).

## Applying the recommendations
See `docs/before_after.md` for each vulnerable pattern, its fix and the regression test. Reuse the patterns in `sample_app/secure/app.py`.
