import os
import tempfile
import unittest

from sample_app.secure import app as sapp

PW = "Test-passw0rd-1"  # test-only value


class SecureAppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = os.path.join(self.tmp.name, "t.db")
        self.up = os.path.join(self.tmp.name, "up")
        os.mkdir(self.up)
        with open(os.path.join(self.up, "ok.txt"), "w") as fh:
            fh.write("hello")
        with open(os.path.join(self.tmp.name, "outside.txt"), "w") as fh:
            fh.write("TOPSECRET")
        self.app = sapp.create_app(self.db, secret_key="x" * 32, uploads_dir=self.up, secure_cookies=False)
        self.app.config["PROPAGATE_EXCEPTIONS"] = False
        self.alice = sapp.create_user(self.db, "alice", PW)
        self.bob = sapp.create_user(self.db, "bob", PW)
        sapp.create_user(self.db, "root_admin", PW, role="admin")

    def tearDown(self):
        self.tmp.cleanup()

    def client(self, user=None):
        c = self.app.test_client()
        if user:
            self.assertEqual(c.post("/login", json={"username": user, "password": PW}).status_code, 200)
        return c

    def test_sql_injection_login_rejected(self):
        for u in ("admin' --", "alice' OR '1'='1"):
            self.assertEqual(self.app.test_client().post("/login", json={"username": u, "password": "x"}).status_code, 401)

    def test_search_injection_returns_nothing(self):
        c = self.client("alice")
        c.post("/notes", json={"title": "mine", "body": "b"})
        rows = c.get("/search", query_string={"q": "zzz' OR 1=1 --"}).get_json()["rows"]
        self.assertEqual(rows, [])

    def test_login_validation_and_generic_errors(self):
        c = self.app.test_client()
        self.assertEqual(c.post("/login", json={"username": "alice", "password": "bad"}).get_json(), {"error": "invalid credentials"})
        self.assertEqual(c.post("/login", json={"username": "nobody", "password": "bad"}).get_json(), {"error": "invalid credentials"})
        self.assertEqual(c.post("/login", json={"username": 5, "password": ["x"]}).status_code, 401)

    def test_input_validation(self):
        for u, p in (("a", PW), ("bad name!", PW), ("okname", "short")):
            with self.assertRaises(ValueError):
                sapp.create_user(self.db, u, p)
        c = self.client("alice")
        self.assertEqual(c.post("/notes", json={"title": "", "body": "x"}).status_code, 400)
        self.assertEqual(c.get("/search", query_string={"q": "a" * 101}).status_code, 400)

    def test_passwords_are_salted_hashes(self):
        import sqlite3
        h = sqlite3.connect(self.db).execute("SELECT password_hash FROM users WHERE username='alice'").fetchone()[0]
        self.assertNotIn(PW, h)
        self.assertTrue(h.startswith(("scrypt:", "pbkdf2:")))
        h2 = sqlite3.connect(self.db).execute("SELECT password_hash FROM users WHERE username='bob'").fetchone()[0]
        self.assertNotEqual(h, h2)  # same password, different salt

    def test_xss_is_escaped(self):
        body = self.app.test_client().get("/greet", query_string={"name": "<script>alert(1)</script>"}).get_data(as_text=True)
        self.assertNotIn("<script>", body)
        self.assertIn("&lt;script&gt;", body)

    def test_authentication_required(self):
        c = self.app.test_client()
        for path in ("/search", "/note/1", "/admin/users", "/download?name=ok.txt", "/ping?host=127.0.0.1"):
            self.assertEqual(c.get(path).status_code, 401, path)

    def test_note_ownership_enforced(self):
        a = self.client("alice")
        nid = a.post("/notes", json={"title": "t", "body": "alice-private"}).get_json()["id"]
        self.assertEqual(a.get(f"/note/{nid}").get_json()["body"], "alice-private")
        self.assertEqual(self.client("bob").get(f"/note/{nid}").status_code, 404)

    def test_admin_requires_admin_role(self):
        self.assertEqual(self.client("alice").get("/admin/users").status_code, 403)
        self.assertEqual(self.client("root_admin").get("/admin/users").status_code, 200)

    def test_path_traversal_blocked(self):
        c = self.client("alice")
        self.assertEqual(c.get("/download", query_string={"name": "ok.txt"}).get_data(as_text=True), "hello")
        for n in ("../outside.txt", "..%2foutside.txt", "/etc/passwd"):
            r = c.get("/download", query_string={"name": n})
            self.assertEqual(r.status_code, 404, n)
            self.assertNotIn("TOPSECRET", r.get_data(as_text=True))

    def test_ping_rejects_injection(self):
        c = self.client("alice")
        for h in ("127.0.0.1; id", "$(id)", "a b", "-c5", "", "x" * 300):
            self.assertEqual(c.get("/ping", query_string={"host": h}).status_code, 400, h)

    def test_errors_do_not_leak_details(self):
        @self.app.route("/boom")
        def boom():
            raise ValueError("secret-internal-detail")
        with self.assertLogs("secure_app", level="ERROR"):
            r = self.app.test_client().get("/boom")
        self.assertEqual(r.status_code, 500)
        self.assertNotIn("secret-internal-detail", r.get_data(as_text=True))

    def test_missing_secret_fails_closed(self):
        os.environ.pop("APP_SECRET_KEY", None)
        with self.assertRaises(RuntimeError):
            sapp.create_app(self.db)

    def test_security_headers_and_cookie_flags(self):
        r = self.app.test_client().get("/greet")
        self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
        self.assertIn("default-src 'none'", r.headers["Content-Security-Policy"])
        self.assertTrue(self.app.config["SESSION_COOKIE_HTTPONLY"])
        self.assertEqual(self.app.config["SESSION_COOKIE_SAMESITE"], "Lax")

    def test_no_hardcoded_secret_in_source(self):
        with open(sapp.__file__) as fh:
            src = fh.read()
        self.assertNotIn("secret_key=\"", src.replace(" ", ""))


if __name__ == "__main__":
    unittest.main()
