import os
import tempfile
import unittest

from src import scanner, verify

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class ScannerTests(unittest.TestCase):
    def test_insecure_sample_detected(self):
        res = scanner.scan_directory(os.path.join(ROOT, "sample_app", "insecure"))
        rules = {f.rule for f in res["findings"]}
        self.assertTrue({"SCR-001", "SCR-002", "SCR-003", "SCR-004", "SCR-005", "SCR-006", "SCR-007", "SCR-008", "SCR-009"} <= rules)
        keys = [(f.rule, f.file, f.line) for f in res["findings"]]
        self.assertEqual(len(keys), len(set(keys)))  # no duplicates

    def test_secure_app_is_clean(self):
        res = scanner.scan_directory(os.path.join(ROOT, "sample_app", "secure"))
        self.assertEqual(res["findings"], [], res["findings"])

    def test_exploit_proofs_confirm_flaws_in_insecure_sample(self):
        proofs = verify.exploit_proofs()
        self.assertTrue(all(proofs.values()), proofs)

    def test_path_validation(self):
        with tempfile.TemporaryDirectory() as d:
            f = os.path.join(d, "f.txt")
            open(f, "w").close()
            link = os.path.join(d, "link")
            os.symlink(d, link)
            for bad in (f, os.path.join(d, "missing"), link):
                with self.assertRaises(ValueError):
                    scanner.validate_target(bad)
            with self.assertRaises(ValueError):
                scanner.validate_target(d, allowed_root=os.path.join(d, "sub"))

    def test_scanner_never_executes_code(self):
        with tempfile.TemporaryDirectory() as d:
            marker = os.path.join(d, "marker")
            with open(os.path.join(d, "evil.py"), "w") as fh:
                fh.write(f"open({marker!r}, 'w').write('x')\nimport os\nos.system('echo hi')\n")
            res = scanner.scan_directory(d)
            self.assertFalse(os.path.exists(marker))
            self.assertIn("SCR-002", {f.rule for f in res["findings"]})

    def test_symlinked_files_not_followed(self):
        with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as other:
            with open(os.path.join(other, "x.py"), "w") as fh:
                fh.write("import os\nos.system('x')\n")
            os.symlink(os.path.join(other, "x.py"), os.path.join(d, "x.py"))
            self.assertEqual(scanner.scan_directory(d)["files"], 0)

    def test_syntax_errors_are_reported_not_fatal(self):
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, "bad.py"), "w") as fh:
                fh.write("def (:\n")
            res = scanner.scan_directory(d)
            self.assertEqual(len(res["errors"]), 1)


if __name__ == "__main__":
    unittest.main()
