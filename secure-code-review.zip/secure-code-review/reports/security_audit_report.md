# Secure Coding Review Report

Generated: 2026-10-20 14:06 UTC  
Target: `sample_app/insecure` (deliberately vulnerable training code) and `sample_app/secure` (remediated).

## 1. Executive summary

The built-in scanner reported **17 findings** in the insecure training sample across 2 Python files (3 confirmed (direct evidence), 10 confirmed (exploit demonstrated), 1 false positive, 2 potential risk (not exercised), 1 informational). The remediated application produced **0 findings** with the same scanner. Of the external analyzers, 0 of 3 actually executed (see Tools). Automated test result: **22 tests executed, OK**. This does not prove the application is secure (see Remaining risks).

## 2. Audit scope

- `sample_app/insecure/vulnerable_app.py` - intentionally flawed Flask app (educational).
- `sample_app/secure/app.py` - remediated default app.
- Only local code written for this project; no third-party systems were touched.

## 3. Methodology

1. Static AST analysis with the project's own rules (code is parsed, never executed).
2. Manual inspection of every route, query, hash, file access and config line.
3. Exploit proofs against the insecure sample using Flask's in-process test client to upgrade findings from *potential* to *confirmed*.
4. Re-scan and regression tests against the secure app.

Severity model (qualitative, impact x ease of exploitation): **Critical** remote code execution with no preconditions; **High** direct compromise of data/auth/code integrity; **Medium** information leak or weakened defense; **Low** minor hardening; **Informational** best-practice note. No CVSS scores were computed.
Status model: *Confirmed (exploit demonstrated)*, *Confirmed (direct evidence)* (flaw visible in source), *Potential risk (not exercised)*, *False positive*, *Informational*.

## 4. Tools used

| Tool | Status | Detail |
|---|---|---|
| Built-in AST scanner (`src/scanner.py`) | executed | rules SCR-001..SCR-011 |
| Bandit | not executed | bandit is not installed in this environment (issues: n/a) |
| Ruff | not executed | ruff is not installed in this environment (issues: n/a) |
| pip-audit | not executed | pip-audit is not installed in this environment (issues: n/a) |

## 5. Findings summary

| Severity | Count (excl. false positives/informational) |
|---|---|
| Critical | 0 |
| High | 14 |
| Medium | 1 |
| Low | 0 |

| ID | Severity | Title | Location | Status |
|---|---|---|---|---|
| F-001 | High | Hardcoded secret or password | vulnerable_app.py:15 | Confirmed (direct evidence) |
| F-002 | High | Hardcoded secret or password | vulnerable_app.py:16 | Confirmed (direct evidence) |
| F-003 | High | Weak password hashing (MD5) | vulnerable_app.py:20 | Confirmed (exploit demonstrated) |
| F-004 | High | SQL injection via dynamically built query | vulnerable_app.py:46 | Confirmed (exploit demonstrated) |
| F-005 | High | Reflected cross-site scripting | vulnerable_app.py:53 | Confirmed (exploit demonstrated) |
| F-006 | High | Missing authentication/authorization check | vulnerable_app.py:56 | Confirmed (exploit demonstrated) |
| F-007 | High | SQL injection via dynamically built query | vulnerable_app.py:61 | Confirmed (exploit demonstrated) |
| F-008 | Medium | Internal error details returned to client | vulnerable_app.py:63 | Confirmed (exploit demonstrated) |
| F-009 | High | Missing authentication/authorization check | vulnerable_app.py:68 | Confirmed (exploit demonstrated) |
| F-010 | High | SQL injection via dynamically built query | vulnerable_app.py:70 | False positive |
| F-011 | High | Missing authentication/authorization check | vulnerable_app.py:75 | Confirmed (exploit demonstrated) |
| F-012 | High | Missing authentication/authorization check | vulnerable_app.py:82 | Confirmed (exploit demonstrated) |
| F-013 | High | Path traversal in file access | vulnerable_app.py:83 | Confirmed (exploit demonstrated) |
| F-014 | High | Missing authentication/authorization check | vulnerable_app.py:87 | Potential risk (not exercised) |
| F-015 | High | Shell command built from user input | vulnerable_app.py:88 | Potential risk (not exercised) |
| F-016 | High | Debug mode enabled | vulnerable_app.py:95 | Confirmed (direct evidence) |
| F-017 | Informational | Server bound to all interfaces | vulnerable_app.py:95 | Informational |

## 6. Detailed findings

### F-001: Hardcoded secret or password

- **Severity:** High
- **Status:** Confirmed (direct evidence)
- **Location:** `vulnerable_app.py:15` (function `<module>`)
- **Reference:** CWE-798; OWASP A07:2021 Identification and Authentication Failures
- **Description:** A secret-like name is assigned a string literal in source.
- **Impact:** Anyone with source access can forge sessions or log in.
- **Remediation:** Load secrets from the environment/secret store; fail closed if missing.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_missing_secret_fails_closed / test_scanner.test_secure_app_is_clean`.

Evidence:

```python
SECRET_KEY = "training-only-secret"  # VULN-08 hardcoded secret
```

Corrected pattern:

```python
os.environ.get("APP_SECRET_KEY")  # raise if absent
```

### F-002: Hardcoded secret or password

- **Severity:** High
- **Status:** Confirmed (direct evidence)
- **Location:** `vulnerable_app.py:16` (function `<module>`)
- **Reference:** CWE-798; OWASP A07:2021 Identification and Authentication Failures
- **Description:** A secret-like name is assigned a string literal in source.
- **Impact:** Anyone with source access can forge sessions or log in.
- **Remediation:** Load secrets from the environment/secret store; fail closed if missing.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_missing_secret_fails_closed / test_scanner.test_secure_app_is_clean`.

Evidence:

```python
ADMIN_PASSWORD = "admin123"  # VULN-08 hardcoded password
```

Corrected pattern:

```python
os.environ.get("APP_SECRET_KEY")  # raise if absent
```

### F-003: Weak password hashing (MD5)

- **Severity:** High
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:20` (function `_md5`)
- **Reference:** CWE-327 / CWE-916; OWASP A02:2021 Cryptographic Failures
- **Description:** Passwords are hashed with fast, unsalted MD5.
- **Impact:** Stolen hashes can be cracked quickly; identical passwords share hashes.
- **Remediation:** Use a slow salted password hash (scrypt/PBKDF2/Argon2).
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_passwords_are_salted_hashes`.

Evidence:

```python
return hashlib.md5(text.encode()).hexdigest()  # VULN-03 weak, unsalted hash
```

Corrected pattern:

```python
generate_password_hash(password)  # werkzeug, salted
```

### F-004: SQL injection via dynamically built query

- **Severity:** High
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:46` (function `login`)
- **Reference:** CWE-89; OWASP A03:2021 Injection
- **Description:** User input is concatenated/formatted into SQL text, so input can change query structure.
- **Impact:** Authentication bypass, data disclosure or modification.
- **Remediation:** Use parameterized queries and validate input.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_sql_injection_login_rejected / test_search_injection_returns_nothing`.

Evidence:

```python
row = c.execute(q).fetchone()
```

Corrected pattern:

```python
con.execute("SELECT id FROM users WHERE username = ?", (name,))
```

### F-005: Reflected cross-site scripting

- **Severity:** High
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:53` (function `greet`)
- **Reference:** CWE-79; OWASP A03:2021 Injection
- **Description:** Request data is placed into HTML without output encoding.
- **Impact:** Script execution in victims' browsers (session abuse, phishing).
- **Remediation:** Escape on output, restrict length, add a restrictive CSP.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_xss_is_escaped`.

Evidence:

```python
return f"<h1>Hello {request.args.get('name', '')}</h1>"
```

Corrected pattern:

```python
return f"<h1>Hello {escape(name)}</h1>"
```

### F-006: Missing authentication/authorization check

- **Severity:** High
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:56` (function `search`)
- **Reference:** CWE-306 / CWE-862 / CWE-639; OWASP A01:2021 Broken Access Control
- **Description:** Route has no server-side authentication decorator or session check; object access has no ownership check.
- **Impact:** Anonymous access to data and admin functions; users reading others' records (IDOR).
- **Remediation:** Require login/role on the server and filter by owner.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_authentication_required / test_note_ownership_enforced / test_admin_requires_admin_role`.

Evidence:

```python
def search():  # VULN-07 no authentication
```

Corrected pattern:

```python
@login_required
... WHERE id = ? AND owner = ?
```

### F-007: SQL injection via dynamically built query

- **Severity:** High
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:61` (function `search`)
- **Reference:** CWE-89; OWASP A03:2021 Injection
- **Description:** User input is concatenated/formatted into SQL text, so input can change query structure.
- **Impact:** Authentication bypass, data disclosure or modification.
- **Remediation:** Use parameterized queries and validate input.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_sql_injection_login_rejected / test_search_injection_returns_nothing`.

Evidence:

```python
return jsonify(rows=c.execute("SELECT title FROM notes WHERE title LIKE '%" + q + "%'").fetchall())
```

Corrected pattern:

```python
con.execute("SELECT id FROM users WHERE username = ?", (name,))
```

### F-008: Internal error details returned to client

- **Severity:** Medium
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:63` (function `search`)
- **Reference:** CWE-209; OWASP A05:2021 Security Misconfiguration
- **Description:** Exception text is returned in the HTTP response.
- **Impact:** Leaks schema/query details that aid further attacks.
- **Remediation:** Log server-side, return a generic message.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_errors_do_not_leak_details`.

Evidence:

```python
return str(e), 500  # VULN-05 internal error text returned to client
```

Corrected pattern:

```python
log.exception("unhandled error")
return jsonify(error="internal error"), 500
```

### F-009: Missing authentication/authorization check

- **Severity:** High
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:68` (function `note`)
- **Reference:** CWE-306 / CWE-862 / CWE-639; OWASP A01:2021 Broken Access Control
- **Description:** Route has no server-side authentication decorator or session check; object access has no ownership check.
- **Impact:** Anonymous access to data and admin functions; users reading others' records (IDOR).
- **Remediation:** Require login/role on the server and filter by owner.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_authentication_required / test_note_ownership_enforced / test_admin_requires_admin_role`.

Evidence:

```python
def note(note_id):  # VULN-07 no auth, no ownership check (IDOR)
```

Corrected pattern:

```python
@login_required
... WHERE id = ? AND owner = ?
```

### F-010: SQL injection via dynamically built query

- **Severity:** High
- **Status:** False positive
- **Location:** `vulnerable_app.py:70` (function `note`)
- **Reference:** CWE-89; OWASP A03:2021 Injection
- **Description:** User input is concatenated/formatted into SQL text, so input can change query structure.
- **Impact:** Authentication bypass, data disclosure or modification.
- **Remediation:** Use parameterized queries and validate input.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_sql_injection_login_rejected / test_search_injection_returns_nothing`.
- **Triage note:** note_id comes from Flask's <int:...> converter, so only integers reach the f-string. Not exploitable, but parameterization is still recommended as hardening.

Evidence:

```python
rows = c.execute(f"SELECT body FROM notes WHERE id={note_id}").fetchall()  # int converter: see triage
```

Corrected pattern:

```python
con.execute("SELECT id FROM users WHERE username = ?", (name,))
```

### F-011: Missing authentication/authorization check

- **Severity:** High
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:75` (function `admin`)
- **Reference:** CWE-306 / CWE-862 / CWE-639; OWASP A01:2021 Broken Access Control
- **Description:** Route has no server-side authentication decorator or session check; object access has no ownership check.
- **Impact:** Anonymous access to data and admin functions; users reading others' records (IDOR).
- **Remediation:** Require login/role on the server and filter by owner.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_authentication_required / test_note_ownership_enforced / test_admin_requires_admin_role`.

Evidence:

```python
def admin():  # VULN-07 admin data without any check
```

Corrected pattern:

```python
@login_required
... WHERE id = ? AND owner = ?
```

### F-012: Missing authentication/authorization check

- **Severity:** High
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:82` (function `download`)
- **Reference:** CWE-306 / CWE-862 / CWE-639; OWASP A01:2021 Broken Access Control
- **Description:** Route has no server-side authentication decorator or session check; object access has no ownership check.
- **Impact:** Anonymous access to data and admin functions; users reading others' records (IDOR).
- **Remediation:** Require login/role on the server and filter by owner.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_authentication_required / test_note_ownership_enforced / test_admin_requires_admin_role`.

Evidence:

```python
def download():  # VULN-06 path traversal and VULN-07 no auth
```

Corrected pattern:

```python
@login_required
... WHERE id = ? AND owner = ?
```

### F-013: Path traversal in file access

- **Severity:** High
- **Status:** Confirmed (exploit demonstrated)
- **Location:** `vulnerable_app.py:83` (function `download`)
- **Reference:** CWE-22; OWASP A01:2021 Broken Access Control
- **Description:** A user-supplied name is joined to a base directory and opened without containment checks.
- **Impact:** Reading arbitrary files readable by the process.
- **Remediation:** Use send_from_directory / safe_join so the result stays in the base directory.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_path_traversal_blocked`.

Evidence:

```python
with open(os.path.join(UPLOADS, request.args.get("name", ""))) as fh:
```

Corrected pattern:

```python
send_from_directory(uploads, name)
```

### F-014: Missing authentication/authorization check

- **Severity:** High
- **Status:** Potential risk (not exercised)
- **Location:** `vulnerable_app.py:87` (function `ping`)
- **Reference:** CWE-306 / CWE-862 / CWE-639; OWASP A01:2021 Broken Access Control
- **Description:** Route has no server-side authentication decorator or session check; object access has no ownership check.
- **Impact:** Anonymous access to data and admin functions; users reading others' records (IDOR).
- **Remediation:** Require login/role on the server and filter by owner.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_authentication_required / test_note_ownership_enforced / test_admin_requires_admin_role`.

Evidence:

```python
def ping():  # VULN-02 command injection and VULN-07 no auth
```

Corrected pattern:

```python
@login_required
... WHERE id = ? AND owner = ?
```

### F-015: Shell command built from user input

- **Severity:** High
- **Status:** Potential risk (not exercised)
- **Location:** `vulnerable_app.py:88` (function `ping`)
- **Reference:** CWE-78; OWASP A03:2021 Injection
- **Description:** A command string containing user input is run with shell=True.
- **Impact:** Arbitrary command execution as the application user.
- **Remediation:** Avoid the shell; pass an argument list, validate the host, set a timeout.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_secure_app.test_ping_rejects_injection`.

Evidence:

```python
out = subprocess.run("ping -c 1 " + request.args.get("host", ""), shell=True, capture_output=True, text=True)
```

Corrected pattern:

```python
subprocess.run(["ping", "-c", "1", host], timeout=5)  # after ip/hostname validation
```

### F-016: Debug mode enabled

- **Severity:** High
- **Status:** Confirmed (direct evidence)
- **Location:** `vulnerable_app.py:95` (function `<module>`)
- **Reference:** CWE-489 / CWE-215; OWASP A05:2021 Security Misconfiguration
- **Description:** app.run(debug=True) exposes the interactive debugger.
- **Impact:** Remote code execution risk if reachable.
- **Remediation:** Never enable debug outside local development.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_scanner.test_secure_app_is_clean`.

Evidence:

```python
create_app("insecure_demo.db").run(debug=True, host="0.0.0.0")  # VULN-09/10 debug + all interfaces
```

Corrected pattern:

```python
app.run(host="127.0.0.1")
```

### F-017: Server bound to all interfaces

- **Severity:** Informational
- **Status:** Informational
- **Location:** `vulnerable_app.py:95` (function `<module>`)
- **Reference:** CWE-668; OWASP A05:2021 Security Misconfiguration
- **Description:** host='0.0.0.0' exposes the server on every network interface.
- **Impact:** Wider exposure than necessary.
- **Remediation:** Bind to 127.0.0.1 or put behind a reverse proxy.
- **Verification:** Rule not reported in `sample_app/secure` by the re-scan. Regression test: `test_scanner.test_secure_app_is_clean`.
- **Triage note:** Binding to all interfaces is only exploitable together with debug mode; see SCR-009.

Evidence:

```python
create_app("insecure_demo.db").run(debug=True, host="0.0.0.0")  # VULN-09/10 debug + all interfaces
```

Corrected pattern:

```python
app.run(host="127.0.0.1")
```

## 7. Remediation plan

1. Remove hardcoded secrets; inject via environment (SCR-008). 2. Parameterize all SQL (SCR-001). 3. Replace MD5 with salted slow hashing (SCR-003). 4. Enforce authentication, roles and ownership on the server (SCR-007). 5. Escape output (SCR-004), contain file paths (SCR-006), remove shell use (SCR-002). 6. Generic errors, no debug, local bind (SCR-005/009/010). All are implemented in `sample_app/secure/app.py`.

## 8. Remaining risks

- The secure app has no CSRF tokens (mitigated only by SameSite=Lax) and no login rate limiting/lockout.
- No TLS/reverse-proxy hardening, session revocation, audit logging or password-reset flow is implemented.
- `/ping` was only tested for input rejection; a real ping was not executed in tests.
- The scanner is heuristic: it follows simple intra-function data flow only and can miss or over-report. `# scr:public` markers suppress the authentication rule and need review (3 used in the secure app).
- SQLite and Flask versions were not checked for CVEs unless pip-audit executed (see Tools).

## 9. Testing limitations

- Network access was unavailable, so pip-audit could not query advisories; Bandit/Ruff run only if installed (see Tools table for what actually ran).
- Tests use Flask's in-process client; no browser, fuzzing, or load testing.

## 10. Final security assessment

The insecure sample is unsafe by design. The remediated sample fixes every finding the tooling and manual review identified, and its test suite result is: 22 tests executed, OK. That reduces known risk but does not establish that the application is completely secure; treat it as a teaching reference, not a production-ready system.
