# Before-and-after code comparison

Insecure examples live only in `sample_app/insecure/` (training samples).

## SCR-001: SQL injection via dynamically built query

**Problem:** User input is concatenated/formatted into SQL text, so input can change query structure. (CWE-89)

Vulnerable:

```python
q = "... WHERE username='%s'" % name
con.execute(q)
```

Corrected:

```python
con.execute("SELECT id FROM users WHERE username = ?", (name,))
```

**Why safer:** Use parameterized queries and validate input.

**Regression test:** `test_secure_app.test_sql_injection_login_rejected / test_search_injection_returns_nothing`

## SCR-002: Shell command built from user input

**Problem:** A command string containing user input is run with shell=True. (CWE-78)

Vulnerable:

```python
subprocess.run("ping -c 1 " + host, shell=True)
```

Corrected:

```python
subprocess.run(["ping", "-c", "1", host], timeout=5)  # after ip/hostname validation
```

**Why safer:** Avoid the shell; pass an argument list, validate the host, set a timeout.

**Regression test:** `test_secure_app.test_ping_rejects_injection`

## SCR-003: Weak password hashing (MD5)

**Problem:** Passwords are hashed with fast, unsalted MD5. (CWE-327 / CWE-916)

Vulnerable:

```python
hashlib.md5(password.encode()).hexdigest()
```

Corrected:

```python
generate_password_hash(password)  # werkzeug, salted
```

**Why safer:** Use a slow salted password hash (scrypt/PBKDF2/Argon2).

**Regression test:** `test_secure_app.test_passwords_are_salted_hashes`

## SCR-004: Reflected cross-site scripting

**Problem:** Request data is placed into HTML without output encoding. (CWE-79)

Vulnerable:

```python
return f"<h1>Hello {name}</h1>"
```

Corrected:

```python
return f"<h1>Hello {escape(name)}</h1>"
```

**Why safer:** Escape on output, restrict length, add a restrictive CSP.

**Regression test:** `test_secure_app.test_xss_is_escaped`

## SCR-005: Internal error details returned to client

**Problem:** Exception text is returned in the HTTP response. (CWE-209)

Vulnerable:

```python
except Exception as e:
    return str(e), 500
```

Corrected:

```python
log.exception("unhandled error")
return jsonify(error="internal error"), 500
```

**Why safer:** Log server-side, return a generic message.

**Regression test:** `test_secure_app.test_errors_do_not_leak_details`

## SCR-006: Path traversal in file access

**Problem:** A user-supplied name is joined to a base directory and opened without containment checks. (CWE-22)

Vulnerable:

```python
open(os.path.join(UPLOADS, name))
```

Corrected:

```python
send_from_directory(uploads, name)
```

**Why safer:** Use send_from_directory / safe_join so the result stays in the base directory.

**Regression test:** `test_secure_app.test_path_traversal_blocked`

## SCR-007: Missing authentication/authorization check

**Problem:** Route has no server-side authentication decorator or session check; object access has no ownership check. (CWE-306 / CWE-862 / CWE-639)

Vulnerable:

```python
@app.route("/note/<int:id>")
def note(id): ...
```

Corrected:

```python
@login_required
... WHERE id = ? AND owner = ?
```

**Why safer:** Require login/role on the server and filter by owner.

**Regression test:** `test_secure_app.test_authentication_required / test_note_ownership_enforced / test_admin_requires_admin_role`

## SCR-008: Hardcoded secret or password

**Problem:** A secret-like name is assigned a string literal in source. (CWE-798)

Vulnerable:

```python
SECRET_KEY = "...literal..."
```

Corrected:

```python
os.environ.get("APP_SECRET_KEY")  # raise if absent
```

**Why safer:** Load secrets from the environment/secret store; fail closed if missing.

**Regression test:** `test_secure_app.test_missing_secret_fails_closed / test_scanner.test_secure_app_is_clean`

## SCR-009: Debug mode enabled

**Problem:** app.run(debug=True) exposes the interactive debugger. (CWE-489 / CWE-215)

Vulnerable:

```python
app.run(debug=True)
```

Corrected:

```python
app.run(host="127.0.0.1")
```

**Why safer:** Never enable debug outside local development.

**Regression test:** `test_scanner.test_secure_app_is_clean`

## SCR-010: Server bound to all interfaces

**Problem:** host='0.0.0.0' exposes the server on every network interface. (CWE-668)

Vulnerable:

```python
app.run(host="0.0.0.0")
```

Corrected:

```python
app.run(host="127.0.0.1")
```

**Why safer:** Bind to 127.0.0.1 or put behind a reverse proxy.

**Regression test:** `test_scanner.test_secure_app_is_clean`

## SCR-011: Dangerous dynamic execution/deserialization

**Problem:** eval/exec/pickle/yaml.load on data may execute attacker code. (CWE-95 / CWE-502)

Vulnerable:

```python
eval(data)
```

Corrected:

```python
json.loads(data)
```

**Why safer:** Use json / yaml.safe_load; never eval input.

**Regression test:** `n/a (rule not triggered in sample)`
