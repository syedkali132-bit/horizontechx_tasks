"""CLI: python -m src.cli scan <dir> | audit"""
import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

from src import report, scanner, tools, verify

ROOT = Path(__file__).resolve().parent.parent


def run_tests():
    p = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-t", "."], cwd=ROOT, capture_output=True, text=True, check=False)
    ran = re.search(r"Ran (\d+) tests?", p.stderr)
    verdict = "OK" if p.returncode == 0 else "FAILED"
    return {"ok": p.returncode == 0, "summary": f"{ran[1] if ran else '?'} tests executed, {verdict}", "tail": p.stderr[-400:]}


def cmd_scan(a):
    res = scanner.scan_directory(a.directory)
    for f in res["findings"]:
        print(f"{f.rule} {f.file}:{f.line} [{f.function}] {report.RULES[f.rule][0]}")
    print(f"{len(res['findings'])} findings in {res['files']} files; {res['suppressed']} public-endpoint suppressions; parse errors: {res['errors'] or 'none'}")
    return 1 if res["findings"] else 0


def cmd_audit(a):
    ins = scanner.scan_directory(ROOT / "sample_app" / "insecure")
    sec = scanner.scan_directory(ROOT / "sample_app" / "secure")
    ctx = {"insecure": ins, "secure": sec, "proofs": verify.exploit_proofs(), "tests": run_tests(),
           "tools": tools.run_external(ROOT / "sample_app", ROOT / "requirements.txt"), "when": report.now()}
    out = ROOT / "reports"
    out.mkdir(exist_ok=True)
    md = report.build_markdown(ctx)
    (out / "security_audit_report.md").write_text(md, encoding="utf-8")
    (out / "security_audit_report.html").write_text(report.md_to_html(md), encoding="utf-8")
    (out / "findings.json").write_text(json.dumps([vars(f) for f in ins["findings"]], indent=2), encoding="utf-8")
    (ROOT / "docs" / "before_after.md").write_text(report.build_before_after(), encoding="utf-8")
    print(f"insecure findings: {len(ins['findings'])}; secure findings: {len(sec['findings'])}; tests: {ctx['tests']['summary']}")
    for t in ctx["tools"]:
        print(f"  {t['tool']}: {t['status']}")
    return 0 if ctx["tests"]["ok"] else 1


def main():
    ap = argparse.ArgumentParser(prog="secure-review")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan", help="scan a local directory")
    s.add_argument("directory")
    s.set_defaults(fn=cmd_scan)
    sub.add_parser("audit", help="full workflow + reports").set_defaults(fn=cmd_audit)
    a = ap.parse_args()
    try:
        sys.exit(a.fn(a))
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
