"""Exploit proofs against the bundled INSECURE sample (local test client only) and triage data."""
import hashlib
import os
import tempfile

# (rule, function) -> (status, rationale) for manual triage decisions
TRIAGE = {
    ("SCR-001", "note"): ("False positive", "note_id comes from Flask's <int:...> converter, so only integers reach the f-string. "
                          "Not exploitable, but parameterization is still recommended as hardening."),
    ("SCR-010", "<module>"): ("Informational", "Binding to all interfaces is only exploitable together with debug mode; see SCR-009."),
}
CONFIRMED_BY_EVIDENCE = {"SCR-008", "SCR-009"}  # the vulnerable literal/flag is directly visible in source


def exploit_proofs():
    """Return {(rule, function): bool}. True means the flaw was actually demonstrated."""
    from sample_app.insecure import vulnerable_app as va
    with tempfile.TemporaryDirectory() as d:
        c = va.create_app(os.path.join(d, "t.db")).test_client()
        r = c.post("/login", json={"username": "admin' --", "password": "wrong"})
        sqli_login = r.status_code == 200 and r.get_json().get("role") == "admin"
        sqli_search = "alice note" in c.get("/search", query_string={"q": "zzz' OR 1=1 --"}).get_data(as_text=True)
        leak = c.get("/search", query_string={"q": "'"})
        xss = "<script>alert(1)</script>" in c.get("/greet", query_string={"name": "<script>alert(1)</script>"}).get_data(as_text=True)
        trav = "VULN-01" in c.get("/download", query_string={"name": "../vulnerable_app.py"}).get_data(as_text=True)
        no_auth_search = c.get("/search").status_code == 200
        no_auth_dl = c.get("/download", query_string={"name": "../vulnerable_app.py"}).status_code == 200
        idor = "bob private data" in c.get("/note/1").get_data(as_text=True)
        admin = "alice" in c.get("/admin").get_data(as_text=True)
        md5 = va._md5("x") == hashlib.md5(b"x").hexdigest()  # unsalted, fast MD5
    return {
        ("SCR-001", "login"): sqli_login, ("SCR-001", "search"): sqli_search,
        ("SCR-005", "search"): leak.status_code == 500 and any(k in leak.get_data(as_text=True).lower() for k in ("syntax error", "unrecognized token")),
        ("SCR-004", "greet"): xss, ("SCR-006", "download"): trav,
        ("SCR-007", "search"): no_auth_search, ("SCR-007", "download"): no_auth_dl,
        ("SCR-007", "note"): idor, ("SCR-007", "admin"): admin, ("SCR-003", "_md5"): md5,
    }
