"""AST-based security scanner. Parses source only; never imports or executes scanned code."""
import ast
import os
import re
from dataclasses import dataclass
from pathlib import Path

SECRET_NAME = re.compile(r"(passw(or)?d|secret|api_?key|token|private_key)", re.I)
SQL_WORD = re.compile(r"\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE)\b", re.I)
AUTH_DECOS = {"login_required", "admin_required"}
SKIP_DIRS = {"__pycache__", ".git", ".venv", "venv", "node_modules", "reports"}
MAX_BYTES = 1_000_000


@dataclass
class Finding:
    rule: str
    file: str
    line: int
    function: str
    evidence: str


def validate_target(path, allowed_root=None):
    """Accept only an existing, non-symlink local directory (optionally inside allowed_root)."""
    p = Path(path)
    if p.is_symlink():
        raise ValueError("target is a symbolic link; refusing")
    r = p.resolve()
    if not r.is_dir():
        raise ValueError(f"not a directory: {path}")
    if allowed_root is not None and not r.is_relative_to(Path(allowed_root).resolve()):
        raise ValueError("target outside allowed root")
    return r


def dotted(n):
    parts = []
    while isinstance(n, ast.Attribute):
        parts.append(n.attr)
        n = n.value
    if isinstance(n, ast.Name):
        parts.append(n.id)
        return ".".join(reversed(parts))
    return ""


def const_text(n):
    return " ".join(c.value for c in ast.walk(n) if isinstance(c, ast.Constant) and isinstance(c.value, str))


def dynamic_str(n):
    if isinstance(n, ast.JoinedStr):
        return any(isinstance(v, ast.FormattedValue) for v in n.values)
    if isinstance(n, ast.BinOp) and isinstance(n.op, (ast.Add, ast.Mod)):
        return any(isinstance(c, ast.Constant) and isinstance(c.value, str) for c in ast.walk(n)) and not (
            isinstance(n.left, ast.Constant) and isinstance(n.right, ast.Constant))
    return isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "format"


class _Visitor(ast.NodeVisitor):
    def __init__(self, rel, lines):
        self.rel, self.lines = rel, lines
        self.findings, self.suppressed = [], 0
        self.funcs, self.dyn, self.exc = [], [], []

    def add(self, rule, node):
        ln = node.lineno
        self.findings.append(Finding(rule, self.rel, ln, self.funcs[-1] if self.funcs else "<module>",
                                     self.lines[ln - 1].strip()[:200]))

    def visit_FunctionDef(self, node):
        names = set()
        for s in ast.walk(node):
            if isinstance(s, ast.Assign) and dynamic_str(s.value) and SQL_WORD.search(const_text(s.value)):
                names |= {t.id for t in s.targets if isinstance(t, ast.Name)}
        self.funcs.append(node.name)
        self.dyn.append(names)
        self._authz(node)
        self.generic_visit(node)
        self.funcs.pop()
        self.dyn.pop()

    def _authz(self, node):
        routes = [d for d in node.decorator_list if isinstance(d, ast.Call) and dotted(d.func).endswith(".route")]
        if not routes:
            return
        decos = {dotted(d.func if isinstance(d, ast.Call) else d).split(".")[-1] for d in node.decorator_list}
        uses_session = any(isinstance(n, ast.Name) and n.id == "session" for n in ast.walk(node))
        marked = any("scr:public" in self.lines[ln - 1] for ln in
                     [d.lineno for d in node.decorator_list] + [node.lineno])
        if marked:
            self.suppressed += 1  # explicit, reviewable public-endpoint marker
            return
        if decos & AUTH_DECOS or uses_session:
            return
        self.add("SCR-007", node)

    def visit_ExceptHandler(self, node):
        self.exc.append(node.name)
        self.generic_visit(node)
        self.exc.pop()

    def visit_Call(self, node):
        name = dotted(node.func)
        kws = {k.arg: k.value for k in node.keywords}
        if isinstance(node.func, ast.Attribute) and node.func.attr in ("execute", "executemany", "executescript") and node.args:
            a = node.args[0]
            if (dynamic_str(a) and SQL_WORD.search(const_text(a))) or (
                    isinstance(a, ast.Name) and any(a.id in d for d in self.dyn)):
                self.add("SCR-001", node)
        if name in ("os.system", "os.popen", "subprocess.getoutput") or (
                name.startswith("subprocess.") and isinstance(kws.get("shell"), ast.Constant) and kws["shell"].value is True):
            self.add("SCR-002", node)
        if name in ("hashlib.md5", "hashlib.sha1"):
            self.add("SCR-003", node)
        if name == "render_template_string" and node.args and dynamic_str(node.args[0]):
            self.add("SCR-004", node)
        if name == "open" and node.args and not isinstance(node.args[0], ast.Constant):
            self.add("SCR-006", node)
        if name in ("eval", "exec", "pickle.loads", "pickle.load") or (name == "yaml.load" and "Loader" not in kws):
            self.add("SCR-011", node)
        if isinstance(node.func, ast.Attribute) and node.func.attr == "run" and not name.startswith("subprocess"):
            if isinstance(kws.get("debug"), ast.Constant) and kws["debug"].value is True:
                self.add("SCR-009", node)
            if isinstance(kws.get("host"), ast.Constant) and kws["host"].value == "0.0.0.0":
                self.add("SCR-010", node)
        self.generic_visit(node)

    def visit_Return(self, node):
        v = node.value
        if v is not None:
            if dynamic_str(v) and "<" in const_text(v) and not any(
                    isinstance(c, ast.Call) and dotted(c.func).split(".")[-1] == "escape" for c in ast.walk(v)):
                self.add("SCR-004", node)
            if any(isinstance(c, ast.Call) and ((dotted(c.func) == "str" and c.args and isinstance(c.args[0], ast.Name)
                                                 and c.args[0].id in self.exc) or dotted(c.func) == "traceback.format_exc")
                   for c in ast.walk(v)):
                self.add("SCR-005", node)
        self.generic_visit(node)

    def visit_Assign(self, node):
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str) and node.value.value:
            for t in node.targets:
                key = t.id if isinstance(t, ast.Name) else t.attr if isinstance(t, ast.Attribute) else (
                    t.slice.value if isinstance(t, ast.Subscript) and isinstance(t.slice, ast.Constant) else "")
                if isinstance(key, str) and SECRET_NAME.search(key):
                    self.add("SCR-008", node)
        self.generic_visit(node)


def scan_file(path, root):
    src = Path(path).read_text(encoding="utf-8", errors="replace")
    v = _Visitor(os.path.relpath(path, root), src.splitlines())
    v.visit(ast.parse(src))
    return v.findings, v.suppressed


def scan_directory(target, allowed_root=None):
    root = validate_target(target, allowed_root)
    findings, errors, files, suppressed = [], [], 0, 0
    for dp, dns, fns in os.walk(root, followlinks=False):
        dns[:] = [d for d in dns if d not in SKIP_DIRS and not os.path.islink(os.path.join(dp, d))]
        for fn in sorted(fns):
            p = os.path.join(dp, fn)
            if not fn.endswith(".py") or os.path.islink(p) or os.path.getsize(p) > MAX_BYTES:
                continue
            files += 1
            try:
                f, s = scan_file(p, root)
                findings += f
                suppressed += s
            except (SyntaxError, ValueError) as e:
                errors.append(f"{os.path.relpath(p, root)}: {type(e).__name__}")
    seen, uniq = set(), []
    for f in sorted(findings, key=lambda x: (x.file, x.line, x.rule)):
        if (f.rule, f.file, f.line) not in seen:
            seen.add((f.rule, f.file, f.line))
            uniq.append(f)
    return {"root": str(root), "files": files, "findings": uniq, "errors": errors, "suppressed": suppressed}
