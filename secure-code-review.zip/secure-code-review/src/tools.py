"""Run external analyzers only if installed; report exactly what happened."""
import json
import shutil
import subprocess


def _run(name, cmd, timeout=120):
    exe = shutil.which(cmd[0])
    if not exe:
        return {"tool": name, "status": "not executed", "detail": f"{cmd[0]} is not installed in this environment", "issues": None}
    try:
        p = subprocess.run([exe] + cmd[1:], capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired:
        return {"tool": name, "status": "failed", "detail": "timed out", "issues": None}
    out = {"tool": name, "status": f"executed (exit code {p.returncode})", "detail": p.stderr.strip()[:300], "issues": None}
    try:
        data = json.loads(p.stdout or "null")
        out["issues"] = len(data.get("results", data)) if isinstance(data, dict) else len(data)
    except (ValueError, TypeError):
        out["status"] = f"executed (exit code {p.returncode}); output not parseable"
    if name == "pip-audit" and p.returncode not in (0, 1):
        out["status"] = "failed"
        out["detail"] = "pip-audit needs network access to the vulnerability service: " + out["detail"]
    return out


def run_external(target, requirements):
    return [
        _run("Bandit", ["bandit", "-r", str(target), "-f", "json", "-q"]),
        _run("Ruff", ["ruff", "check", str(target), "--output-format", "json"]),
        _run("pip-audit", ["pip-audit", "-r", str(requirements), "-f", "json"]),
    ]
