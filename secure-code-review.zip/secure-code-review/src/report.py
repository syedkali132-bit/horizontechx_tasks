"""Generate Markdown/HTML reports and the before/after doc from REAL scan data."""
import html
import re
from datetime import datetime, timezone

from src import verify

SEV = ["Critical", "High", "Medium", "Low", "Informational"]
# rule: (title, severity, cwe, owasp, description, impact, remediation, vulnerable, fixed, regression test)
RULES = {
    "SCR-001": ("SQL injection via dynamically built query", "High", "CWE-89", "A03:2021 Injection",
                "User input is concatenated/formatted into SQL text, so input can change query structure.",
                "Authentication bypass, data disclosure or modification.",
                "Use parameterized queries and validate input.",
                "q = \"... WHERE username='%s'\" % name\ncon.execute(q)",
                "con.execute(\"SELECT id FROM users WHERE username = ?\", (name,))",
                "test_secure_app.test_sql_injection_login_rejected / test_search_injection_returns_nothing"),
    "SCR-002": ("Shell command built from user input", "High", "CWE-78", "A03:2021 Injection",
                "A command string containing user input is run with shell=True.",
                "Arbitrary command execution as the application user.",
                "Avoid the shell; pass an argument list, validate the host, set a timeout.",
                "subprocess.run(\"ping -c 1 \" + host, shell=True)",
                "subprocess.run([\"ping\", \"-c\", \"1\", host], timeout=5)  # after ip/hostname validation",
                "test_secure_app.test_ping_rejects_injection"),
    "SCR-003": ("Weak password hashing (MD5)", "High", "CWE-327 / CWE-916", "A02:2021 Cryptographic Failures",
                "Passwords are hashed with fast, unsalted MD5.",
                "Stolen hashes can be cracked quickly; identical passwords share hashes.",
                "Use a slow salted password hash (scrypt/PBKDF2/Argon2).",
                "hashlib.md5(password.encode()).hexdigest()",
                "generate_password_hash(password)  # werkzeug, salted",
                "test_secure_app.test_passwords_are_salted_hashes"),
    "SCR-004": ("Reflected cross-site scripting", "High", "CWE-79", "A03:2021 Injection",
                "Request data is placed into HTML without output encoding.",
                "Script execution in victims' browsers (session abuse, phishing).",
                "Escape on output, restrict length, add a restrictive CSP.",
                "return f\"<h1>Hello {name}</h1>\"",
                "return f\"<h1>Hello {escape(name)}</h1>\"",
                "test_secure_app.test_xss_is_escaped"),
    "SCR-005": ("Internal error details returned to client", "Medium", "CWE-209", "A05:2021 Security Misconfiguration",
                "Exception text is returned in the HTTP response.",
                "Leaks schema/query details that aid further attacks.",
                "Log server-side, return a generic message.",
                "except Exception as e:\n    return str(e), 500",
                "log.exception(\"unhandled error\")\nreturn jsonify(error=\"internal error\"), 500",
                "test_secure_app.test_errors_do_not_leak_details"),
    "SCR-006": ("Path traversal in file access", "High", "CWE-22", "A01:2021 Broken Access Control",
                "A user-supplied name is joined to a base directory and opened without containment checks.",
                "Reading arbitrary files readable by the process.",
                "Use send_from_directory / safe_join so the result stays in the base directory.",
                "open(os.path.join(UPLOADS, name))",
                "send_from_directory(uploads, name)",
                "test_secure_app.test_path_traversal_blocked"),
    "SCR-007": ("Missing authentication/authorization check", "High", "CWE-306 / CWE-862 / CWE-639", "A01:2021 Broken Access Control",
                "Route has no server-side authentication decorator or session check; object access has no ownership check.",
                "Anonymous access to data and admin functions; users reading others' records (IDOR).",
                "Require login/role on the server and filter by owner.",
                "@app.route(\"/note/<int:id>\")\ndef note(id): ...",
                "@login_required\n... WHERE id = ? AND owner = ?",
                "test_secure_app.test_authentication_required / test_note_ownership_enforced / test_admin_requires_admin_role"),
    "SCR-008": ("Hardcoded secret or password", "High", "CWE-798", "A07:2021 Identification and Authentication Failures",
                "A secret-like name is assigned a string literal in source.",
                "Anyone with source access can forge sessions or log in.",
                "Load secrets from the environment/secret store; fail closed if missing.",
                "SECRET_KEY = \"...literal...\"",
                "os.environ.get(\"APP_SECRET_KEY\")  # raise if absent",
                "test_secure_app.test_missing_secret_fails_closed / test_scanner.test_secure_app_is_clean"),
    "SCR-009": ("Debug mode enabled", "High", "CWE-489 / CWE-215", "A05:2021 Security Misconfiguration",
                "app.run(debug=True) exposes the interactive debugger.",
                "Remote code execution risk if reachable.",
                "Never enable debug outside local development.",
                "app.run(debug=True)", "app.run(host=\"127.0.0.1\")", "test_scanner.test_secure_app_is_clean"),
    "SCR-010": ("Server bound to all interfaces", "Informational", "CWE-668", "A05:2021 Security Misconfiguration",
                "host='0.0.0.0' exposes the server on every network interface.",
                "Wider exposure than necessary.", "Bind to 127.0.0.1 or put behind a reverse proxy.",
                "app.run(host=\"0.0.0.0\")", "app.run(host=\"127.0.0.1\")", "test_scanner.test_secure_app_is_clean"),
    "SCR-011": ("Dangerous dynamic execution/deserialization", "Critical", "CWE-95 / CWE-502", "A08:2021 Software and Data Integrity Failures",
                "eval/exec/pickle/yaml.load on data may execute attacker code.", "Remote code execution.",
                "Use json / yaml.safe_load; never eval input.", "eval(data)", "json.loads(data)", "n/a (rule not triggered in sample)"),
}


def status_of(f, proofs):
    k = (f.rule, f.function)
    if k in verify.TRIAGE:
        return verify.TRIAGE[k][0]
    if f.rule in verify.CONFIRMED_BY_EVIDENCE:
        return "Confirmed (direct evidence)"
    if proofs.get(k):
        return "Confirmed (exploit demonstrated)"
    return "Potential risk (not exercised)"


def md_escape(s):
    return str(s).replace("|", "\\|").replace("\n", " ")


def build_markdown(ctx):
    ins, sec, proofs, tools, tests = ctx["insecure"], ctx["secure"], ctx["proofs"], ctx["tools"], ctx["tests"]
    fs = ins["findings"]
    rows = []
    for i, f in enumerate(fs, 1):
        rows.append((f"F-{i:03d}", f, RULES[f.rule], status_of(f, proofs)))
    counts = {s: sum(1 for r in rows if r[2][1] == s and not r[3].startswith(("False", "Info"))) for s in SEV}
    stat = {}
    for r in rows:
        stat[r[3]] = stat.get(r[3], 0) + 1
    ran = [t for t in tools if t["status"].startswith("executed")]
    L = [f"# Secure Coding Review Report", "", f"Generated: {ctx['when']}  ", "Target: `sample_app/insecure` (deliberately vulnerable training code) and `sample_app/secure` (remediated).", "",
         "## 1. Executive summary", "",
         f"The built-in scanner reported **{len(fs)} findings** in the insecure training sample across {ins['files']} Python files "
         f"({', '.join(f'{v} {k.lower()}' for k, v in stat.items())}). The remediated application produced **{len(sec['findings'])} findings** "
         f"with the same scanner. Of the external analyzers, {len(ran)} of {len(tools)} actually executed (see Tools). "
         f"Automated test result: **{tests['summary']}**. This does not prove the application is secure (see Remaining risks).", "",
         "## 2. Audit scope", "", "- `sample_app/insecure/vulnerable_app.py` - intentionally flawed Flask app (educational).",
         "- `sample_app/secure/app.py` - remediated default app.", "- Only local code written for this project; no third-party systems were touched.", "",
         "## 3. Methodology", "",
         "1. Static AST analysis with the project's own rules (code is parsed, never executed).",
         "2. Manual inspection of every route, query, hash, file access and config line.",
         "3. Exploit proofs against the insecure sample using Flask's in-process test client to upgrade findings from *potential* to *confirmed*.",
         "4. Re-scan and regression tests against the secure app.", "",
         "Severity model (qualitative, impact x ease of exploitation): **Critical** remote code execution with no preconditions; **High** direct compromise of data/auth/code integrity; "
         "**Medium** information leak or weakened defense; **Low** minor hardening; **Informational** best-practice note. No CVSS scores were computed.",
         "Status model: *Confirmed (exploit demonstrated)*, *Confirmed (direct evidence)* (flaw visible in source), *Potential risk (not exercised)*, *False positive*, *Informational*.", "",
         "## 4. Tools used", "", "| Tool | Status | Detail |", "|---|---|---|",
         "| Built-in AST scanner (`src/scanner.py`) | executed | rules SCR-001..SCR-011 |"]
    for t in tools:
        L.append(f"| {t['tool']} | {md_escape(t['status'])} | {md_escape(t['detail'] or '-')} (issues: {t['issues'] if t['issues'] is not None else 'n/a'}) |")
    L += ["", "## 5. Findings summary", "", "| Severity | Count (excl. false positives/informational) |", "|---|---|"]
    L += [f"| {s} | {counts[s]} |" for s in SEV[:4]]
    L += ["", "| ID | Severity | Title | Location | Status |", "|---|---|---|---|---|"]
    for fid, f, m, st in rows:
        L.append(f"| {fid} | {m[1]} | {md_escape(m[0])} | {f.file}:{f.line} | {st} |")
    L += ["", "## 6. Detailed findings", ""]
    for fid, f, m, st in rows:
        title, sev, cwe, owasp, desc, impact, fix, bad, good, test = m
        retest = ("Rule not reported in `sample_app/secure` by the re-scan. " if not any(x.rule == f.rule for x in sec["findings"]) else "Rule STILL reported in secure app. ")
        L += [f"### {fid}: {title}", "", f"- **Severity:** {sev}", f"- **Status:** {st}", f"- **Location:** `{f.file}:{f.line}` (function `{f.function}`)",
              f"- **Reference:** {cwe}; OWASP {owasp}", f"- **Description:** {desc}", f"- **Impact:** {impact}",
              f"- **Remediation:** {fix}", f"- **Verification:** {retest}Regression test: `{test}`."]
        if (f.rule, f.function) in verify.TRIAGE:
            L.append(f"- **Triage note:** {verify.TRIAGE[(f.rule, f.function)][1]}")
        L += ["", "Evidence:", "", "```python", f.evidence, "```", "", "Corrected pattern:", "", "```python", good, "```", ""]
    L += ["## 7. Remediation plan", "", "1. Remove hardcoded secrets; inject via environment (SCR-008). 2. Parameterize all SQL (SCR-001). 3. Replace MD5 with salted slow hashing (SCR-003). "
          "4. Enforce authentication, roles and ownership on the server (SCR-007). 5. Escape output (SCR-004), contain file paths (SCR-006), remove shell use (SCR-002). "
          "6. Generic errors, no debug, local bind (SCR-005/009/010). All are implemented in `sample_app/secure/app.py`.", "",
          "## 8. Remaining risks", "",
          "- The secure app has no CSRF tokens (mitigated only by SameSite=Lax) and no login rate limiting/lockout.",
          "- No TLS/reverse-proxy hardening, session revocation, audit logging or password-reset flow is implemented.",
          "- `/ping` was only tested for input rejection; a real ping was not executed in tests.",
          "- The scanner is heuristic: it follows simple intra-function data flow only and can miss or over-report. `# scr:public` markers suppress the authentication rule and need review "
          f"({sec['suppressed']} used in the secure app).", "- SQLite and Flask versions were not checked for CVEs unless pip-audit executed (see Tools).", "",
          "## 9. Testing limitations", "",
          "- Network access was unavailable, so pip-audit could not query advisories; Bandit/Ruff run only if installed (see Tools table for what actually ran).",
          "- Tests use Flask's in-process client; no browser, fuzzing, or load testing.", "",
          "## 10. Final security assessment", "",
          f"The insecure sample is unsafe by design. The remediated sample fixes every finding the tooling and manual review identified, and its test suite result is: {tests['summary']}. "
          "That reduces known risk but does not establish that the application is completely secure; treat it as a teaching reference, not a production-ready system.", ""]
    return "\n".join(L)


def build_before_after():
    L = ["# Before-and-after code comparison", "", "Insecure examples live only in `sample_app/insecure/` (training samples).", ""]
    for rid, m in RULES.items():
        L += [f"## {rid}: {m[0]}", "", f"**Problem:** {m[4]} ({m[2]})", "", "Vulnerable:", "", "```python", m[7], "```", "", "Corrected:", "", "```python", m[8], "```", "",
              f"**Why safer:** {m[6]}", "", f"**Regression test:** `{m[9]}`", ""]
    return "\n".join(L)


def md_to_html(md):
    out, code, tbl = [], False, False
    inline = lambda s: re.sub(r"`([^`]+)`", r"<code>\1</code>", re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", html.escape(s, quote=False)))
    for ln in md.split("\n"):
        if ln.startswith("```"):
            out.append("</pre>" if code else "<pre>")
            code = not code
        elif code:
            out.append(html.escape(ln))
        elif ln.startswith("|"):
            cells = [c.strip() for c in re.split(r"(?<!\\)\|", ln.strip().strip("|"))]
            if set("".join(cells)) <= set("-"):
                continue
            tag = "th" if not tbl else "td"
            if not tbl:
                out.append("<table>")
                tbl = True
            out.append("<tr>" + "".join(f"<{tag}>{inline(c.replace(chr(92) + '|', '|'))}</{tag}>" for c in cells) + "</tr>")
        else:
            if tbl:
                out.append("</table>")
                tbl = False
            m = re.match(r"(#{1,3}) (.*)", ln)
            if m:
                out.append(f"<h{len(m[1])}>{inline(m[2])}</h{len(m[1])}>")
            elif ln.startswith("- "):
                out.append(f"<p>&bull; {inline(ln[2:])}</p>")
            elif ln.strip():
                out.append(f"<p>{inline(ln)}</p>")
    if tbl:
        out.append("</table>")
    css = ("body{font:15px/1.5 system-ui,sans-serif;max-width:960px;margin:2rem auto;padding:0 1rem;color:#1a1a1a}"
           "table{border-collapse:collapse;width:100%;margin:1rem 0}td,th{border:1px solid #ccc;padding:.35rem .6rem;text-align:left;font-size:13px}"
           "th{background:#f0f2f5}pre{background:#f6f8fa;padding:.7rem;overflow-x:auto}code{background:#f0f0f0;padding:0 .2rem}h1,h2{border-bottom:1px solid #ddd}")
    return f"<!doctype html><html lang=en><meta charset=utf-8><title>Secure Coding Review Report</title><style>{css}</style><body>" + "\n".join(out) + "</body></html>"


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
