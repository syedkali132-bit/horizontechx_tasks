"""INSECURE TRAINING SAMPLE - deliberately vulnerable. NEVER deploy or reuse.

Every flaw is labelled VULN-nn. The secure counterpart is sample_app/secure/app.py.
The default application (sample_app/secure) does not import this module.
"""
import hashlib
import os
import sqlite3
import subprocess

from flask import Flask, jsonify, request

BASE = os.path.dirname(os.path.abspath(__file__))
UPLOADS = os.path.join(BASE, "uploads")
SECRET_KEY = "training-only-secret"  # VULN-08 hardcoded secret
ADMIN_PASSWORD = "admin123"  # VULN-08 hardcoded password


def _md5(text):
    return hashlib.md5(text.encode()).hexdigest()  # VULN-03 weak, unsalted hash


def create_app(db_path):
    app = Flask(__name__)
    app.secret_key = SECRET_KEY

    con = sqlite3.connect(db_path)
    con.executescript(
        "CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT, password TEXT, role TEXT);"
        "CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, owner INTEGER, title TEXT, body TEXT);"
    )
    if not con.execute("SELECT 1 FROM users").fetchone():
        for name, pw, role in (("admin", ADMIN_PASSWORD, "admin"), ("alice", "alicepw", "user"), ("bob", "bobpw", "user")):
            con.execute("INSERT INTO users(username,password,role) VALUES (?,?,?)", (name, _md5(pw), role))
        con.execute("INSERT INTO notes(owner,title,body) VALUES (3,'bob note','bob private data')")
        con.execute("INSERT INTO notes(owner,title,body) VALUES (2,'alice note','alice private data')")
        con.commit()
    con.close()

    @app.route("/login", methods=["POST"])  # scr:public
    def login():
        d = request.get_json(force=True)
        # VULN-01 SQL injection: user input concatenated into SQL
        q = "SELECT id, role FROM users WHERE username='%s' AND password='%s'" % (d["username"], _md5(d["password"]))
        c = sqlite3.connect(db_path)
        row = c.execute(q).fetchone()
        c.close()
        return (jsonify(ok=True, role=row[1]), 200) if row else (jsonify(ok=False), 401)

    @app.route("/greet")  # scr:public
    def greet():
        # VULN-04 reflected XSS: unescaped input in HTML
        return f"<h1>Hello {request.args.get('name', '')}</h1>"

    @app.route("/search")
    def search():  # VULN-07 no authentication
        q = request.args.get("q", "")
        c = sqlite3.connect(db_path)
        try:
            # VULN-01 SQL injection via concatenation
            return jsonify(rows=c.execute("SELECT title FROM notes WHERE title LIKE '%" + q + "%'").fetchall())
        except Exception as e:
            return str(e), 500  # VULN-05 internal error text returned to client
        finally:
            c.close()

    @app.route("/note/<int:note_id>")
    def note(note_id):  # VULN-07 no auth, no ownership check (IDOR)
        c = sqlite3.connect(db_path)
        rows = c.execute(f"SELECT body FROM notes WHERE id={note_id}").fetchall()  # int converter: see triage
        c.close()
        return jsonify(body=rows[0][0]) if rows else ("not found", 404)

    @app.route("/admin")
    def admin():  # VULN-07 admin data without any check
        c = sqlite3.connect(db_path)
        users = c.execute("SELECT username, role FROM users").fetchall()
        c.close()
        return jsonify(users=users)

    @app.route("/download")
    def download():  # VULN-06 path traversal and VULN-07 no auth
        with open(os.path.join(UPLOADS, request.args.get("name", ""))) as fh:
            return fh.read()

    @app.route("/ping")
    def ping():  # VULN-02 command injection and VULN-07 no auth
        out = subprocess.run("ping -c 1 " + request.args.get("host", ""), shell=True, capture_output=True, text=True)
        return out.stdout

    return app


if __name__ == "__main__":
    create_app("insecure_demo.db").run(debug=True, host="0.0.0.0")  # VULN-09/10 debug + all interfaces
