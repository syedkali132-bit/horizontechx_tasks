"""Secure reference implementation of the demo application (the default app)."""
import ipaddress
import logging
import os
import re
import sqlite3
import subprocess
from functools import wraps

from flask import Flask, abort, jsonify, request, send_from_directory, session
from markupsafe import escape
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash, generate_password_hash

log = logging.getLogger("secure_app")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,32}$")
HOST_RE = re.compile(r"^(?=.{1,253}$)([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)*[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?$")
_DUMMY_HASH = generate_password_hash("dummy-password-for-timing")


def _connect(db_path):
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    return con


def init_db(db_path):
    con = _connect(db_path)
    con.executescript(
        "CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,"
        " password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user');"
        "CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, owner INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL);"
    )
    con.commit()
    con.close()


def create_user(db_path, username, password, role="user"):
    if not USERNAME_RE.match(username or ""):
        raise ValueError("invalid username")
    if not isinstance(password, str) or not 8 <= len(password) <= 128:
        raise ValueError("password must be 8-128 characters")
    if role not in ("user", "admin"):
        raise ValueError("invalid role")
    con = _connect(db_path)
    cur = con.execute("INSERT INTO users(username, password_hash, role) VALUES (?, ?, ?)",
                      (username, generate_password_hash(password), role))
    con.commit()
    uid = cur.lastrowid
    con.close()
    return uid


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if "uid" not in session:
            abort(401)
        return fn(*a, **kw)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*a, **kw):
        if session.get("role") != "admin":
            abort(403)
        return fn(*a, **kw)
    return wrapper


def create_app(db_path, secret_key=None, uploads_dir=None, secure_cookies=True):
    secret = secret_key or os.environ.get("APP_SECRET_KEY")
    if not secret:
        raise RuntimeError("APP_SECRET_KEY must be provided via the environment")
    app = Flask(__name__)
    app.config.update(SECRET_KEY=secret, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                      SESSION_COOKIE_SECURE=secure_cookies, MAX_CONTENT_LENGTH=64 * 1024)
    uploads = uploads_dir or os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
    init_db(db_path)

    @app.after_request
    def headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Content-Security-Policy"] = "default-src 'none'"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.errorhandler(Exception)
    def handle(e):
        if isinstance(e, HTTPException):
            return jsonify(error=e.name), e.code
        log.exception("unhandled error")  # details stay in the server log
        return jsonify(error="internal error"), 500

    @app.route("/login", methods=["POST"])  # scr:public
    def login():
        d = request.get_json(silent=True) or {}
        u, p = d.get("username"), d.get("password")
        if not isinstance(u, str) or not isinstance(p, str) or not USERNAME_RE.match(u):
            return jsonify(error="invalid credentials"), 401
        con = _connect(db_path)
        row = con.execute("SELECT id, role, password_hash FROM users WHERE username = ?", (u,)).fetchone()
        con.close()
        ok = check_password_hash(row["password_hash"] if row else _DUMMY_HASH, p)
        if not (row and ok):
            return jsonify(error="invalid credentials"), 401
        session.clear()
        session.update(uid=row["id"], role=row["role"])
        return jsonify(ok=True)

    @app.route("/logout", methods=["POST"])  # scr:public
    def logout():
        session.clear()
        return jsonify(ok=True)

    @app.route("/greet")  # scr:public
    def greet():
        return f"<h1>Hello {escape(request.args.get('name', '')[:64])}</h1>"

    @app.route("/notes", methods=["POST"])
    @login_required
    def add_note():
        d = request.get_json(silent=True) or {}
        t, b = d.get("title"), d.get("body")
        if not (isinstance(t, str) and isinstance(b, str) and 1 <= len(t) <= 100 and 1 <= len(b) <= 2000):
            return jsonify(error="invalid input"), 400
        con = _connect(db_path)
        cur = con.execute("INSERT INTO notes(owner, title, body) VALUES (?, ?, ?)", (session["uid"], t, b))
        con.commit()
        nid = cur.lastrowid
        con.close()
        return jsonify(id=nid), 201

    @app.route("/search")
    @login_required
    def search():
        q = request.args.get("q", "")
        if len(q) > 100:
            return jsonify(error="query too long"), 400
        like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        con = _connect(db_path)
        rows = con.execute("SELECT id, title FROM notes WHERE owner = ? AND title LIKE ? ESCAPE '\\'",
                           (session["uid"], like)).fetchall()
        con.close()
        return jsonify(rows=[dict(r) for r in rows])

    @app.route("/note/<int:note_id>")
    @login_required
    def note(note_id):
        con = _connect(db_path)
        row = con.execute("SELECT body FROM notes WHERE id = ? AND owner = ?", (note_id, session["uid"])).fetchone()
        con.close()
        if row is None:
            abort(404)  # same answer for missing and foreign notes
        return jsonify(body=row["body"])

    @app.route("/admin/users")
    @admin_required
    def admin_users():
        con = _connect(db_path)
        rows = con.execute("SELECT username, role FROM users").fetchall()
        con.close()
        return jsonify(users=[dict(r) for r in rows])

    @app.route("/download")
    @login_required
    def download():
        name = request.args.get("name", "")
        return send_from_directory(uploads, name)  # uses safe_join; traversal -> 404

    @app.route("/ping")
    @login_required
    def ping():
        host = request.args.get("host", "")
        try:
            ipaddress.ip_address(host)
        except ValueError:
            if not HOST_RE.match(host):
                return jsonify(error="invalid host"), 400
        if host.startswith("-"):
            return jsonify(error="invalid host"), 400
        try:
            out = subprocess.run(["ping", "-c", "1", "-W", "2", host], capture_output=True, text=True, timeout=5, check=False)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return jsonify(error="ping unavailable"), 503
        return jsonify(reachable=out.returncode == 0)

    return app


if __name__ == "__main__":
    create_app(os.environ.get("APP_DB", "app.db")).run(host="127.0.0.1")
